import {
  pgTable,
  uuid,
  text,
  integer,
  real,
  boolean,
  timestamp,
  jsonb,
  date,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

const uid = () =>
  uuid("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`);

export const subjects = pgTable("subjects", {
  id: uid(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#8b5cf6"),
  icon: text("icon").notNull().default("book"),
  totalSeconds: integer("total_seconds").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const notes = pgTable("notes", {
  id: uid(),
  subjectId: uuid("subject_id"),
  title: text("title").notNull(),
  content: text("content").notNull().default(""),
  tags: text("tags").array().notNull().default(sql`'{}'::text[]`),
  favorite: boolean("favorite").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const decks = pgTable("decks", {
  id: uid(),
  subjectId: uuid("subject_id"),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const cards = pgTable("cards", {
  id: uid(),
  deckId: uuid("deck_id").notNull(),
  front: text("front").notNull(),
  back: text("back").notNull(),
  easeFactor: real("ease_factor").notNull().default(2.5),
  intervalDays: integer("interval_days").notNull().default(0),
  repetitions: integer("repetitions").notNull().default(0),
  nextReview: timestamp("next_review", { withTimezone: true })
    .notNull()
    .defaultNow(),
  lastGrade: integer("last_grade").notNull().default(-1),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const cardReviews = pgTable("card_reviews", {
  id: uid(),
  cardId: uuid("card_id").notNull(),
  grade: integer("grade").notNull(),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const quizzes = pgTable("quizzes", {
  id: uid(),
  subjectId: uuid("subject_id"),
  title: text("title").notNull(),
  questions: jsonb("questions").notNull().default(sql`'[]'::jsonb`),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const quizAttempts = pgTable("quiz_attempts", {
  id: uid(),
  quizId: uuid("quiz_id").notNull(),
  score: integer("score").notNull().default(0),
  total: integer("total").notNull().default(0),
  answers: jsonb("answers").notNull().default(sql`'[]'::jsonb`),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const studySessions = pgTable("study_sessions", {
  id: uid(),
  subjectId: uuid("subject_id"),
  roomId: text("room_id").notNull().default("night"),
  mode: text("mode").notNull().default("pomodoro"),
  plannedSeconds: integer("planned_seconds").notNull().default(1500),
  actualSeconds: integer("actual_seconds").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  interruptions: integer("interruptions").notNull().default(0),
  focusScore: integer("focus_score").notNull().default(0),
  startedAt: timestamp("started_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  note: text("note").notNull().default(""),
});

export const goals = pgTable("goals", {
  id: uid(),
  subjectId: uuid("subject_id"),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  targetDate: date("target_date"),
  progress: integer("progress").notNull().default(0),
  status: text("status").notNull().default("active"),
  xp: integer("xp").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const goalSteps = pgTable("goal_steps", {
  id: uid(),
  goalId: uuid("goal_id").notNull(),
  title: text("title").notNull(),
  done: boolean("done").notNull().default(false),
  position: integer("position").notNull().default(0),
});

export const tasks = pgTable("tasks", {
  id: uid(),
  subjectId: uuid("subject_id"),
  title: text("title").notNull(),
  estMinutes: integer("est_minutes").notNull().default(25),
  done: boolean("done").notNull().default(false),
  priority: text("priority").notNull().default("medium"),
  scheduledFor: date("scheduled_for"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const companionMoods = pgTable("companion_moods", {
  id: uid(),
  mood: text("mood").notNull().default("happy"),
  message: text("message").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Subject = typeof subjects.$inferSelect;
export type Note = typeof notes.$inferSelect;
export type Deck = typeof decks.$inferSelect;
export type Card = typeof cards.$inferSelect;
export type Quiz = typeof quizzes.$inferSelect;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type StudySession = typeof studySessions.$inferSelect;
export type Goal = typeof goals.$inferSelect;
export type GoalStep = typeof goalSteps.$inferSelect;
export type Task = typeof tasks.$inferSelect;
