"use client";

import { useState } from "react";
import {
  Target, Plus, Check, Trash2, Flag, Calendar, ChevronDown, ListTodo, GraduationCap, X,
  CalendarClock,
} from "lucide-react";
import { api } from "@/lib/api";
import { engine } from "@/lib/audio-engine";
import type { Goal, GoalStep, Task, Subject } from "@/db/schema";

interface Props {
  goals: Goal[];
  steps: GoalStep[];
  tasks: Task[];
  subjects: Subject[];
  accent: string;
  refresh: () => void;
  onXp?: (xp: number, label: string) => void;
}

const COLORS = ["#8b5cf6", "#38bdf8", "#4ade80", "#f472b6", "#fbbf24", "#fb7185", "#2dd4bf", "#a3e635"];

export default function Goals({ goals, steps, tasks, subjects, accent, refresh, onXp }: Props) {
  const [tab, setTab] = useState<"goals" | "tasks" | "subjects">("goals");
  const [openGoal, setOpenGoal] = useState<string | null>(goals[0]?.id ?? null);
  const [newGoal, setNewGoal] = useState("");
  const [newStep, setNewStep] = useState("");
  const [newTask, setNewTask] = useState("");
  const [newSubject, setNewSubject] = useState("");
  const [subjectColor, setSubjectColor] = useState(COLORS[0]);

  const stepsFor = (gid: string) => steps.filter((s) => s.goalId === gid).sort((a, b) => a.position - b.position);
  const progressOf = (gid: string) => {
    const ss = stepsFor(gid);
    if (!ss.length) return goals.find((g) => g.id === gid)?.progress ?? 0;
    return Math.round((ss.filter((s) => s.done).length / ss.length) * 100);
  };

  const createGoal = async () => {
    if (!newGoal.trim()) return;
    await api.create("goals", { title: newGoal.trim(), subjectId: subjects[0]?.id ?? null });
    setNewGoal("");
    refresh();
  };

  const toggleStep = async (st: GoalStep) => {
    await api.update("goal_steps", st.id, { done: !st.done });
    if (!st.done) {
      engine.chime("tick");
      onXp?.(5, "Алхам +5 XP");
    }
    refresh();
  };

  const addStep = async (gid: string) => {
    if (!newStep.trim()) return;
    const ss = stepsFor(gid);
    await api.create("goal_steps", { goalId: gid, title: newStep.trim(), position: ss.length });
    setNewStep("");
    refresh();
  };

  const delGoal = async (id: string) => {
    if (!confirm("Зорилгыг устгах уу?")) return;
    await api.remove("goals", id);
    refresh();
  };

  const createTask = async () => {
    if (!newTask.trim()) return;
    await api.create("tasks", { title: newTask.trim(), subjectId: subjects[0]?.id ?? null });
    setNewTask("");
    refresh();
  };

  const toggleTask = async (t: Task) => {
    await api.update("tasks", t.id, { done: !t.done });
    if (!t.done) {
      engine.chime("tick");
      onXp?.(8, "Даалгавар +8 XP");
    }
    refresh();
  };

  const delTask = async (id: string) => {
    await api.remove("tasks", id);
    refresh();
  };

  const createSubject = async () => {
    if (!newSubject.trim()) return;
    await api.create("subjects", { name: newSubject.trim(), color: subjectColor });
    setNewSubject("");
    refresh();
  };

  const delSubject = async (id: string) => {
    if (!confirm("Хичээлийг устгах уу?")) return;
    await api.remove("subjects", id);
    refresh();
  };

  const openTasks = tasks.filter((t) => !t.done);
  const doneTasks = tasks.filter((t) => t.done);

  // ── шалгалтын тоолуур (StudySphere/StudyOS санаа) ──
  const exams = goals
    .filter((g) => g.targetDate)
    .map((g) => {
      const days = Math.ceil((new Date(g.targetDate!).getTime() - Date.now()) / 864e5);
      const sub = subjects.find((s) => s.id === g.subjectId);
      return { ...g, days, sub };
    })
    .filter((g) => g.days >= -30)
    .sort((a, b) => a.days - b.days)
    .slice(0, 3);

  // ── өнөөдрийн авто-төлөвлөгөө (StudySet санаа) ──
  const plan = [
    ...openTasks.slice(0, 3).map((t) => ({
      kind: "task", id: t.id, title: t.title,
      minutes: t.estMinutes, done: false, color: subjects.find((s) => s.id === t.subjectId)?.color ?? accent,
    })),
    ...goals
      .flatMap((g) => stepsFor(g.id).filter((s) => !s.done).slice(0, 1).map((s) => ({
        kind: "step", id: s.id, title: `${g.title} → ${s.title}`,
        minutes: 30, done: false, color: subjects.find((x) => x.id === g.subjectId)?.color ?? accent,
      })))
      .slice(0, 3),
  ];
  const planMinutes = plan.reduce((a, p) => a + (p.minutes ?? 25), 0);

  return (
    <div className="glass rounded-3xl p-4 md:p-5">
      {/* ── шалгалтын тоолуур ── */}
      {exams.length > 0 && (
        <div className="mb-3 grid grid-cols-3 gap-1.5">
          {exams.map((g) => {
            const urgent = g.days <= 7;
            const critical = g.days <= 0;
            return (
              <div
                key={g.id}
                className="overflow-hidden rounded-2xl p-2.5 ring-1"
                style={{
                  background: critical ? "rgba(239,68,68,.14)" : urgent ? "rgba(251,146,60,.12)" : "rgba(255,255,255,.05)",
                  borderColor: critical ? "rgba(239,68,68,.4)" : urgent ? "rgba(251,146,60,.4)" : "rgba(255,255,255,.1)",
                }}
              >
                <div className="flex items-baseline gap-1">
                  <span
                    className="font-display text-[26px] font-bold leading-none tabular-nums"
                    style={{ color: critical ? "#fca5a5" : urgent ? "#fdba74" : accent }}
                  >
                    {Math.max(0, g.days)}
                  </span>
                  <span className="text-[11px] font-bold text-white/55">хоног</span>
                </div>
                <div className="mt-1 truncate text-[11px] font-bold text-white/85">{g.title}</div>
                <div className="truncate text-[10px] text-white/45">
                  {g.days <= 0 ? "Өнөөдөр!" : g.targetDate}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── авто-төлөвлөгөө ── */}
      {plan.length > 0 && (
        <div className="mb-3 rounded-2xl bg-white/[.04] p-3 ring-1 ring-white/10">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-white/45">
              <CalendarClock size={12} style={{ color: accent }} /> Өнөөдрийн авто-төлөвлөгөө
            </span>
            <span className="text-[11px] font-bold" style={{ color: accent }}>~{planMinutes} мин</span>
          </div>
          <div className="space-y-1">
            {plan.map((p, i) => (
              <div key={p.id} className="flex items-center gap-2 rounded-xl bg-black/20 px-2.5 py-1.5">
                <span
                  className="grid h-5 w-5 shrink-0 place-items-center rounded-md text-[10px] font-bold text-white"
                  style={{ background: p.color }}
                >
                  {i + 1}
                </span>
                <span className="flex-1 truncate text-[12px] font-semibold text-white/85">{p.title}</span>
                <span className="shrink-0 text-[10px] text-white/40">{p.minutes}м</span>
              </div>
            ))}
          </div>
          <p className="mt-1.5 text-[10px] leading-snug text-white/40">
            Даалгавар, зорилгын алхмаас автоматаар үүсч байна — хүүрнэл төлөвлөгөө 🤖
          </p>
        </div>
      )}

      <div className="grid grid-cols-3 gap-1.5">
        {([
          { id: "goals", label: "Зорилго", icon: Target },
          { id: "tasks", label: "Даалгавар", icon: ListTodo },
          { id: "subjects", label: "Хичээл", icon: GraduationCap },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center justify-center gap-1.5 rounded-2xl px-2 py-2.5 text-[13px] font-bold ring-1 transition ${
              tab === t.id ? "text-white" : "bg-white/5 text-white/55 ring-white/10 hover:bg-white/10"
            }`}
            style={tab === t.id ? { background: `${accent}2e`, borderColor: `${accent}66` } : undefined}
          >
            <t.icon size={15} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "goals" && (
        <div className="mt-3">
          <div className="flex gap-1.5">
            <input
              value={newGoal}
              onChange={(e) => setNewGoal(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && createGoal()}
              placeholder="Шинэ зорилго — жишээ: IELTS 6.5…"
              className="w-full rounded-2xl bg-black/30 px-3 py-2.5 text-[13px] font-bold text-white ring-1 ring-white/12 outline-none placeholder:font-medium placeholder:text-white/30"
            />
            <button onClick={createGoal} className="grid w-11 shrink-0 place-items-center rounded-2xl text-white" style={{ background: accent }}>
              <Plus size={17} />
            </button>
          </div>
          <div className="mt-2.5 space-y-2">
            {goals.map((g) => {
              const ss = stepsFor(g.id);
              const pct = progressOf(g.id);
              const open = openGoal === g.id;
              const sub = subjects.find((s) => s.id === g.subjectId);
              return (
                <div key={g.id} className="overflow-hidden rounded-3xl bg-white/5 ring-1 ring-white/10">
                  <button onClick={() => setOpenGoal(open ? null : g.id)} className="flex w-full items-center gap-2.5 p-3 text-left">
                    <div
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl"
                      style={{ background: `${sub?.color ?? accent}22`, border: `1px solid ${sub?.color ?? accent}44` }}
                    >
                      <Flag size={17} style={{ color: sub?.color ?? accent }} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13px] font-bold text-white">{g.title}</div>
                      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/10">
                        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: sub?.color ?? accent }} />
                      </div>
                    </div>
                    <span className="shrink-0 font-display text-[13px] font-bold text-white/70">{pct}%</span>
                    <ChevronDown size={15} className={`shrink-0 text-white/40 transition-transform ${open ? "rotate-180" : ""}`} />
                  </button>
                  {open && (
                    <div className="anim-pop space-y-1.5 px-3 pb-3">
                      {ss.map((st) => (
                        <div key={st.id} className="flex items-center gap-2 rounded-2xl bg-black/25 px-2.5 py-2 ring-1 ring-white/8">
                          <button
                            onClick={() => toggleStep(st)}
                            className={`grid h-6 w-6 shrink-0 place-items-center rounded-lg ring-1 transition ${
                              st.done ? "text-white" : "bg-white/5 text-transparent ring-white/20 hover:ring-white/40"
                            }`}
                            style={st.done ? { background: "#22c55e", borderColor: "#22c55e" } : undefined}
                          >
                            <Check size={14} />
                          </button>
                          <span className={`flex-1 text-[12px] font-semibold ${st.done ? "text-white/40 line-through" : "text-white/85"}`}>
                            {st.title}
                          </span>
                        </div>
                      ))}
                      <div className="flex gap-1.5">
                        <input
                          value={newStep}
                          onChange={(e) => setNewStep(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && addStep(g.id)}
                          placeholder="+ Жижиг алхам нэмэх…"
                          className="w-full rounded-2xl bg-black/30 px-3 py-2 text-[12px] text-white ring-1 ring-white/10 outline-none placeholder:text-white/30"
                        />
                        <button onClick={() => addStep(g.id)} className="shrink-0 rounded-2xl bg-white/10 px-3 py-2 text-[12px] font-bold text-white/75 hover:bg-white/15">
                          <Plus size={14} />
                        </button>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="flex items-center gap-1 text-[11px] text-white/40">
                          <Calendar size={11} /> {g.targetDate || "Хугацаа тогтоогоогүй"}
                        </span>
                        <button onClick={() => delGoal(g.id)} className="flex items-center gap-1 text-[11px] font-bold text-red-300/70 hover:text-red-300">
                          <Trash2 size={11} /> Устгах
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            {goals.length === 0 && (
              <div className="rounded-3xl bg-white/4 p-5 text-center text-[12px] text-white/45">
                Зорилгоо бич — том мөрөөдлийг жижиг алхам болго 🎯
              </div>
            )}
          </div>
        </div>
      )}

      {tab === "tasks" && (
        <div className="mt-3">
          <div className="flex gap-1.5">
            <input
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && createTask()}
              placeholder="Өнөөдрийн даалгавар…"
              className="w-full rounded-2xl bg-black/30 px-3 py-2.5 text-[13px] font-bold text-white ring-1 ring-white/12 outline-none placeholder:font-medium placeholder:text-white/30"
            />
            <button onClick={createTask} className="grid w-11 shrink-0 place-items-center rounded-2xl text-white" style={{ background: accent }}>
              <Plus size={17} />
            </button>
          </div>
          <div className="mt-2.5 space-y-1.5">
            {openTasks.map((t) => {
              const sub = subjects.find((s) => s.id === t.subjectId);
              return (
                <div key={t.id} className="group flex items-center gap-2.5 rounded-2xl bg-white/5 px-3 py-2.5 ring-1 ring-white/10">
                  <button
                    onClick={() => toggleTask(t)}
                    className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-white/5 text-transparent ring-1 ring-white/20 transition hover:ring-white/50"
                  >
                    <Check size={14} />
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[13px] font-bold text-white/90">{t.title}</div>
                    <div className="flex items-center gap-2 text-[10px] text-white/45">
                      {sub && <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full" style={{ background: sub.color }} />{sub.name}</span>}
                      <span>~{t.estMinutes} мин</span>
                    </div>
                  </div>
                  <button onClick={() => delTask(t.id)} className="text-white/25 opacity-0 transition group-hover:opacity-100 hover:text-red-300">
                    <X size={15} />
                  </button>
                </div>
              );
            })}
            {openTasks.length === 0 && (
              <div className="rounded-3xl bg-emerald-400/10 p-4 text-center text-[12px] font-bold text-emerald-200 ring-1 ring-emerald-400/25">
                🎉 Бүх даалгавар дууссан! Бондоок бахархаж байна.
              </div>
            )}
            {doneTasks.length > 0 && (
              <>
                <div className="pt-1 text-[11px] font-bold uppercase tracking-widest text-white/35">Дууссан ({doneTasks.length})</div>
                {doneTasks.slice(0, 5).map((t) => (
                  <div key={t.id} className="flex items-center gap-2.5 rounded-2xl bg-white/[.03] px-3 py-2 opacity-60 ring-1 ring-white/5">
                    <button onClick={() => toggleTask(t)} className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-emerald-500 text-white">
                      <Check size={14} />
                    </button>
                    <span className="flex-1 truncate text-[12px] text-white/60 line-through">{t.title}</span>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      )}

      {tab === "subjects" && (
        <div className="mt-3">
          <div className="flex gap-1.5">
            <input
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && createSubject()}
              placeholder="Шинэ хичээл — жишээ: Физик…"
              className="w-full rounded-2xl bg-black/30 px-3 py-2.5 text-[13px] font-bold text-white ring-1 ring-white/12 outline-none placeholder:font-medium placeholder:text-white/30"
            />
            <button onClick={createSubject} className="grid w-11 shrink-0 place-items-center rounded-2xl text-white" style={{ background: accent }}>
              <Plus size={17} />
            </button>
          </div>
          <div className="mt-2 flex gap-1.5">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setSubjectColor(c)}
                className={`h-7 w-7 rounded-xl transition ${subjectColor === c ? "scale-110 ring-2 ring-white/60" : "opacity-60 hover:opacity-100"}`}
                style={{ background: c }}
              />
            ))}
          </div>
          <div className="mt-2.5 grid grid-cols-2 gap-1.5">
            {subjects.map((s) => (
              <div key={s.id} className="group flex items-center gap-2 rounded-2xl bg-white/5 px-3 py-2.5 ring-1 ring-white/10">
                <span className="h-3 w-3 shrink-0 rounded-full" style={{ background: s.color, boxShadow: `0 0 8px ${s.color}` }} />
                <span className="flex-1 truncate text-[13px] font-bold text-white/90">{s.name}</span>
                <button onClick={() => delSubject(s.id)} className="text-white/25 opacity-0 transition group-hover:opacity-100 hover:text-red-300">
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
