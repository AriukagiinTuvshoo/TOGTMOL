export type Priority = 1 | 2 | 3;
export type Energy = "deep" | "light";
export type TaskStatus = "todo" | "doing" | "done";

export type Subject = {
  id: number;
  name: string;
  color: string;
  glyph: string;
  weeklyTargetMinutes: number;
};

export type Milestone = {
  id: number;
  goalId: number;
  title: string;
  done: boolean;
  dueDate: string | null;
  sortOrder: number;
};

export type Goal = {
  id: number;
  title: string;
  description: string | null;
  subjectId: number | null;
  targetDate: string | null;
  status: string;
  priority: number;
  weeklyMinutes: number;
  milestones: Milestone[];
  focusSeconds: number;
  doneMilestones: number;
};

export type Task = {
  id: number;
  title: string;
  notes: string | null;
  subjectId: number | null;
  goalId: number | null;
  estimateMinutes: number;
  priority: number;
  energy: Energy;
  status: TaskStatus;
  dueDate: string | null;
  scheduledStart: string | null;
  scheduledEnd: string | null;
  startLabel: string | null;
  endLabel: string | null;
  completedAt: string | null;
  focusSeconds: number;
};

export type StudySession = {
  id: number;
  taskId: number | null;
  taskTitle: string | null;
  subjectId: number | null;
  subjectName: string | null;
  subjectColor: string | null;
  mode: string;
  plannedSeconds: number;
  actualSeconds: number;
  startedAt: string;
  endedAt: string;
  localDate: string;
  timeLabel: string;
  soundscape: string | null;
  rating: number | null;
  notes: string | null;
  interruptions: number;
  completed: boolean;
};

export type Settings = {
  focusMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  cyclesBeforeLong: number;
  dailyGoalMinutes: number;
  dayStart: string;
  dayEnd: string;
  deepStart: string;
  deepEnd: string;
  autoStartBreaks: boolean;
  autoStartFocus: boolean;
  soundOnFocus: boolean;
  chime: boolean;
  notifications: boolean;
  masterVolume: number;
  lastPreset: string;
  soundMix: Record<string, number>;
  displayName: string;
};

export type DayTotals = {
  date: string;
  minutes: number;
  sessions: number;
};

export type SubjectStat = {
  id: number;
  name: string;
  color: string;
  minutes: number;
  target: number;
};

export type DashboardData = {
  today: string;
  todayLabel: string;
  greeting: string;
  settings: Settings;
  subjects: Subject[];
  goals: Goal[];
  todayTasks: Task[];
  upcomingTasks: Task[];
  todaySessions: StudySession[];
  recentSessions: StudySession[];
  activeStreak: number;
  bestStreak: number;
  todayMinutes: number;
  weekMinutes: number;
  weekSessions: number;
  completedToday: number;
  totalOpenTasks: number;
  weekSeries: DayTotals[];
  heatmap: DayTotals[];
  subjectStats: SubjectStat[];
  nextBlock: PlanBlock | null;
  minutesToNextBlock: number | null;
  averageRating: number | null;
  focusSecondsToday: number;
};

export type PlanBlock = {
  id: string;
  taskId: number | null;
  title: string;
  startLabel: string;
  endLabel: string;
  startMinute: number;
  endMinute: number;
  startIso: string | null;
  endIso: string | null;
  kind: "task" | "break" | "event";
  energy: Energy | "rest";
  subjectId: number | null;
  reason: string;
  taskEstimate?: number;
  taskPriority?: number;
};

export type PlanData = {
  date: string;
  dateLabel: string;
  isToday: boolean;
  settings: Settings;
  subjects: Subject[];
  goals: Goal[];
  tasks: Task[];
  unscheduled: Task[];
  blocks: PlanBlock[];
  sessions: StudySession[];
  dayMinutes: number;
  capacityMinutes: number;
  overloadedTasks: Task[];
};

export type ShellData = {
  displayName: string;
  streak: number;
  todayMinutes: number;
  dailyGoalMinutes: number;
  lastPreset: string;
  soundMix: Record<string, number>;
  masterVolume: number;
  openTasks: number;
};

export type FocusData = {
  settings: Settings;
  subjects: Subject[];
  tasks: Task[];
  todaySessions: StudySession[];
  todayMinutes: number;
  goals: Goal[];
  nextBlock: PlanBlock | null;
  nowMinute: number;
  streak: number;
  dailyGoalMinutes: number;
};

export type StatsData = {
  range: number;
  totalMinutes: number;
  totalSessions: number;
  avgRating: number | null;
  completionRate: number;
  activeStreak: number;
  bestStreak: number;
  daily: DayTotals[];
  subjects: SubjectStat[];
  hours: { hour: number; minutes: number }[];
  soundscapes: { id: string; minutes: number }[];
  bestDay: DayTotals | null;
  heatmap: DayTotals[];
  sessions: StudySession[];
  focusBlocks: number;
};
