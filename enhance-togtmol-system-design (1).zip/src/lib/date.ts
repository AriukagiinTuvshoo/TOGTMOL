export const WEEKDAYS_MN = [
  "Ням",
  "Даваа",
  "Мягмар",
  "Лхагва",
  "Пүрэв",
  "Баасан",
  "Бямба",
];

export const WEEKDAYS_SHORT_MN = ["Ня", "Да", "Мя", "Лх", "Пү", "Ба", "Бя"];

export const MONTHS_MN = [
  "1 сар",
  "2 сар",
  "3 сар",
  "4 сар",
  "5 сар",
  "6 сар",
  "7 сар",
  "8 сар",
  "9 сар",
  "10 сар",
  "11 сар",
  "12 сар",
];

const pad = (value: number) => String(value).padStart(2, "0");

export function toISODate(date: Date): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function todayISO(): string {
  return toISODate(new Date());
}

export function parseISODate(iso: string): Date {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(year, (month ?? 1) - 1, day ?? 1, 12, 0, 0, 0);
}

export function isValidISODate(value: string | undefined | null): value is string {
  if (!value) return false;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = parseISODate(value);
  return !Number.isNaN(parsed.getTime()) && toISODate(parsed) === value;
}

export function addDaysISO(iso: string, days: number): string {
  const date = parseISODate(iso);
  date.setDate(date.getDate() + days);
  return toISODate(date);
}

export function startOfWeekISO(iso: string): string {
  const date = parseISODate(iso);
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  return addDaysISO(iso, diff);
}

export function daysBetweenISO(from: string, to: string): number {
  const a = parseISODate(from).getTime();
  const b = parseISODate(to).getTime();
  return Math.round((b - a) / 86_400_000);
}

export function formatDateLong(iso: string): string {
  const date = parseISODate(iso);
  return `${date.getFullYear()} оны ${date.getMonth() + 1} сарын ${date.getDate()}, ${WEEKDAYS_MN[date.getDay()]}`;
}

export function formatDateShort(iso: string): string {
  const date = parseISODate(iso);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

export function formatDateNumeric(iso: string): string {
  const date = parseISODate(iso);
  return `${date.getFullYear()}.${pad(date.getMonth() + 1)}.${pad(date.getDate())}`;
}

export function weekdayLabel(iso: string, short = false): string {
  const day = parseISODate(iso).getDay();
  return short ? WEEKDAYS_SHORT_MN[day] : WEEKDAYS_MN[day];
}

export function relativeDayLabel(iso: string, today = todayISO()): string {
  const diff = daysBetweenISO(today, iso);
  if (diff === 0) return "Өнөөдөр";
  if (diff === 1) return "Маргааш";
  if (diff === -1) return "Өчигдөр";
  if (diff > 1 && diff < 7) return `${weekdayLabel(iso)}`;
  return formatDateNumeric(iso);
}

export function minutesOfDayFromClock(value: string): number {
  const [hours, minutes] = value.split(":").map(Number);
  return (hours || 0) * 60 + (minutes || 0);
}

export function clockLabel(minutes: number): string {
  const clamped = Math.max(0, Math.min(24 * 60, Math.round(minutes)));
  return `${pad(Math.floor(clamped / 60))}:${pad(clamped % 60)}`;
}

export function clockLabelFromTimestamp(value: string | null): string | null {
  if (!value) return null;
  const time = value.includes("T") ? value.split("T")[1] : value.split(" ")[1];
  return time ? time.slice(0, 5) : null;
}

export function dateFromTimestamp(value: string | null): string | null {
  if (!value) return null;
  return value.slice(0, 10);
}

export function combineDateTime(dateISO: string, minutes: number): string {
  const clamped = Math.max(0, Math.min(24 * 60 - 1, Math.round(minutes)));
  return `${dateISO} ${pad(Math.floor(clamped / 60))}:${pad(clamped % 60)}:00`;
}

export function naiveNow(): string {
  const now = new Date();
  return `${toISODate(now)} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
}

export function nowMinuteOfDay(): number {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

export function minutesLabel(totalMinutes: number): string {
  const rounded = Math.max(0, Math.round(totalMinutes));
  const hours = Math.floor(rounded / 60);
  const minutes = rounded % 60;
  if (hours === 0) return `${minutes}м`;
  if (minutes === 0) return `${hours}ц`;
  return `${hours}ц ${minutes}м`;
}

export function focusLabel(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  if (hours === 0) return `${minutes} мин`;
  return `${hours}ц ${minutes}м`;
}

export function timerLabel(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const rest = total % 60;
  if (hours > 0) return `${hours}:${pad(minutes)}:${pad(rest)}`;
  return `${pad(minutes)}:${pad(rest)}`;
}

export function numberLabel(value: number): string {
  return new Intl.NumberFormat("en-US").format(Math.round(value));
}

export function percent(value: number, total: number): number {
  if (total <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round((value / total) * 100)));
}

export function dayRange(endISO: string, count: number): string[] {
  return Array.from({ length: count }, (_, index) => addDaysISO(endISO, index - (count - 1)));
}

export function computeStreaks(dates: string[], today = todayISO()): { active: number; best: number } {
  const unique = Array.from(new Set(dates)).sort();
  let best = 0;
  let run = 0;
  let previous: string | null = null;
  for (const day of unique) {
    if (previous && daysBetweenISO(previous, day) === 1) {
      run += 1;
    } else {
      run = 1;
    }
    best = Math.max(best, run);
    previous = day;
  }

  const set = new Set(unique);
  let active = 0;
  let cursor = set.has(today) ? today : addDaysISO(today, -1);
  while (set.has(cursor)) {
    active += 1;
    cursor = addDaysISO(cursor, -1);
  }
  return { active, best };
}

export function greetingForHour(hour = new Date().getHours()): string {
  if (hour < 6) return "Шөнийн тайван ажил";
  if (hour < 12) return "Өглөөний мэнд";
  if (hour < 18) return "Өдрийн мэнд";
  return "Оройн мэнд";
}
