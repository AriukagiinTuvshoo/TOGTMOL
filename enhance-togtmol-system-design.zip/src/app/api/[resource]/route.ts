import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  subjects, notes, decks, cards, cardReviews, quizzes, quizAttempts,
  studySessions, goals, goalSteps, tasks, companionMoods, appSettings,
} from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

const TABLES: Record<string, any> = {
  subjects,
  notes,
  decks,
  cards,
  card_reviews: cardReviews,
  quizzes,
  quiz_attempts: quizAttempts,
  study_sessions: studySessions,
  goals,
  goal_steps: goalSteps,
  tasks,
  companion_moods: companionMoods,
  app_settings: appSettings,
};

const ORDER_COL: Record<string, string> = {
  subjects: "created_at",
  notes: "updated_at",
  decks: "created_at",
  cards: "updated_at",
  card_reviews: "reviewed_at",
  quizzes: "created_at",
  quiz_attempts: "created_at",
  study_sessions: "started_at",
  goals: "created_at",
  goal_steps: "position",
  tasks: "created_at",
  companion_moods: "created_at",
  app_settings: "updated_at",
};

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string }> }
) {
  const { resource } = await params;
  const table = TABLES[resource];
  if (!table) return NextResponse.json({ error: "unknown resource" }, { status: 404 });
  try {
    const url = new URL(req.url);
    const limit = Math.min(500, Number(url.searchParams.get("limit") ?? 200));
    const orderCol = ORDER_COL[resource] ?? "created_at";
    // simple equality filters from query params (except limit/order)
    const filters: ReturnType<typeof eq>[] = [];
    url.searchParams.forEach((v, k) => {
      if (k === "limit" || k === "order") return;
      const col = table[k as keyof typeof table] as any;
      if (col && v) filters.push(eq(col, v));
    });
    let q = db.select().from(table).$dynamic();
    filters.forEach((f) => {
      q = q.where(f as any) as typeof q;
    });
    const rows = await q
      .orderBy(desc(sql.raw(`"${resource}"."${orderCol}"`)))
      .limit(limit);
    return NextResponse.json(rows);
  } catch (e) {
    console.error("GET", resource, e);
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string }> }
) {
  const { resource } = await params;
  const table = TABLES[resource];
  if (!table) return NextResponse.json({ error: "unknown resource" }, { status: 404 });
  try {
    const body = await req.json().catch(() => ({}));
    // map camelCase -> snake_case keys for convenience
    const mapped: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(body as Record<string, unknown>)) {
      const snake = k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
      mapped[snake] = v;
    }
    // app_settings upsert
    if (resource === "app_settings" && mapped["key"]) {
      const rows = await db
        .insert(appSettings)
        .values({ key: String(mapped["key"]), value: (mapped["value"] as object) ?? {} })
        .onConflictDoUpdate({
          target: appSettings.key,
          set: { value: (mapped["value"] as object) ?? {}, updatedAt: new Date() },
        })
        .returning();
      return NextResponse.json(rows[0], { status: 201 });
    }
    const rows = (await (db.insert as any)(table).values(mapped).returning()) as any[];
    return NextResponse.json(rows[0], { status: 201 });
  } catch (e) {
    console.error("POST", resource, e);
    return NextResponse.json({ error: "failed to create" }, { status: 500 });
  }
}
