export function cx(...values: (string | false | null | undefined)[]): string {
  return values.filter(Boolean).join(" ");
}

export const cn = cx;

export function sum(values: number[]): number {
  return values.reduce((total, value) => total + value, 0);
}

export function pick<T>(items: T[], index: number): T {
  return items[index % items.length];
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}
