import {
  boolean,
  date,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * ТОГТМОЛ v8 — study operating system.
 * Naive timestamps (no timezone) are used on purpose: the planner works on
 * wall-clock time, so a block scheduled at 09:00 is always 09:00 for the user.
 */

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#a3e635"),
  glyph: text("glyph").notNull().default("✦"),
  weeklyTargetMinutes: integer("weekly_target_minutes").notNull().default(240),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().defaultNow(),
});

export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  targetDate: date("target_date", { mode: "string" }),
  status: text("status").notNull().default("active"),
  priority: integer("priority").notNull().default(2),
  weeklyMinutes: integer("weekly_minutes").notNull().default(180),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().defaultNow(),
});

export const milestones = pgTable("milestones", {
  id: serial("id").primaryKey(),
  goalId: integer("goal_id")
    .notNull()
    .references(() => goals.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  done: boolean("done").notNull().default(false),
  dueDate: date("due_date", { mode: "string" }),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  notes: text("notes"),
  subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  goalId: integer("goal_id").references(() => goals.id, { onDelete: "set null" }),
  estimateMinutes: integer("estimate_minutes").notNull().default(30),
  priority: integer("priority").notNull().default(2),
  energy: text("energy").notNull().default("deep"),
  status: text("status").notNull().default("todo"),
  dueDate: date("due_date", { mode: "string" }),
  scheduledStart: timestamp("scheduled_start", { mode: "string" }),
  scheduledEnd: timestamp("scheduled_end", { mode: "string" }),
  completedAt: timestamp("completed_at", { mode: "string" }),
  focusSeconds: integer("focus_seconds").notNull().default(0),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  taskId: integer("task_id").references(() => tasks.id, { onDelete: "set null" }),
  subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  mode: text("mode").notNull().default("focus"),
  plannedSeconds: integer("planned_seconds").notNull().default(0),
  actualSeconds: integer("actual_seconds").notNull().default(0),
  startedAt: timestamp("started_at", { mode: "string" }).notNull(),
  endedAt: timestamp("ended_at", { mode: "string" }).notNull(),
  localDate: date("local_date", { mode: "string" }).notNull(),
  soundscape: text("soundscape"),
  rating: integer("rating"),
  notes: text("notes"),
  interruptions: integer("interruptions").notNull().default(0),
  completed: boolean("completed").notNull().default(true),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  id: integer("id").primaryKey().default(1),
  focusMinutes: integer("focus_minutes").notNull().default(25),
  shortBreakMinutes: integer("short_break_minutes").notNull().default(5),
  longBreakMinutes: integer("long_break_minutes").notNull().default(15),
  cyclesBeforeLong: integer("cycles_before_long").notNull().default(4),
  dailyGoalMinutes: integer("daily_goal_minutes").notNull().default(150),
  dayStart: text("day_start").notNull().default("07:30"),
  dayEnd: text("day_end").notNull().default("22:30"),
  deepStart: text("deep_start").notNull().default("08:30"),
  deepEnd: text("deep_end").notNull().default("12:00"),
  autoStartBreaks: boolean("auto_start_breaks").notNull().default(true),
  autoStartFocus: boolean("auto_start_focus").notNull().default(false),
  soundOnFocus: boolean("sound_on_focus").notNull().default(true),
  chime: boolean("chime").notNull().default(true),
  notifications: boolean("notifications").notNull().default(true),
  masterVolume: real("master_volume").notNull().default(0.7),
  lastPreset: text("last_preset").notNull().default("forest-rain"),
  soundMix: jsonb("sound_mix").$type<Record<string, number>>().notNull().default({}),
  displayName: text("display_name").notNull().default("Тэмүүлэн"),
  updatedAt: timestamp("updated_at", { mode: "string" }).notNull().defaultNow(),
});

export type SubjectRow = typeof subjects.$inferSelect;
export type GoalRow = typeof goals.$inferSelect;
export type MilestoneRow = typeof milestones.$inferSelect;
export type TaskRow = typeof tasks.$inferSelect;
export type SessionRow = typeof sessions.$inferSelect;
export type SettingsRow = typeof settings.$inferSelect;
