"use client";

import { cx } from "@/lib/utils";
import { useSound } from "@/components/sound/provider";
import { LAYERS, PRESETS } from "@/lib/sound";

const GROUPS = ["Байгаль", "Орон зай", "Хөгжим"] as const;

export function SoundMixer({ compact = false }: { compact?: boolean }) {
  const {
    mix,
    preset,
    volume,
    running,
    supported,
    setLayerVolume,
    setMasterVolume,
    applyPreset,
    toggle,
  } = useSound();

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="label">Дууны систем</p>
          <h3 className="mt-1 text-[16px] font-bold tracking-tight text-white">Амбиент микс</h3>
        </div>
        <button
          type="button"
          onClick={toggle}
          className={cx("btn", running ? "btn-ghost" : "btn-primary")}
          disabled={!supported}
        >
          {running ? "❚❚ Түр зогсоох" : "▶ Тоглуулах"}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {PRESETS.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => applyPreset(option.id)}
            className={cx(
              "rounded-xl border p-2.5 text-left transition",
              preset === option.id
                ? "border-[rgba(201,247,90,0.5)] bg-[rgba(201,247,90,0.12)]"
                : "border-[var(--line)] bg-white/[0.03] hover:border-white/25 hover:bg-white/[0.06]",
            )}
          >
            <span className="text-[13px]">{option.glyph}</span>
            <p className="mt-1 text-[11.5px] font-bold leading-tight text-white">{option.name}</p>
            {!compact ? (
              <p className="mt-0.5 line-clamp-2 text-[10px] leading-snug text-[var(--dim)]">
                {option.description}
              </p>
            ) : null}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {GROUPS.map((group) => (
          <div key={group}>
            <p className="label mb-2">{group}</p>
            <div className="space-y-2.5">
              {LAYERS.filter((layer) => layer.group === group).map((layer) => {
                const value = Math.round((mix[layer.id] ?? 0) * 100);
                return (
                  <div key={layer.id} className="flex items-center gap-3">
                    <span
                      className={cx(
                        "grid h-7 w-7 shrink-0 place-items-center rounded-lg border text-[11px]",
                        value > 0
                          ? "border-[rgba(201,247,90,0.35)] bg-[rgba(201,247,90,0.1)] text-[var(--lime)]"
                          : "border-[var(--line)] bg-white/[0.03] text-[var(--dim)]",
                      )}
                      aria-hidden
                    >
                      {layer.glyph}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="truncate text-[12px] font-semibold text-[#dde3ec]">{layer.name}</span>
                        <span className="mono text-[10px] text-[var(--dim)]">{value}</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={value}
                        onChange={(event) =>
                          setLayerVolume(layer.id, Number(event.target.value) / 100)
                        }
                        className="slider mt-1.5 w-full"
                        aria-label={`${layer.name} дууны түвшин`}
                        title={layer.hint}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="hairline" />

      <div>
        <div className="flex items-center justify-between">
          <span className="label">Ерөнхий түвшин</span>
          <span className="mono text-[11px] text-[var(--muted)]">{Math.round(volume * 100)}%</span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(volume * 100)}
          onChange={(event) => setMasterVolume(Number(event.target.value) / 100)}
          className="slider mt-2.5 w-full"
          aria-label="Ерөнхий дууны түвшин"
        />
      </div>

      <p className="rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2 text-[10.5px] leading-relaxed text-[var(--dim)]">
        Бүх дуу нь таны төхөөрөмж дээр бодит хугацаанд нийлэгждэг — татах файл, интернэт
        шаардлагагүй. Бинауралын давхарга зөвхөн чихэвчтэй үед мэдрэгдэнэ.
      </p>
    </div>
  );
}
