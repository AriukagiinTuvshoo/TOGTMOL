import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { getShellData } from "@/lib/data";
import { SoundProvider } from "@/components/sound/provider";
import { AppShell } from "@/components/shell";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "ТОГТМОЛ · Study OS",
  description:
    "Анхаарал, цаг, төлөвлөлт нэг дор — дуу, хугацаа, зорилгыг удирддаг хувийн суралцах систем.",
};

export const viewport: Viewport = {
  themeColor: "#07080a",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const profile = await getShellData();

  return (
    <html lang="mn">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <SoundProvider
          initialMix={profile.soundMix}
          initialPreset={profile.lastPreset}
          initialVolume={profile.masterVolume}
        >
          <AppShell profile={profile}>{children}</AppShell>
        </SoundProvider>
      </body>
    </html>
  );
}
