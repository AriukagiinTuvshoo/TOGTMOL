"use client";

import { cx } from "@/lib/utils";
import { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { updateSettings } from "@/app/actions";
import { SectionHeading, Toast } from "@/components/ui";
import { minutesLabel, minutesOfDayFromClock, clockLabel } from "@/lib/date";
import { presetLabel } from "@/lib/labels";
import type { Settings } from "@/lib/types";

function Toggle({
  checked,
  onChange,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  hint: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-center gap-3 rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2.5 text-left transition hover:border-white/20"
      aria-pressed={checked}
    >
      <span
        className={cx(
          "relative h-5 w-9 shrink-0 rounded-full transition",
          checked ? "bg-[rgba(201,247,90,0.85)]" : "bg-white/15",
        )}
      >
        <span
          className={cx(
            "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all",
            checked ? "left-[18px]" : "left-0.5",
          )}
        />
      </span>
      <span className="min-w-0">
        <span className="block text-[12px] font-semibold text-white">{label}</span>
        <span className="block text-[10px] leading-snug text-[var(--dim)]">{hint}</span>
      </span>
    </button>
  );
}

export function SettingsForm({ settings }: { settings: Settings }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [form, setForm] = useState<Settings>(settings);
  const [toast, setToast] = useState<string | null>(null);

  const patch = (values: Partial<Settings>) => setForm((current) => ({ ...current, ...values }));

  const save = () => {
    startTransition(async () => {
      await updateSettings({
        displayName: form.displayName,
        focusMinutes: form.focusMinutes,
        shortBreakMinutes: form.shortBreakMinutes,
        longBreakMinutes: form.longBreakMinutes,
        cyclesBeforeLong: form.cyclesBeforeLong,
        dailyGoalMinutes: form.dailyGoalMinutes,
        dayStart: form.dayStart,
        dayEnd: form.dayEnd,
        deepStart: form.deepStart,
        deepEnd: form.deepEnd,
        autoStartBreaks: form.autoStartBreaks,
        autoStartFocus: form.autoStartFocus,
        soundOnFocus: form.soundOnFocus,
        chime: form.chime,
        notifications: form.notifications,
        masterVolume: form.masterVolume,
      });
      setToast("Тохиргоо хадгалагдлаа.");
      window.setTimeout(() => setToast(null), 2600);
      router.refresh();
    });
  };

  const cyclePreview = useMemo(() => {
    const blocks: { label: string; kind: "focus" | "short" | "long"; minutes: number }[] = [];
    for (let index = 1; index <= form.cyclesBeforeLong; index += 1) {
      blocks.push({ label: `${index}`, kind: "focus", minutes: form.focusMinutes });
      if (index < form.cyclesBeforeLong) {
        blocks.push({ label: "☁", kind: "short", minutes: form.shortBreakMinutes });
      }
    }
    blocks.push({ label: "☾", kind: "long", minutes: form.longBreakMinutes });
    return blocks;
  }, [form.cyclesBeforeLong, form.focusMinutes, form.longBreakMinutes, form.shortBreakMinutes]);

  const cycleTotal = cyclePreview.reduce((sum, block) => sum + block.minutes, 0);
  const windowMinutes =
    minutesOfDayFromClock(form.dayEnd) - minutesOfDayFromClock(form.dayStart);
  const deepMinutes =
    minutesOfDayFromClock(form.deepEnd) - minutesOfDayFromClock(form.deepStart);
  const invalidWindow = windowMinutes <= 0;
  const invalidDeep = deepMinutes <= 0;

  return (
    <div className="space-y-4">
      <div className="panel p-5">
        <SectionHeading label="Профайл" title="Хувийн орон зай" hint="Нэр нь хянах самбар ба сессийн бүртгэлд харагдана." />
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="display-name">Нэр</label>
            <input
              id="display-name"
              className="input mt-1.5"
              value={form.displayName}
              onChange={(event) => patch({ displayName: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="daily-goal">Өдрийн зорилт (минут)</label>
            <input
              id="daily-goal"
              type="number"
              min={15}
              max={720}
              step={15}
              className="input mt-1.5"
              value={form.dailyGoalMinutes}
              onChange={(event) => patch({ dailyGoalMinutes: Number(event.target.value) })}
            />
          </div>
        </div>
      </div>

      <div className="panel p-5">
        <SectionHeading
          label="Цагийн систем"
          title="Цикл ба амралт"
          hint="Дрифтгүй тоолуур: түр зогссон ч цаг зөв бүртгэгдэнэ."
          action={<span className="chip">Нийт цикл {minutesLabel(cycleTotal)}</span>}
        />
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { key: "focusMinutes", label: "Фокус (мин)", min: 5, max: 180, step: 5 },
            { key: "shortBreakMinutes", label: "Богино амралт", min: 1, max: 60, step: 1 },
            { key: "longBreakMinutes", label: "Урт амралт", min: 5, max: 120, step: 5 },
            { key: "cyclesBeforeLong", label: "Урт амралт хүртэл", min: 2, max: 12, step: 1 },
          ].map((field) => (
            <div key={field.key}>
              <label className="label" htmlFor={field.key}>{field.label}</label>
              <input
                id={field.key}
                type="number"
                min={field.min}
                max={field.max}
                step={field.step}
                className="input mt-1.5"
                value={form[field.key as keyof Settings] as number}
                onChange={(event) => patch({ [field.key]: Number(event.target.value) } as Partial<Settings>)}
              />
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-2xl border border-[var(--line)] bg-black/25 p-3">
          <p className="label mb-2">Циклийн зураглал</p>
          <div className="flex flex-wrap items-center gap-1.5">
            {cyclePreview.map((block, index) => (
              <span
                key={index}
                className={cx(
                  "flex items-center gap-1 rounded-lg border px-2 py-1 text-[10px] font-bold",
                  block.kind === "focus"
                    ? "border-[rgba(201,247,90,0.4)] bg-[rgba(201,247,90,0.14)] text-[#e3ffb0]"
                    : block.kind === "short"
                      ? "border-[rgba(94,234,212,0.35)] bg-[rgba(94,234,212,0.1)] text-[#b9fff3]"
                      : "border-[rgba(180,164,255,0.35)] bg-[rgba(180,164,255,0.1)] text-[#ddd6ff]",
                )}
              >
                <span className="opacity-70">{block.kind === "focus" ? "◎" : block.label}</span>
                {block.minutes}м
              </span>
            ))}
            <span className="ml-1 text-[10px] text-[var(--dim)]">→ {clockLabel(cycleTotal)} нийт</span>
          </div>
        </div>

        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <Toggle
            checked={form.autoStartBreaks}
            onChange={(value) => patch({ autoStartBreaks: value })}
            label="Амралтыг автоматаар эхлүүлэх"
            hint="Сесс хадгалсны дараа амралт автоматаар эхэлнэ"
          />
          <Toggle
            checked={form.autoStartFocus}
            onChange={(value) => patch({ autoStartFocus: value })}
            label="Фокусыг автоматаар үргэлжлүүлэх"
            hint="Амралтын дараа дараагийн фокус автоматаар эхэлнэ"
          />
        </div>
      </div>

      <div className="panel p-5">
        <SectionHeading
          label="Төлөвлөлтийн цонх"
          title="Өдрийн хүрээ ба гүн ажил"
          hint="Автомат төлөвлөгч зөвхөн энэ цонх дотор блок байрлуулна."
        />
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="label" htmlFor="day-start">Өдөр эхлэх</label>
            <input
              id="day-start"
              type="time"
              className="input mt-1.5"
              value={form.dayStart}
              onChange={(event) => patch({ dayStart: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="day-end">Өдөр дуусах</label>
            <input
              id="day-end"
              type="time"
              className="input mt-1.5"
              value={form.dayEnd}
              onChange={(event) => patch({ dayEnd: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="deep-start">Гүн ажил эхлэх</label>
            <input
              id="deep-start"
              type="time"
              className="input mt-1.5"
              value={form.deepStart}
              onChange={(event) => patch({ deepStart: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="deep-end">Гүн ажил дуусах</label>
            <input
              id="deep-end"
              type="time"
              className="input mt-1.5"
              value={form.deepEnd}
              onChange={(event) => patch({ deepEnd: event.target.value })}
            />
          </div>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2.5">
            <p className="label">Идэвхтэй цонх</p>
            <p className="mono mt-1 text-[14px] font-bold text-white">
              {invalidWindow ? "Алдаатай" : minutesLabel(windowMinutes)}
            </p>
            {invalidWindow ? (
              <p className="mt-1 text-[10px] text-[var(--rose)]">Дуусах цаг эхлэхээс хойш байх ёстой.</p>
            ) : null}
          </div>
          <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2.5">
            <p className="label">Гүн ажлын нөөц</p>
            <p className="mono mt-1 text-[14px] font-bold text-[var(--lime)]">
              {invalidDeep ? "Алдаатай" : minutesLabel(deepMinutes)}
            </p>
            {invalidDeep ? (
              <p className="mt-1 text-[10px] text-[var(--rose)]">Гүн ажлын цонх буруу байна.</p>
            ) : null}
          </div>
        </div>
      </div>

      <div className="panel p-5">
        <SectionHeading
          label="Дуу ба мэдэгдэл"
          title="Амбиент систем"
          hint="Дуу нь төхөөрөмж дээр нийлэгждэг тул интернэт шаардлагагүй."
          action={
            <Link href="/focus" className="chip hover:border-white/30">
              Микшер →
            </Link>
          }
        />
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          <Toggle
            checked={form.soundOnFocus}
            onChange={(value) => patch({ soundOnFocus: value })}
            label="Фокус эхлэхэд дуу асаах"
            hint="Сесс эхлэхэд сонгосон амбиент тоглоно"
          />
          <Toggle
            checked={form.chime}
            onChange={(value) => patch({ chime: value })}
            label="Дуусах дохио"
            hint="Блок дуусахад зөөлөн хонх дуугарна"
          />
          <Toggle
            checked={form.notifications}
            onChange={(value) => patch({ notifications: value })}
            label="Системийн мэдэгдэл"
            hint="Таб хаагдсан ч дуусахыг мэдэгдэнэ"
          />
          <div className="rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2.5">
            <p className="label">Одоогийн амбиент</p>
            <p className="mt-1 text-[12px] font-bold text-white">{presetLabel(form.lastPreset)}</p>
            <div className="mt-2 flex items-center gap-2">
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(form.masterVolume * 100)}
                onChange={(event) => patch({ masterVolume: Number(event.target.value) / 100 })}
                className="slider flex-1"
                aria-label="Ерөнхий дууны түвшин"
              />
              <span className="mono text-[10px] text-[var(--dim)]">{Math.round(form.masterVolume * 100)}%</span>
            </div>
          </div>
        </div>
        <p className="mt-2.5 text-[10px] leading-relaxed text-[var(--dim)]">
          Мэдэгдлийн зөвшөөрөл шаардлагатай бол эхний фокус дээр браузер асууна.
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--line)] bg-white/[0.03] p-4">
        <p className="text-[11px] text-[var(--muted)]">
          {pending ? "Хадгалж байна…" : "Өөрчлөлтийг хадгалахад бүх хуудас шинэчлэгдэнэ."}
        </p>
        <div className="flex gap-2">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => setForm(settings)}
            disabled={pending}
          >
            Буцаах
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={save}
            disabled={pending || invalidWindow || invalidDeep}
          >
            {pending ? "Хадгалж байна…" : "Хадгалах"}
          </button>
        </div>
      </div>

      {toast ? <Toast message={toast} /> : null}
    </div>
  );
}
