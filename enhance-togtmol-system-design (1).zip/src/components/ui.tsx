"use client";

import { useEffect, useId, useRef, type ReactNode } from "react";
import { cx } from "@/lib/utils";

export function SectionHeading({
  label,
  title,
  action,
  hint,
}: {
  label?: string;
  title: string;
  action?: ReactNode;
  hint?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        {label ? <p className="label">{label}</p> : null}
        <h2 className="mt-1.5 text-[17px] font-bold tracking-tight text-white">{title}</h2>
        {hint ? <p className="mt-1 text-[12px] text-[var(--muted)]">{hint}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function Progress({
  value,
  tone = "lime",
  height = 6,
  className,
}: {
  value: number;
  tone?: "lime" | "violet" | "mint" | "rose";
  height?: number;
  className?: string;
}) {
  const colors: Record<string, string> = {
    lime: "linear-gradient(90deg,#8fd62a,#d9ff8d)",
    violet: "linear-gradient(90deg,#8b7cff,#d5ccff)",
    mint: "linear-gradient(90deg,#2dd4bf,#a7fff2)",
    rose: "linear-gradient(90deg,#fb7185,#ffd0d8)",
  };
  return (
    <div
      className={cx("w-full overflow-hidden rounded-full bg-white/8", className)}
      style={{ height }}
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="h-full rounded-full transition-[width] duration-500"
        style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: colors[tone] }}
      />
    </div>
  );
}

export function RadialProgress({
  value,
  size = 156,
  stroke = 10,
  children,
  tone = "#c9f75a",
  track = "rgba(255,255,255,0.09)",
}: {
  value: number;
  size?: number;
  stroke?: number;
  children?: ReactNode;
  tone?: string;
  track?: string;
}) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={tone}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - (circumference * clamped) / 100}
          style={{ transition: "stroke-dashoffset 700ms cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  const titleId = useId();
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center overflow-y-auto bg-black/70 p-3 backdrop-blur-md sm:items-center sm:p-6"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      role="presentation"
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className={cx(
          "panel fade-up my-auto w-full p-5 sm:p-6",
          wide ? "max-w-3xl" : "max-w-lg",
        )}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id={titleId} className="text-lg font-bold tracking-tight text-white">
              {title}
            </h2>
            {subtitle ? <p className="mt-1 text-[12.5px] text-[var(--muted)]">{subtitle}</p> : null}
          </div>
          <button className="btn btn-icon btn-ghost shrink-0" onClick={onClose} aria-label="Хаах" type="button">
            ✕
          </button>
        </div>
        <div className="mt-5">{children}</div>
        {footer ? <div className="mt-6 flex flex-wrap justify-end gap-2">{footer}</div> : null}
      </div>
    </div>
  );
}

export function Stat({
  label,
  value,
  unit,
  hint,
  tone = "default",
}: {
  label: string;
  value: string | number;
  unit?: string;
  hint?: string;
  tone?: "default" | "lime" | "violet" | "mint";
}) {
  const tones: Record<string, string> = {
    default: "text-white",
    lime: "text-[var(--lime)]",
    violet: "text-[var(--violet)]",
    mint: "text-[var(--mint)]",
  };
  return (
    <div className="rounded-2xl border border-[var(--line)] bg-white/[0.028] px-4 py-3.5">
      <p className="label">{label}</p>
      <p className={cx("mt-2 flex items-baseline gap-1 text-[26px] font-extrabold leading-none tracking-tight", tones[tone])}>
        <span className="mono">{value}</span>
        {unit ? <span className="text-[11.5px] font-semibold text-[var(--muted)]">{unit}</span> : null}
      </p>
      {hint ? <p className="mt-1.5 text-[11px] text-[var(--dim)]">{hint}</p> : null}
    </div>
  );
}

export function EmptyState({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-[var(--line-strong)] bg-white/[0.015] px-5 py-8 text-center">
      <p className="text-sm font-semibold text-white">{title}</p>
      <p className="mx-auto mt-1.5 max-w-sm text-[12px] leading-relaxed text-[var(--muted)]">{text}</p>
      {action ? <div className="mt-4 flex justify-center">{action}</div> : null}
    </div>
  );
}

export function SubjectDot({ color, size = 8 }: { color: string; size?: number }) {
  return (
    <span
      className="inline-block shrink-0 rounded-full"
      style={{ background: color, width: size, height: size, boxShadow: `0 0 10px ${color}66` }}
    />
  );
}

export function Toast({ message, tone = "ok" }: { message: string; tone?: "ok" | "error" }) {
  return (
    <div
      className={cx(
        "fixed bottom-24 left-1/2 z-[60] -translate-x-1/2 rounded-full border px-4 py-2 text-[12.5px] font-semibold shadow-2xl backdrop-blur-xl sm:bottom-8",
        tone === "ok"
          ? "border-[rgba(201,247,90,0.4)] bg-[rgba(24,32,14,0.92)] text-[#e3ffb0]"
          : "border-[rgba(248,113,113,0.4)] bg-[rgba(38,14,14,0.92)] text-[#fecaca]",
      )}
      role="status"
    >
      {message}
    </div>
  );
}
