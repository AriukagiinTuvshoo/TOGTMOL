import { asc, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import { goals, milestones, sessions, settings, subjects, tasks } from "@/db/schema";
import type { SettingsRow, SubjectRow, TaskRow } from "@/db/schema";
import {
  addDaysISO,
  clockLabelFromTimestamp,
  computeStreaks,
  daysBetweenISO,
  formatDateLong,
  greetingForHour,
  minutesLabel,
  minutesOfDayFromClock,
  nowMinuteOfDay,
  startOfWeekISO,
  todayISO,
} from "@/lib/date";
import { dayCapacity, taskBlocks } from "@/lib/plan";
import type {
  DashboardData,
  DayTotals,
  Energy,
  FocusData,
  Goal,
  PlanBlock,
  PlanData,
  Settings,
  ShellData,
  StatsData,
  StudySession,
  Subject,
  SubjectStat,
  Task,
  TaskStatus,
} from "@/lib/types";

export function mapSettings(row: SettingsRow): Settings {
  return {
    focusMinutes: row.focusMinutes,
    shortBreakMinutes: row.shortBreakMinutes,
    longBreakMinutes: row.longBreakMinutes,
    cyclesBeforeLong: row.cyclesBeforeLong,
    dailyGoalMinutes: row.dailyGoalMinutes,
    dayStart: row.dayStart,
    dayEnd: row.dayEnd,
    deepStart: row.deepStart,
    deepEnd: row.deepEnd,
    autoStartBreaks: row.autoStartBreaks,
    autoStartFocus: row.autoStartFocus,
    soundOnFocus: row.soundOnFocus,
    chime: row.chime,
    notifications: row.notifications,
    masterVolume: row.masterVolume,
    lastPreset: row.lastPreset,
    soundMix: row.soundMix ?? {},
    displayName: row.displayName,
  };
}

function mapSubject(row: SubjectRow): Subject {
  return {
    id: row.id,
    name: row.name,
    color: row.color,
    glyph: row.glyph,
    weeklyTargetMinutes: row.weeklyTargetMinutes,
  };
}

function mapTask(row: TaskRow): Task {
  return {
    id: row.id,
    title: row.title,
    notes: row.notes,
    subjectId: row.subjectId,
    goalId: row.goalId,
    estimateMinutes: row.estimateMinutes,
    priority: row.priority,
    energy: (row.energy === "light" ? "light" : "deep") as Energy,
    status: row.status as TaskStatus,
    dueDate: row.dueDate,
    scheduledStart: row.scheduledStart,
    scheduledEnd: row.scheduledEnd,
    startLabel: clockLabelFromTimestamp(row.scheduledStart),
    endLabel: clockLabelFromTimestamp(row.scheduledEnd),
    completedAt: row.completedAt,
    focusSeconds: row.focusSeconds,
  };
}

type SessionJoinRow = {
  id: number;
  taskId: number | null;
  subjectId: number | null;
  mode: string;
  plannedSeconds: number;
  actualSeconds: number;
  startedAt: string;
  endedAt: string;
  localDate: string;
  soundscape: string | null;
  rating: number | null;
  notes: string | null;
  interruptions: number;
  completed: boolean;
  taskTitle: string | null;
  subjectName: string | null;
  subjectColor: string | null;
};

function mapSession(row: SessionJoinRow): StudySession {
  return {
    id: row.id,
    taskId: row.taskId,
    taskTitle: row.taskTitle,
    subjectId: row.subjectId,
    subjectName: row.subjectName,
    subjectColor: row.subjectColor,
    mode: row.mode,
    plannedSeconds: row.plannedSeconds,
    actualSeconds: row.actualSeconds,
    startedAt: row.startedAt,
    endedAt: row.endedAt,
    localDate: row.localDate,
    timeLabel: clockLabelFromTimestamp(row.startedAt) ?? "00:00",
    soundscape: row.soundscape,
    rating: row.rating,
    notes: row.notes,
    interruptions: row.interruptions,
    completed: row.completed,
  };
}

export async function getSettings(): Promise<Settings> {
  await ensureSeeded();
  const rows = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  if (rows[0]) return mapSettings(rows[0]);
  const inserted = await db.insert(settings).values({ id: 1 }).returning();
  return mapSettings(inserted[0]);
}

async function loadSubjects(): Promise<Subject[]> {
  const rows = await db.select().from(subjects).orderBy(asc(subjects.id));
  return rows.map(mapSubject);
}

async function loadGoals(): Promise<Goal[]> {
  const [goalRows, milestoneRows, taskRows] = await Promise.all([
    db.select().from(goals).orderBy(asc(goals.status), asc(goals.targetDate)),
    db.select().from(milestones).orderBy(asc(milestones.sortOrder), asc(milestones.id)),
    db
      .select({ goalId: tasks.goalId, focusSeconds: tasks.focusSeconds, status: tasks.status })
      .from(tasks),
  ]);
  return goalRows.map((goal) => {
    const goalMilestones = milestoneRows
      .filter((milestone) => milestone.goalId === goal.id)
      .map((milestone) => ({
        id: milestone.id,
        goalId: milestone.goalId,
        title: milestone.title,
        done: milestone.done,
        dueDate: milestone.dueDate,
        sortOrder: milestone.sortOrder,
      }));
    const focusSeconds = taskRows
      .filter((task) => task.goalId === goal.id)
      .reduce((sum, task) => sum + task.focusSeconds, 0);
    return {
      id: goal.id,
      title: goal.title,
      description: goal.description,
      subjectId: goal.subjectId,
      targetDate: goal.targetDate,
      status: goal.status,
      priority: goal.priority,
      weeklyMinutes: goal.weeklyMinutes,
      milestones: goalMilestones,
      focusSeconds,
      doneMilestones: goalMilestones.filter((milestone) => milestone.done).length,
    };
  });
}

async function loadTasks(): Promise<Task[]> {
  const rows = await db
    .select()
    .from(tasks)
    .orderBy(asc(tasks.status), asc(tasks.dueDate), asc(tasks.scheduledStart));
  return rows.map(mapTask);
}

async function loadSessionsSince(sinceISO: string): Promise<StudySession[]> {
  const rows = await db
    .select({
      id: sessions.id,
      taskId: sessions.taskId,
      subjectId: sessions.subjectId,
      mode: sessions.mode,
      plannedSeconds: sessions.plannedSeconds,
      actualSeconds: sessions.actualSeconds,
      startedAt: sessions.startedAt,
      endedAt: sessions.endedAt,
      localDate: sessions.localDate,
      soundscape: sessions.soundscape,
      rating: sessions.rating,
      notes: sessions.notes,
      interruptions: sessions.interruptions,
      completed: sessions.completed,
      taskTitle: tasks.title,
      subjectName: subjects.name,
      subjectColor: subjects.color,
    })
    .from(sessions)
    .leftJoin(tasks, eq(sessions.taskId, tasks.id))
    .leftJoin(subjects, eq(sessions.subjectId, subjects.id))
    .where(gte(sessions.localDate, sinceISO))
    .orderBy(desc(sessions.startedAt));
  return rows.map(mapSession);
}

const focusMinutes = (list: StudySession[]) =>
  Math.round(
    list
      .filter((session) => session.mode === "focus")
      .reduce((sum, session) => sum + session.actualSeconds, 0) / 60,
  );

function aggregateDays(sessionList: StudySession[], isoDays: string[]): DayTotals[] {
  return isoDays.map((date) => {
    const daySessions = sessionList.filter(
      (session) => session.localDate === date && session.mode === "focus",
    );
    return { date, minutes: focusMinutes(daySessions), sessions: daySessions.length };
  });
}

function subjectBreakdown(
  subjectList: Subject[],
  sessionList: StudySession[],
): SubjectStat[] {
  return subjectList
    .map((subject) => ({
      id: subject.id,
      name: subject.name,
      color: subject.color,
      minutes: focusMinutes(sessionList.filter((session) => session.subjectId === subject.id)),
      target: subject.weeklyTargetMinutes,
    }))
    .sort((a, b) => b.minutes - a.minutes);
}

function nextBlockFor(taskList: Task[]): PlanBlock | null {
  const now = nowMinuteOfDay();
  const blocks = taskBlocks(taskList).filter(
    (block) => block.endMinute > now && block.kind === "task",
  );
  return blocks[0] ?? null;
}

function streakFrom(sessionList: StudySession[]): number {
  return computeStreaks(
    sessionList.filter((session) => session.mode === "focus").map((session) => session.localDate),
  ).active;
}

export async function getDashboardData(): Promise<DashboardData> {
  await ensureSeeded();
  const today = todayISO();
  const since = addDaysISO(today, -120);
  const weekStart = startOfWeekISO(today);

  const [settingsData, subjectList, goalList, taskList, sessionList] = await Promise.all([
    getSettings(),
    loadSubjects(),
    loadGoals(),
    loadTasks(),
    loadSessionsSince(since),
  ]);

  const todayTasks = taskList.filter(
    (task) => task.scheduledStart?.slice(0, 10) === today || task.completedAt?.slice(0, 10) === today,
  );
  const todaySessions = sessionList.filter((session) => session.localDate === today);
  const weekSessions = sessionList.filter(
    (session) => session.localDate >= weekStart && session.mode === "focus",
  );
  const recentSessions = sessionList
    .filter((session) => session.mode === "focus")
    .slice(0, 6);
  const weekSeries = aggregateDays(sessionList, Array.from({ length: 7 }, (_, index) =>
    addDaysISO(weekStart, index),
  ));
  const heatmap = aggregateDays(
    sessionList,
    Array.from({ length: 98 }, (_, index) => addDaysISO(today, index - 97)),
  );
  const streaks = computeStreaks(
    sessionList.filter((session) => session.mode === "focus").map((session) => session.localDate),
  );
  const nextBlock = nextBlockFor(todayTasks);
  const examined = sessionList.filter(
    (session) => session.rating !== null && daysBetweenISO(session.localDate, today) <= 21,
  );
  const averageRating = examined.length
    ? examined.reduce((sum, session) => sum + (session.rating ?? 0), 0) / examined.length
    : null;

  return {
    today,
    todayLabel: formatDateLong(today),
    greeting: greetingForHour(),
    settings: settingsData,
    subjects: subjectList,
    goals: goalList,
    todayTasks,
    upcomingTasks: taskList
      .filter((task) => task.status !== "done" && task.scheduledStart === null)
      .slice(0, 6),
    todaySessions,
    recentSessions,
    activeStreak: streaks.active,
    bestStreak: streaks.best,
    todayMinutes: focusMinutes(todaySessions),
    weekMinutes: focusMinutes(weekSessions),
    weekSessions: weekSessions.length,
    completedToday: taskList.filter(
      (task) => task.completedAt?.slice(0, 10) === today,
    ).length,
    totalOpenTasks: taskList.filter((task) => task.status !== "done").length,
    weekSeries,
    heatmap,
    subjectStats: subjectBreakdown(subjectList, weekSessions),
    nextBlock,
    minutesToNextBlock: nextBlock
      ? Math.max(0, nextBlock.startMinute - nowMinuteOfDay())
      : null,
    averageRating,
    focusSecondsToday: todaySessions
      .filter((session) => session.mode === "focus")
      .reduce((sum, session) => sum + session.actualSeconds, 0),
  };
}

export async function getPlanData(dateISO: string): Promise<PlanData> {
  await ensureSeeded();
  const today = todayISO();
  const [settingsData, subjectList, goalList, taskList, sessionList] = await Promise.all([
    getSettings(),
    loadSubjects(),
    loadGoals(),
    loadTasks(),
    loadSessionsSince(addDaysISO(dateISO, -1)),
  ]);

  const dayTasks = taskList.filter(
    (task) =>
      task.scheduledStart?.slice(0, 10) === dateISO ||
      task.completedAt?.slice(0, 10) === dateISO ||
      (task.scheduledStart === null && task.status !== "done" && task.dueDate === dateISO),
  );
  const daySessions = sessionList.filter((session) => session.localDate === dateISO);
  const unscheduled = taskList.filter(
    (task) => task.status !== "done" && task.scheduledStart === null,
  );
  const blocks = taskBlocks(dayTasks);
  const dayMinutes = focusMinutes(daySessions);

  return {
    date: dateISO,
    dateLabel: formatDateLong(dateISO),
    isToday: dateISO === today,
    settings: settingsData,
    subjects: subjectList,
    goals: goalList,
    tasks: taskList.filter((task) => task.status !== "done" || task.completedAt?.slice(0, 10) === dateISO),
    unscheduled,
    blocks,
    sessions: daySessions,
    dayMinutes,
    capacityMinutes: dayCapacity(settingsData),
    overloadedTasks: unscheduled.filter(
      (task) => task.dueDate !== null && task.dueDate <= dateISO,
    ),
  };
}

export async function getStatsData(range = 30): Promise<StatsData> {
  await ensureSeeded();
  const safeRange = [7, 30, 84].includes(range) ? range : 30;
  const today = todayISO();
  const heatmapSince = addDaysISO(today, -97);
  const since = addDaysISO(today, -(safeRange - 1));
  const [subjectList, sessionList, taskList] = await Promise.all([
    loadSubjects(),
    loadSessionsSince(heatmapSince < since ? heatmapSince : since),
    loadTasks(),
  ]);

  const rangeSessions = sessionList.filter(
    (session) => session.localDate >= since && session.mode === "focus",
  );
  const isoDays = Array.from({ length: safeRange }, (_, index) =>
    addDaysISO(since, index),
  );
  const daily = aggregateDays(rangeSessions, isoDays);
  const hours = Array.from({ length: 18 }, (_, index) => {
    const hour = index + 6;
    const minutes = rangeSessions
      .filter((session) => Number(session.startedAt.slice(11, 13)) === hour)
      .reduce((sum, session) => sum + session.actualSeconds, 0);
    return { hour, minutes: Math.round(minutes / 60) };
  });
  const soundscapeMap = new Map<string, number>();
  for (const session of rangeSessions) {
    const key = session.soundscape ?? "none";
    soundscapeMap.set(
      key,
      (soundscapeMap.get(key) ?? 0) + Math.round(session.actualSeconds / 60),
    );
  }
  const rated = rangeSessions.filter((session) => session.rating !== null);
  const streaks = computeStreaks(sessionList.map((session) => session.localDate));
  const completedTasks = taskList.filter((task) => task.status === "done").length;

  return {
    range: safeRange,
    totalMinutes: focusMinutes(rangeSessions),
    totalSessions: rangeSessions.length,
    avgRating: rated.length
      ? rated.reduce((sum, session) => sum + (session.rating ?? 0), 0) / rated.length
      : null,
    completionRate: completedTasks + taskList.length > 0
      ? Math.round((completedTasks / Math.max(1, completedTasks + taskList.filter((task) => task.status !== "done").length)) * 100)
      : 0,
    activeStreak: streaks.active,
    bestStreak: streaks.best,
    daily,
    subjects: subjectBreakdown(subjectList, rangeSessions),
    hours,
    soundscapes: Array.from(soundscapeMap.entries())
      .map(([id, minutes]) => ({ id, minutes }))
      .sort((a, b) => b.minutes - a.minutes),
    bestDay: daily.reduce<DayTotals | null>(
      (best, day) => (!best || day.minutes > best.minutes ? day : best),
      null,
    ),
    heatmap: aggregateDays(
      sessionList,
      Array.from({ length: 98 }, (_, index) => addDaysISO(heatmapSince, index)),
    ),
    sessions: rangeSessions.slice(0, 24),
    focusBlocks: rangeSessions.length,
  };
}

export async function getFocusData(): Promise<FocusData> {
  await ensureSeeded();
  const today = todayISO();
  const [settingsData, subjectList, goalList, taskList, sessionList] = await Promise.all([
    getSettings(),
    loadSubjects(),
    loadGoals(),
    loadTasks(),
    loadSessionsSince(addDaysISO(today, -2)),
  ]);
  const todaySessions = sessionList.filter((session) => session.localDate === today);
  const openTasks = taskList.filter((task) => task.status !== "done");
  return {
    settings: settingsData,
    subjects: subjectList,
    tasks: openTasks,
    todaySessions,
    todayMinutes: focusMinutes(todaySessions),
    goals: goalList,
    nextBlock: nextBlockFor(openTasks.filter((task) => task.scheduledStart?.slice(0, 10) === today)),
    nowMinute: nowMinuteOfDay(),
    streak: streakFrom(sessionList),
    dailyGoalMinutes: settingsData.dailyGoalMinutes,
  };
}

export async function getShellData(): Promise<ShellData> {
  await ensureSeeded();
  const today = todayISO();
  const [settingsData, sessionList, openTasks] = await Promise.all([
    getSettings(),
    loadSessionsSince(addDaysISO(today, -60)),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(tasks)
      .where(sql`${tasks.status} <> 'done'`),
  ]);
  const todaySessions = sessionList.filter(
    (session) => session.localDate === today && session.mode === "focus",
  );
  return {
    displayName: settingsData.displayName,
    streak: streakFrom(sessionList),
    todayMinutes: focusMinutes(todaySessions),
    dailyGoalMinutes: settingsData.dailyGoalMinutes,
    lastPreset: settingsData.lastPreset,
    soundMix: settingsData.soundMix,
    masterVolume: settingsData.masterVolume,
    openTasks: openTasks[0]?.count ?? 0,
  };
}

export function planSummary(plan: { blocks: PlanBlock[]; capacityMinutes: number }): string {
  const load = plan.blocks
    .filter((block) => block.kind === "task")
    .reduce((sum, block) => sum + (block.endMinute - block.startMinute), 0);
  return `${minutesLabel(load)} / ${minutesLabel(plan.capacityMinutes)}`;
}

export const DAY_START_FALLBACK = minutesOfDayFromClock("07:30");
