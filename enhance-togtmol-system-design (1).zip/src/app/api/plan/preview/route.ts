import { getPlanData } from "@/lib/data";
import { isValidISODate, todayISO } from "@/lib/date";
import { autoScheduleDay, dayCapacity } from "@/lib/plan";

export const dynamic = "force-dynamic";

/**
 * GET /api/plan/preview?date=YYYY-MM-DD
 * Returns a non-destructive, energy-aware schedule proposal for the day.
 */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const requested = url.searchParams.get("date");
  const date = isValidISODate(requested) ? requested : todayISO();

  try {
    const data = await getPlanData(date);
    const result = autoScheduleDay({
      date,
      tasks: data.tasks,
      settings: data.settings,
    });
    return Response.json({
      ok: true,
      date,
      capacityMinutes: dayCapacity(data.settings),
      window: { start: data.settings.dayStart, end: data.settings.dayEnd },
      deepWindow: { start: data.settings.deepStart, end: data.settings.deepEnd },
      scheduled: data.blocks.length,
      proposal: result,
    });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "unknown error" },
      { status: 500 },
    );
  }
}
