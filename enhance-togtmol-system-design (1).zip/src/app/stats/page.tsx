import Link from "next/link";
import { cx } from "@/lib/utils";
import { getStatsData } from "@/lib/data";
import { PageHeader } from "@/components/shell";
import { Bars, Donut, Heatmap } from "@/components/charts";
import { EmptyState, SectionHeading, Stat, SubjectDot } from "@/components/ui";
import { minutesLabel, formatDateNumeric, weekdayLabel, relativeDayLabel, todayISO } from "@/lib/date";
import { presetLabel, layerLabel } from "@/lib/labels";

export const dynamic = "force-dynamic";

const RANGES = [
  { value: 7, label: "7 хоног" },
  { value: 30, label: "30 хоног" },
  { value: 84, label: "12 долоо хоног" },
];

export default async function StatsPage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string }>;
}) {
  const params = await searchParams;
  const range = Number(params.range) || 30;
  const data = await getStatsData(range);
  const averageSession = data.totalSessions > 0 ? data.totalMinutes / data.totalSessions : 0;
  const activeDays = data.daily.filter((day) => day.minutes > 0).length;
  const bestHour = data.hours.reduce((best, hour) => (hour.minutes > best.minutes ? hour : best), data.hours[0]);
  const maxHour = Math.max(...data.hours.map((hour) => hour.minutes), 1);
  const maxSound = Math.max(...data.soundscapes.map((sound) => sound.minutes), 1);

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Хэмжилтийн систем"
        title="Анхаарлын статистик"
        description="Минут бүр бүртгэгддэг. Аль цаг, ямар дуу, ямар сэдэв таны хамгийн гүн ажлыг бий болгож байгааг хар."
        actions={
          <>
            {RANGES.map((option) => (
              <Link
                key={option.value}
                href={`/stats?range=${option.value}`}
                className={cx(
                  "chip",
                  data.range === option.value && "chip-accent",
                )}
              >
                {option.label}
              </Link>
            ))}
          </>
        }
      />

      <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        <Stat label="Нийт анхаарал" value={Math.round((data.totalMinutes / 60) * 10) / 10} unit="цаг" tone="lime" hint={`${data.focusBlocks} сесс`} />
        <Stat label="Өдрийн дундаж" value={Math.round(data.totalMinutes / Math.max(1, data.range))} unit="минут" hint={`${activeDays}/${data.range} идэвхтэй өдөр`} />
        <Stat label="Сессийн дундаж" value={Math.round(averageSession)} unit="минут" hint={data.avgRating ? `Чанар ${data.avgRating.toFixed(1)}/5` : "Үнэлгээ байхгүй"} tone="violet" />
        <Stat label="Цуваа" value={data.activeStreak} unit="өдөр" hint={`Дээд амжилт ${data.bestStreak}`} tone="mint" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5 lg:col-span-2">
          <SectionHeading
            label="Өдрийн хэмнэл"
            title="Анхаарлын уулзвар"
            hint={`${formatDateNumeric(data.daily[0]?.date ?? todayISO())} – ${formatDateNumeric(
              data.daily[data.daily.length - 1]?.date ?? todayISO(),
            )}`}
            action={
              data.bestDay ? (
                <span className="chip chip-accent">Шилдэг өдөр {minutesLabel(data.bestDay.minutes)}</span>
              ) : null
            }
          />
          <div className="mt-5">
            {data.daily.length > 0 ? <Bars days={data.daily} /> : null}
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2">
              <p className="label">Идэвхтэй өдөр</p>
              <p className="mono mt-1 text-[14px] font-bold text-white">{activeDays}</p>
            </div>
            <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2">
              <p className="label">Шилдэг цаг</p>
              <p className="mono mt-1 text-[14px] font-bold text-[var(--lime)]">
                {String(bestHour?.hour ?? 0).padStart(2, "0")}:00
              </p>
            </div>
            <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2">
              <p className="label">Гүйцэтгэл</p>
              <p className="mono mt-1 text-[14px] font-bold text-[var(--violet)]">{data.completionRate}%</p>
            </div>
          </div>
        </div>

        <div className="panel p-5">
          <SectionHeading label="Хуваарилалт" title="Сэдвийн минут" />
          <div className="mt-4">
            <Donut subjects={data.subjects} size={130} />
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5">
          <SectionHeading label="Биоритм" title="Цагийн бүс" hint="Аль цагт хамгийн их ажилласан" />
          <div className="mt-4 flex h-32 items-end gap-1">
            {data.hours.map((hour) => {
              const height = Math.max(3, Math.round((hour.minutes / maxHour) * 100));
              const isBest = bestHour && hour.hour === bestHour.hour && hour.minutes > 0;
              return (
                <div key={hour.hour} className="group flex flex-1 flex-col items-center gap-1">
                  <div
                    className={cx(
                      "w-full rounded-t-[3px] transition",
                      isBest
                        ? "bg-gradient-to-t from-[#8fd62a] to-[#e2ff96]"
                        : "bg-gradient-to-t from-[rgba(94,234,212,0.15)] to-[rgba(94,234,212,0.5)]",
                    )}
                    style={{ height: `${height}%` }}
                    title={`${hour.hour}:00 · ${minutesLabel(hour.minutes)}`}
                  />
                  {hour.hour % 3 === 0 ? (
                    <span className="text-[8px] text-[var(--dim)]">{hour.hour}</span>
                  ) : (
                    <span className="h-[10px]" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="panel p-5">
          <SectionHeading label="Дууны систем" title="Амбиентын нөлөө" hint="Сесс бүрд сонгосон дуу" />
          <div className="mt-4 space-y-2.5">
            {data.soundscapes.length > 0 ? (
              data.soundscapes.slice(0, 7).map((sound) => (
                <div key={sound.id}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-[#d6dde8]">
                      {presetLabel(sound.id)}
                    </span>
                    <span className="mono text-[10px] text-[var(--dim)]">{minutesLabel(sound.minutes)}</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/8">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[#2dd4bf] to-[#a7fff2]"
                      style={{ width: `${Math.round((sound.minutes / maxSound) * 100)}%` }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <p className="text-[11px] text-[var(--dim)]">Энэ хугацаанд дуу бүртгэгдээгүй.</p>
            )}
          </div>
          <p className="mt-3 rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2 text-[10px] leading-relaxed text-[var(--dim)]">
            Хамгийн их ашигласан: {data.soundscapes[0] ? presetLabel(data.soundscapes[0].id) : "—"}. Анхаарлын
            өрөөнд давхаргын түвшинг өөрчилж туршиж үз.
          </p>
        </div>

        <div className="panel p-5">
          <SectionHeading label="Тогтвортой байдал" title="98 өдрийн зураглал" />
          <div className="mt-4">
            <Heatmap days={data.heatmap} weeks={14} />
          </div>
          <div className="mt-4 space-y-2">
            {data.daily.slice(-7).reverse().slice(0, 4).map((day) => (
              <div key={day.date} className="flex items-center justify-between rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2">
                <span className="text-[10.5px] text-[var(--muted)]">
                  {weekdayLabel(day.date)} · {relativeDayLabel(day.date)}
                </span>
                <span className="mono text-[10.5px] font-semibold text-white">{minutesLabel(day.minutes)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="panel p-5">
        <SectionHeading
          label="Бүртгэл"
          title="Сессийн дэлгэрэнгүй"
          hint="Хугацаа, сэдэв, дуу, чанарын үнэлгээ"
          action={<span className="chip">{data.sessions.length} сесс</span>}
        />
        <div className="mt-4 overflow-x-auto scroll-thin">
          {data.sessions.length > 0 ? (
            <table className="w-full min-w-[620px] border-separate border-spacing-y-1.5 text-left">
              <thead>
                <tr className="text-[9.5px] uppercase tracking-wider text-[var(--dim)]">
                  <th className="px-3 pb-1 font-bold">Огноо</th>
                  <th className="px-3 pb-1 font-bold">Цаг</th>
                  <th className="px-3 pb-1 font-bold">Ажил / сэдэв</th>
                  <th className="px-3 pb-1 font-bold">Хугацаа</th>
                  <th className="px-3 pb-1 font-bold">Амбиент</th>
                  <th className="px-3 pb-1 font-bold">Чанар</th>
                </tr>
              </thead>
              <tbody>
                {data.sessions.map((session) => (
                  <tr key={session.id} className="text-[11px]">
                    <td className="rounded-l-xl border-y border-l border-[var(--line)] bg-white/[0.025] px-3 py-2.5 text-[var(--muted)]">
                      {formatDateNumeric(session.localDate)}
                    </td>
                    <td className="border-y border-[var(--line)] bg-white/[0.025] px-3 py-2.5">
                      <span className="mono text-[10px] text-[var(--dim)]">{session.timeLabel}</span>
                    </td>
                    <td className="max-w-[240px] border-y border-[var(--line)] bg-white/[0.025] px-3 py-2.5">
                      <span className="flex items-center gap-2">
                        <SubjectDot color={session.subjectColor ?? "#94a3b8"} size={6} />
                        <span className="truncate text-[#dde3ec]">
                          {session.taskTitle ?? session.subjectName ?? "Чөлөөт анхаарал"}
                        </span>
                      </span>
                    </td>
                    <td className="border-y border-[var(--line)] bg-white/[0.025] px-3 py-2.5">
                      <span className="mono font-semibold text-white">{minutesLabel(session.actualSeconds / 60)}</span>
                    </td>
                    <td className="border-y border-[var(--line)] bg-white/[0.025] px-3 py-2.5 text-[var(--muted)]">
                      {presetLabel(session.soundscape)}
                    </td>
                    <td className="rounded-r-xl border-y border-r border-[var(--line)] bg-white/[0.025] px-3 py-2.5">
                      <span className="text-[10px] text-[var(--amber)]">
                        {"★".repeat(session.rating ?? 0)}
                        <span className="text-white/15">{"★".repeat(5 - (session.rating ?? 0))}</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <EmptyState
              title="Энэ хугацаанд бүртгэл алга"
              text="Анхаарлын өрөөнд эхний сессээ бүртгэж, өөрийн хэв маягийг нээ."
              action={
                <Link href="/focus" className="btn btn-primary">
                  Анхаарал эхлүүлэх
                </Link>
              }
            />
          )}
        </div>
      </div>

      <div className="panel p-5">
        <SectionHeading label="Давхарга" title="Ашигласан дууны төрөл" />
        <div className="mt-3 flex flex-wrap gap-2">
          {data.soundscapes.map((sound) => (
            <span key={sound.id} className="chip">
              {layerLabel(sound.id) !== sound.id ? layerLabel(sound.id) : presetLabel(sound.id)} ·{" "}
              {minutesLabel(sound.minutes)}
            </span>
          ))}
          {data.soundscapes.length === 0 ? (
            <span className="text-[11px] text-[var(--dim)]">Мэдээлэл байхгүй.</span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
