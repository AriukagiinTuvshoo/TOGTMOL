"use client";

import { cx } from "@/lib/utils";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { MiniPlayer } from "@/components/sound/provider";
import { formatDateLong, minutesLabel, percent, todayISO } from "@/lib/date";
import type { ShellData } from "@/lib/types";
import { PRESET_BY_ID } from "@/lib/sound";

type NavItem = { href: string; label: string; icon: ReactNode; hint: string };

function Icon({ path, fill }: { path: string; fill?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" fill={fill ? "currentColor" : "none"} aria-hidden>
      <path
        d={path}
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

const NAV: NavItem[] = [
  {
    href: "/",
    label: "Хянах самбар",
    hint: "Өнөөдрийн тойм",
    icon: <Icon path="M4 13h6V4H4v9Zm0 7h6v-4H4v4Zm10 0h6v-9h-6v9Zm0-16v4h6V4h-6Z" />,
  },
  {
    href: "/focus",
    label: "Анхаарал",
    hint: "Цаг ба дуу",
    icon: <Icon path="M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5Zm0-4v2m0 18v2M3 12h2m14 0h2M5.6 5.6l1.4 1.4m10 10 1.4 1.4m0-12.8-1.4 1.4m-10 10L5.6 18.4" />,
  },
  {
    href: "/plan",
    label: "Төлөвлөгөө",
    hint: "Өдрийн блок",
    icon: <Icon path="M4 6h16M4 12h10M4 18h7M17 15l2 2 3-4" />,
  },
  {
    href: "/goals",
    label: "Зорилго",
    hint: "Урт хугацаа",
    icon: <Icon path="M12 3v3m0 12v3M3 12h3m12 0h3M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm0 3.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z" />,
  },
  {
    href: "/stats",
    label: "Статистик",
    hint: "Хэмжилт",
    icon: <Icon path="M5 20V10m7 10V4m7 16v-7" />,
  },
  {
    href: "/settings",
    label: "Тохиргоо",
    hint: "Систем",
    icon: <Icon path="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm8-3-2 1 .5 2-2 1.5-2-1-2 1-1-1.5L9 15l-.5-2L6 12l.5-2L9 9l-.5-2L10 5.5l2 1 2-1 1 1.5 2-1L18 8l2 .5v3Z" />,
  },
];

function Brand() {
  return (
    <Link href="/" className="flex items-center gap-3" aria-label="Тогтмол нүүр">
      <span className="relative grid h-10 w-10 place-items-center rounded-[14px] bg-gradient-to-br from-[#e2ff96] via-[#b8ef4a] to-[#7cbb21] text-[17px] font-black text-[#0e1405] shadow-[0_12px_30px_-12px_rgba(184,239,74,0.8)]">
        Т
        <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-[#080a0c] bg-[var(--mint)]" />
      </span>
      <span>
        <span className="block text-[15px] font-extrabold tracking-[0.16em] text-white">ТОГТМОЛ</span>
        <span className="block text-[10px] font-semibold uppercase tracking-[0.24em] text-[var(--dim)]">
          study os · v8
        </span>
      </span>
    </Link>
  );
}

export function AppShell({ children, profile }: { children: ReactNode; profile: ShellData }) {
  const pathname = usePathname();
  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));
  const goalPercent = percent(profile.todayMinutes, profile.dailyGoalMinutes || 1);
  const presetName = PRESET_BY_ID.get(profile.lastPreset)?.name ?? "Чимээгүй";

  return (
    <div className="min-h-screen">
      <div className="mx-auto flex w-full max-w-[1540px]">
        <aside className="scroll-thin sticky top-0 hidden h-screen w-[260px] shrink-0 flex-col gap-5 overflow-y-auto border-r border-[var(--line)] px-4 py-5 lg:flex">
          <Brand />

          <nav className="mt-2 space-y-1" aria-label="Үндсэн цэс">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cx(
                  "group flex items-center gap-3 rounded-xl px-3 py-2.5 transition",
                  isActive(item.href)
                    ? "border border-[rgba(201,247,90,0.28)] bg-[rgba(201,247,90,0.1)] text-white"
                    : "border border-transparent text-[#aab3c2] hover:bg-white/[0.05] hover:text-white",
                )}
              >
                <span
                  className={cx(
                    "grid h-8 w-8 place-items-center rounded-lg border transition",
                    isActive(item.href)
                      ? "border-[rgba(201,247,90,0.35)] bg-[rgba(201,247,90,0.14)] text-[var(--lime)]"
                      : "border-[var(--line)] bg-white/[0.03] text-[#98a3b4] group-hover:text-white",
                  )}
                >
                  {item.icon}
                </span>
                <span className="min-w-0">
                  <span className="block text-[13px] font-bold">{item.label}</span>
                  <span className="block text-[10.5px] text-[var(--dim)]">{item.hint}</span>
                </span>
                {isActive(item.href) ? (
                  <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[var(--lime)]" />
                ) : null}
              </Link>
            ))}
          </nav>

          <div className="rounded-2xl border border-[var(--line)] bg-white/[0.035] p-3.5">
            <div className="flex items-center justify-between">
              <p className="label">Анхаарлын цуваа</p>
              <span className="text-[13px]" aria-hidden>
                🔥
              </span>
            </div>
            <p className="mt-1.5 flex items-baseline gap-1.5">
              <span className="mono text-[24px] font-extrabold text-white">{profile.streak}</span>
              <span className="text-[11px] font-semibold text-[var(--muted)]">өдөр</span>
            </p>
            <div className="mt-2.5 h-1 w-full overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#8fd62a] to-[#d9ff8d]"
                style={{ width: `${goalPercent}%` }}
              />
            </div>
            <p className="mt-2 text-[10.5px] text-[var(--dim)]">
              {minutesLabel(profile.todayMinutes)} / {minutesLabel(profile.dailyGoalMinutes)} өнөөдөр
            </p>
          </div>

          <div className="mt-auto space-y-3">
            <Link href="/focus" className="btn btn-primary w-full">
              Анхаарал эхлүүлэх
            </Link>
            <MiniPlayer />
            <div className="flex items-center gap-2.5 rounded-2xl border border-[var(--line)] bg-white/[0.03] p-2.5">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-[#b4a4ff] to-[#5eead4] text-[12px] font-black text-[#0b0f14]">
                {profile.displayName.slice(0, 1)}
              </span>
              <div className="min-w-0">
                <p className="truncate text-[12px] font-bold text-white">{profile.displayName}</p>
                <p className="text-[10px] text-[var(--dim)]">
                  {profile.openTasks} нээлттэй ажил · {presetName}
                </p>
              </div>
            </div>
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 border-b border-[var(--line)] bg-[rgba(7,8,10,0.72)] backdrop-blur-xl lg:hidden">
            <div className="flex items-center justify-between gap-3 px-4 py-3">
              <Brand />
              <div className="flex items-center gap-2">
                <span className="chip">
                  🔥 <span className="mono">{profile.streak}</span>
                </span>
                <Link href="/focus" className="chip chip-live">
                  <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[var(--mint)]" /> {presetName}
                </Link>
              </div>
            </div>
          </header>

          <main className="mx-auto w-full max-w-[1320px] px-4 pb-28 pt-5 sm:px-6 lg:px-8 lg:pb-14 lg:pt-7">
            {children}
          </main>
        </div>
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-[var(--line)] bg-[rgba(8,10,13,0.94)] px-2 pb-[max(env(safe-area-inset-bottom),0.4rem)] pt-2 backdrop-blur-xl lg:hidden"
        aria-label="Гар утасны цэс"
      >
        <div className="mx-auto flex max-w-md items-center justify-between">
          {NAV.slice(0, 5).map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cx(
                "flex flex-1 flex-col items-center gap-1 rounded-xl px-1 py-1.5 text-[9.5px] font-bold transition",
                isActive(item.href) ? "text-[var(--lime)]" : "text-[#7d8797]",
              )}
            >
              <span
                className={cx(
                  "grid h-8 w-8 place-items-center rounded-lg",
                  isActive(item.href) ? "bg-[rgba(201,247,90,0.14)]" : "",
                )}
              >
                {item.icon}
              </span>
              {item.label}
            </Link>
          ))}
          <Link
            href="/settings"
            className={cx(
              "flex flex-1 flex-col items-center gap-1 rounded-xl px-1 py-1.5 text-[9.5px] font-bold",
              isActive("/settings") ? "text-[var(--lime)]" : "text-[#7d8797]",
            )}
          >
            <span className="grid h-8 w-8 place-items-center rounded-lg">⚙</span>
            Тохиргоо
          </Link>
        </div>
      </nav>
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:mb-6 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="label">{eyebrow}</p>
        <h1 className="display mt-2 text-[28px] text-white sm:text-[34px]">{title}</h1>
        {description ? (
          <p className="mt-2 max-w-2xl text-[12.5px] leading-relaxed text-[var(--muted)]">{description}</p>
        ) : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function TodayBadge() {
  return <span className="chip chip-accent">{formatDateLong(todayISO())}</span>;
}
