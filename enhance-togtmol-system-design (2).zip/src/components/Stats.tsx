"use client";

import { useMemo, useRef, useState } from "react";
import { Flame, Clock, Target, TrendingUp, Award, BarChart3, Download, Upload, ShieldCheck, Database } from "lucide-react";
import { api } from "@/lib/api";
import { fmtMnDuration, streakDays, levelForXp } from "@/lib/focus";
import type { StudySession, Subject } from "@/db/schema";

export default function Stats({
  sessions, subjects, accent,
}: { sessions: StudySession[]; subjects: Subject[]; accent: string }) {
  const data = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const todayS = sessions.filter((s) => new Date(s.startedAt).toISOString().slice(0, 10) === today);
    const todaySec = todayS.reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
    const weekAgo = Date.now() - 7 * 864e5;
    const weekS = sessions.filter((s) => new Date(s.startedAt).getTime() > weekAgo);
    const weekSec = weekS.reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
    const totalSec = sessions.reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
    const avgFocus = sessions.length
      ? Math.round(sessions.reduce((a, s) => a + (s.focusScore ?? 0), 0) / sessions.length)
      : 0;
    const dates = [...new Set(sessions.map((s) => new Date(s.startedAt).toISOString().slice(0, 10)))];
    const streak = streakDays(dates);
    const totalXp = sessions.reduce((a, s) => {
      const base = Math.floor((s.actualSeconds ?? 0) / 60) * 2;
      return a + base + (s.completed ? 15 : 0) + Math.floor((s.focusScore ?? 0) / 10);
    }, 0);
    const level = levelForXp(totalXp);
    // heatmap: last 8 weeks
    const days: { date: string; sec: number }[] = [];
    for (let i = 55; i >= 0; i--) {
      const d = new Date(Date.now() - i * 864e5);
      const key = d.toISOString().slice(0, 10);
      const sec = sessions
        .filter((s) => new Date(s.startedAt).toISOString().slice(0, 10) === key)
        .reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
      days.push({ date: key, sec });
    }
    const bySubject = subjects.map((sub) => {
      const sec = sessions
        .filter((s) => s.subjectId === sub.id)
        .reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
      return { ...sub, sec };
    }).sort((a, b) => b.sec - a.sec);
    const maxSub = Math.max(1, ...bySubject.map((s) => s.sec));
    return { todaySec, weekSec, totalSec, avgFocus, streak, totalXp, level, days, bySubject, maxSub, todayCount: todayS.length };
  }, [sessions, subjects]);

  const heat = (sec: number) =>
    sec === 0 ? "heat-0" : sec < 1500 ? "heat-1" : sec < 3600 ? "heat-2" : sec < 7200 ? "heat-3" : "heat-4";

  const accentColor = accent;
  const cards = [
    { icon: Flame, label: "Цуврал", value: `${data.streak} өдөр`, color: "#fb923c" },
    { icon: Clock, label: "Өнөөдөр", value: fmtMnDuration(data.todaySec), color: "#38bdf8" },
    { icon: BarChart3, label: "7 хоног", value: fmtMnDuration(data.weekSec), color: "#4ade80" },
    { icon: Target, label: "Фокус дундаж", value: `${data.avgFocus}/100`, color: accentColor },
  ];

  return (
    <div className="space-y-3">
      {/* level banner */}
      <div className="glass overflow-hidden rounded-3xl p-4">
        <div className="flex items-center gap-3">
          <div
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl font-display text-xl font-bold text-white"
            style={{ background: `linear-gradient(135deg, ${accentColor}, ${accentColor}66)`, boxShadow: `0 6px 24px ${accentColor}55` }}
          >
            {data.level.level}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <Award size={15} style={{ color: accentColor }} />
              <span className="font-display text-[14px] font-bold text-white">
                Түвшин {data.level.level} · {data.level.title}
              </span>
            </div>
            <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${(data.level.into / data.level.needed) * 100}%`, background: `linear-gradient(90deg, ${accentColor}, #fff)` }}
              />
            </div>
            <div className="mt-1 text-[11px] text-white/55">
              {data.totalXp} XP нийт · дараагийн түвшин хүртэл {data.level.needed - data.level.into} XP
            </div>
          </div>
        </div>
      </div>

      {/* stat cards */}
      <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="glass rounded-3xl p-3.5">
            <c.icon size={18} style={{ color: c.color }} />
            <div className="mt-2 font-display text-[19px] font-bold text-white">{c.value}</div>
            <div className="text-[11px] text-white/55">{c.label}</div>
          </div>
        ))}
      </div>

      {/* heatmap */}
      <div className="glass rounded-3xl p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp size={16} style={{ color: accentColor }} />
            <span className="text-[13px] font-bold text-white">Идэвхийн зураглал — 8 долоо хоног</span>
          </div>
          <span className="text-[11px] text-white/50">Нийт {fmtMnDuration(data.totalSec)} · {sessions.length} сесс</span>
        </div>
        <div className="grid grid-cols-[repeat(8,minmax(0,1fr))] gap-1.5 sm:grid-cols-[repeat(14,minmax(0,1fr))]">
          {data.days.map((d) => (
            <div
              key={d.date}
              title={`${d.date}: ${fmtMnDuration(d.sec)}`}
              className={`aspect-square rounded-[6px] ${heat(d.sec)} transition hover:scale-110`}
            />
          ))}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-[10px] text-white/40">
          <span>Бага</span>
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className={`h-2.5 w-2.5 rounded-[4px] heat-${i}`} />
          ))}
          <span>Их</span>
          <span className="ml-auto">Өнөөдөр: {data.todayCount} сесс</span>
        </div>
      </div>

      {/* subjects */}
      {data.bySubject.length > 0 && (
        <div className="glass rounded-3xl p-4">
          <div className="mb-3 text-[13px] font-bold text-white">Хичээлээр — зарцуулсан цаг</div>
          <div className="space-y-2.5">
            {data.bySubject.map((s) => (
              <div key={s.id}>
                <div className="mb-1 flex items-center justify-between text-[12px]">
                  <span className="flex items-center gap-1.5 font-bold text-white/85">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                    {s.name}
                  </span>
                  <span className="font-bold text-white/60">{fmtMnDuration(s.sec)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-white/8">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${(s.sec / data.maxSub) * 100}%`, background: s.color, boxShadow: `0 0 10px ${s.color}` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <BackupPanel accent={accentColor} />
    </div>
  );
}

// ── JSON нөөц / сэргээлт (StudySet, Marginalia-аас авсан санаа) ──────
function BackupPanel({ accent }: { accent: string }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const show = (m: string) => {
    setMsg(m);
    setTimeout(() => setMsg(null), 4000);
  };

  const doExport = async () => {
    setBusy(true);
    try {
      const [subjects, notes, decks, cards, quizzes, sessions, goals, steps, tasks] =
        await Promise.all([
          api.list("subjects"), api.list("notes"), api.list("decks"),
          api.list("cards", "?limit=1000"), api.list("quizzes"),
          api.list("study_sessions", "?limit=500"), api.list("goals"),
          api.list("goal_steps", "?limit=500"), api.list("tasks"),
        ]);
      const payload = {
        app: "togtmol",
        version: 8,
        exportedAt: new Date().toISOString(),
        data: { subjects, notes, decks, cards, quizzes, sessions, goals, steps, tasks },
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `togtmol-nööц-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      show("✅ JSON нөөц татагдлаа — аюулгүй газарт хадгалаарай.");
    } catch {
      show("❌ Нөөц бэлдэхэд алдаа гарлаа.");
    } finally {
      setBusy(false);
    }
  };

  const doImport = async (file: File) => {
    setBusy(true);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as { app?: string; data?: Record<string, any[]> };
      if (parsed.app !== "togtmol" || !parsed.data) {
        show("❌ Тогтмолын нөөц биш байна.");
        return;
      }
      // id-г шинэ болгохгүйгээр хэвээр нь — зөвхөн дутуу бичлэгийг нэмнэ
      let added = 0;
      for (const [key, rows] of Object.entries(parsed.data)) {
        if (!Array.isArray(rows)) continue;
        for (const row of rows) {
          try {
            const clean: Record<string, unknown> = { ...row };
            delete clean.id;
            delete clean.createdAt;
            if (key === "sessions") {
              await api.create("study_sessions", clean);
              added++;
            } else if (key === "steps") {
              // goal id хуучин байж магадгүй — давхардалгүй үед
              await api.create("goal_steps", clean);
              added++;
            } else if (["subjects", "notes", "decks", "cards", "quizzes", "goals", "tasks"].includes(key)) {
              await api.create(key as any, clean);
              added++;
            }
          } catch { /* давхардсан бичлэгийг алгасна */ }
        }
      }
      show(`✅ ${added} бичлэг импортлолоо. Шинэчилнэ үү.`);
    } catch {
      show("❌ Файл унших эсвэл JSON формат буруу байна.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-3 rounded-3xl bg-white/[.04] p-4 ring-1 ring-white/10">
      <div className="flex items-center gap-2">
        <Database size={16} style={{ color: accent }} />
        <span className="text-[13px] font-bold text-white">Нөөц ба өгөгдөл</span>
        <span className="ml-auto flex items-center gap-1 text-[11px] text-emerald-300">
          <ShieldCheck size={12} /> Зөвхөн таны төхөөрөмж
        </span>
      </div>
      <div className="mt-2.5 flex flex-wrap gap-1.5">
        <button
          onClick={doExport}
          disabled={busy}
          className="flex items-center gap-1.5 rounded-2xl px-4 py-2.5 text-[12px] font-bold text-white transition hover:scale-[1.03] disabled:opacity-50"
          style={{ background: `linear-gradient(135deg, ${accent}, ${accent}77)` }}
        >
          <Download size={14} /> JSON нөөц татаж авах
        </button>
        <button
          onClick={() => fileRef.current?.click()}
          disabled={busy}
          className="flex items-center gap-1.5 rounded-2xl bg-white/8 px-4 py-2.5 text-[12px] font-bold text-white/75 ring-1 ring-white/12 transition hover:bg-white/15 disabled:opacity-50"
        >
          <Upload size={14} /> Нөөцээс сэргээх
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void doImport(f);
            e.target.value = "";
          }}
        />
      </div>
      {msg && <div className="anim-pop mt-2 rounded-xl bg-black/30 px-3 py-2 text-[12px] font-bold text-white/80 ring-1 ring-white/10">{msg}</div>}
      <p className="mt-2 text-[11px] leading-snug text-white/40">
        Экспорт нь бүх хичээл, тэмдэглэл, карт, сорил, сесс, зорилгыг нэг JSON файл болгон авна. Импорт нь шинэ бичлэг нэмнэ.
      </p>
    </div>
  );
}
