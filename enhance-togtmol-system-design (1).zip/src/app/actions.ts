"use server";

import { revalidatePath } from "next/cache";
import { and, eq, gte, lt } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import { goals, milestones, sessions, settings, tasks } from "@/db/schema";
import {
  addDaysISO,
  combineDateTime,
  daysBetweenISO,
  minutesOfDayFromClock,
  naiveNow,
  todayISO,
} from "@/lib/date";
import { getSettings, mapSettings } from "@/lib/data";
import { autoScheduleDay, type AutoScheduleResult } from "@/lib/plan";
import type { PlanBlock, Settings, Task } from "@/lib/types";
import type { TaskRow } from "@/db/schema";

const refresh = () => {
  revalidatePath("/", "layout");
};

function clampInt(value: unknown, min: number, max: number, fallback: number): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(min, Math.min(max, Math.round(parsed)));
}

function rowToTask(row: TaskRow): Task {
  return {
    id: row.id,
    title: row.title,
    notes: row.notes,
    subjectId: row.subjectId,
    goalId: row.goalId,
    estimateMinutes: row.estimateMinutes,
    priority: row.priority,
    energy: row.energy === "light" ? "light" : "deep",
    status: row.status as Task["status"],
    dueDate: row.dueDate,
    scheduledStart: row.scheduledStart,
    scheduledEnd: row.scheduledEnd,
    startLabel: row.scheduledStart?.slice(11, 16) ?? null,
    endLabel: row.scheduledEnd?.slice(11, 16) ?? null,
    completedAt: row.completedAt,
    focusSeconds: row.focusSeconds,
  };
}

export type SaveSessionInput = {
  mode: "focus" | "short" | "long" | "stopwatch";
  plannedSeconds: number;
  actualSeconds: number;
  startedAt: string;
  endedAt: string;
  localDate?: string;
  taskId?: number | null;
  subjectId?: number | null;
  soundscape?: string | null;
  rating?: number | null;
  notes?: string | null;
  interruptions?: number;
  completed?: boolean;
};

export async function saveSession(input: SaveSessionInput) {
  await ensureSeeded();
  const planned = clampInt(input.plannedSeconds, 0, 24 * 3600, 0);
  const actual = clampInt(input.actualSeconds, 0, 24 * 3600, 0);
  if (actual < 5) return { ok: false as const, error: "Хэт богино байлаа." };

  let subjectId = input.subjectId ?? null;
  let taskTitle: string | null = null;
  if (input.taskId) {
    const taskRows = await db.select().from(tasks).where(eq(tasks.id, input.taskId)).limit(1);
    const task = taskRows[0];
    if (task) {
      subjectId = subjectId ?? task.subjectId;
      taskTitle = task.title;
      if (input.mode === "focus") {
        await db
          .update(tasks)
          .set({ focusSeconds: task.focusSeconds + actual, status: task.status === "todo" ? "doing" : task.status })
          .where(eq(tasks.id, task.id));
      }
    }
  }

  const localDate = input.localDate ?? input.startedAt.slice(0, 10) ?? todayISO();
  const inserted = await db
    .insert(sessions)
    .values({
      taskId: input.taskId ?? null,
      subjectId,
      mode: input.mode,
      plannedSeconds: planned,
      actualSeconds: actual,
      startedAt: input.startedAt,
      endedAt: input.endedAt,
      localDate,
      soundscape: input.soundscape ?? null,
      rating: input.rating != null ? clampInt(input.rating, 1, 5, 3) : null,
      notes: input.notes?.slice(0, 2000) ?? null,
      interruptions: clampInt(input.interruptions, 0, 50, 0),
      completed: input.completed ?? true,
    })
    .returning({ id: sessions.id });

  refresh();
  return { ok: true as const, id: inserted[0]?.id, taskTitle };
}

export async function rateSession(id: number, rating: number | null, notes?: string | null) {
  await ensureSeeded();
  await db
    .update(sessions)
    .set({
      rating: rating != null ? clampInt(rating, 1, 5, 3) : null,
      notes: notes?.slice(0, 2000) ?? null,
    })
    .where(eq(sessions.id, id));
  refresh();
  return { ok: true as const };
}

export async function updateSettings(patch: Partial<Settings>) {
  await ensureSeeded();
  const values: Record<string, unknown> = {};
  const ints: [keyof Settings, number, number][] = [
    ["focusMinutes", 5, 180],
    ["shortBreakMinutes", 1, 60],
    ["longBreakMinutes", 5, 120],
    ["cyclesBeforeLong", 2, 12],
    ["dailyGoalMinutes", 15, 720],
  ];
  for (const [key, min, max] of ints) {
    if (patch[key] !== undefined) values[key] = clampInt(patch[key], min, max, 25);
  }
  const booleans: (keyof Settings)[] = [
    "autoStartBreaks",
    "autoStartFocus",
    "soundOnFocus",
    "chime",
    "notifications",
  ];
  for (const key of booleans) {
    if (typeof patch[key] === "boolean") values[key] = patch[key];
  }
  const clocks: (keyof Settings)[] = ["dayStart", "dayEnd", "deepStart", "deepEnd"];
  for (const key of clocks) {
    const value = patch[key];
    if (typeof value === "string" && /^\d{2}:\d{2}$/.test(value)) {
      values[key] = value;
    }
  }
  if (typeof patch.masterVolume === "number") {
    values.masterVolume = Math.max(0, Math.min(1, patch.masterVolume));
  }
  if (typeof patch.lastPreset === "string") values.lastPreset = patch.lastPreset.slice(0, 60);
  if (patch.soundMix && typeof patch.soundMix === "object") values.soundMix = patch.soundMix;
  if (typeof patch.displayName === "string" && patch.displayName.trim()) {
    values.displayName = patch.displayName.trim().slice(0, 40);
  }
  if (Object.keys(values).length === 0) return { ok: true as const };
  values.updatedAt = naiveNow();
  const updated = await db.update(settings).set(values).where(eq(settings.id, 1)).returning();
  refresh();
  return { ok: true as const, settings: updated[0] ? mapSettings(updated[0]) : null };
}

export type TaskInput = {
  title: string;
  notes?: string | null;
  subjectId?: number | null;
  goalId?: number | null;
  estimateMinutes?: number;
  priority?: number;
  energy?: "deep" | "light";
  dueDate?: string | null;
  scheduledDate?: string | null;
  scheduledMinute?: number | null;
};

export async function createTask(input: TaskInput) {
  await ensureSeeded();
  const title = input.title?.trim();
  if (!title) return { ok: false as const, error: "Гарчиг хоосон байна." };
  const estimate = clampInt(input.estimateMinutes ?? 30, 5, 480, 30);
  const scheduled =
    input.scheduledDate && input.scheduledMinute != null
      ? combineDateTime(input.scheduledDate, input.scheduledMinute)
      : null;
  const inserted = await db
    .insert(tasks)
    .values({
      title: title.slice(0, 200),
      notes: input.notes?.slice(0, 2000) ?? null,
      subjectId: input.subjectId ?? null,
      goalId: input.goalId ?? null,
      estimateMinutes: estimate,
      priority: clampInt(input.priority ?? 2, 1, 3, 2),
      energy: input.energy === "light" ? "light" : "deep",
      dueDate: input.dueDate || null,
      scheduledStart: scheduled,
      scheduledEnd: scheduled
        ? combineDateTime(input.scheduledDate as string, (input.scheduledMinute as number) + estimate)
        : null,
    })
    .returning();
  refresh();
  return { ok: true as const, task: inserted[0] ? rowToTask(inserted[0]) : null };
}

export type TaskPatch = Partial<
  Pick<
    Task,
    "title" | "notes" | "subjectId" | "goalId" | "estimateMinutes" | "priority" | "energy" | "dueDate" | "status"
  >
> & {
  scheduledDate?: string | null;
  scheduledMinute?: number | null;
};

export async function updateTask(id: number, patch: TaskPatch) {
  await ensureSeeded();
  const values: Record<string, unknown> = {};
  if (typeof patch.title === "string" && patch.title.trim()) values.title = patch.title.trim().slice(0, 200);
  if (patch.notes !== undefined) values.notes = patch.notes?.slice(0, 2000) ?? null;
  if (patch.subjectId !== undefined) values.subjectId = patch.subjectId;
  if (patch.goalId !== undefined) values.goalId = patch.goalId;
  if (patch.estimateMinutes !== undefined) values.estimateMinutes = clampInt(patch.estimateMinutes, 5, 480, 30);
  if (patch.priority !== undefined) values.priority = clampInt(patch.priority, 1, 3, 2);
  if (patch.energy) values.energy = patch.energy === "light" ? "light" : "deep";
  if (patch.dueDate !== undefined) values.dueDate = patch.dueDate || null;
  if (patch.status) {
    values.status = patch.status;
    values.completedAt = patch.status === "done" ? naiveNow() : null;
  }
  if (patch.scheduledDate !== undefined) {
    if (patch.scheduledDate && patch.scheduledMinute != null) {
      const estimate = clampInt(patch.estimateMinutes ?? 30, 5, 480, 30);
      values.scheduledStart = combineDateTime(patch.scheduledDate, patch.scheduledMinute);
      values.scheduledEnd = combineDateTime(patch.scheduledDate, patch.scheduledMinute + estimate);
    } else {
      values.scheduledStart = null;
      values.scheduledEnd = null;
    }
  }
  if (Object.keys(values).length === 0) return { ok: true as const };
  await db.update(tasks).set(values).where(eq(tasks.id, id));
  refresh();
  return { ok: true as const };
}

export async function toggleTaskDone(id: number, done: boolean) {
  await ensureSeeded();
  await db
    .update(tasks)
    .set({ status: done ? "done" : "todo", completedAt: done ? naiveNow() : null })
    .where(eq(tasks.id, id));
  refresh();
  return { ok: true as const };
}

export async function deleteTask(id: number) {
  await ensureSeeded();
  await db.delete(tasks).where(eq(tasks.id, id));
  refresh();
  return { ok: true as const };
}

export async function scheduleTask(id: number, dateISO: string, startMinute: number) {
  await ensureSeeded();
  const rows = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  const task = rows[0];
  if (!task) return { ok: false as const, error: "Ажил олдсонгүй." };
  const start = Math.max(0, Math.min(24 * 60 - 5, Math.round(startMinute)));
  await db
    .update(tasks)
    .set({
      scheduledStart: combineDateTime(dateISO, start),
      scheduledEnd: combineDateTime(dateISO, start + task.estimateMinutes),
    })
    .where(eq(tasks.id, id));
  refresh();
  return { ok: true as const };
}

export async function unscheduleTask(id: number) {
  await ensureSeeded();
  await db.update(tasks).set({ scheduledStart: null, scheduledEnd: null }).where(eq(tasks.id, id));
  refresh();
  return { ok: true as const };
}

export type AutoPlanPreview = {
  blocks: PlanBlock[];
  unplacedTitles: string[];
  loadMinutes: number;
  deepMinutes: number;
  breaks: number;
  windowLabel: string;
};

async function buildAutoPlan(
  dateISO: string,
  reschedule: boolean,
): Promise<{ result: AutoScheduleResult; preview: AutoPlanPreview }> {
  await ensureSeeded();
  const [settingsData, taskRows] = await Promise.all([
    getSettings(),
    db.select().from(tasks).where(eq(tasks.status, "todo")),
  ]);
  const doingRows = await db.select().from(tasks).where(eq(tasks.status, "doing"));
  const allRows = [...taskRows, ...doingRows];
  const taskList = allRows.map(rowToTask);
  const dayTasks = taskList.filter((task) => task.scheduledStart?.slice(0, 10) === dateISO);

  const plannerInput = taskList.map((task) => {
    if (reschedule && task.scheduledStart?.slice(0, 10) === dateISO) {
      return { ...task, scheduledStart: null, scheduledEnd: null };
    }
    return task;
  });

  const result = autoScheduleDay({
    date: dateISO,
    tasks: plannerInput,
    settings: settingsData,
    nowMinute: dateISO === todayISO() ? undefined : minutesOfDayFromClock(settingsData.dayStart),
  });

  const previewBlocks = [
    ...(reschedule
      ? []
      : dayTasks
          .filter((task) => task.startLabel && task.endLabel)
          .map<PlanBlock>((task) => ({
            id: `fixed-${task.id}`,
            taskId: task.id,
            title: task.title,
            startLabel: task.startLabel as string,
            endLabel: task.endLabel as string,
            startMinute: minutesOfDayFromClock(task.startLabel as string),
            endMinute: minutesOfDayFromClock(task.endLabel as string),
            startIso: task.scheduledStart,
            endIso: task.scheduledEnd,
            kind: "task",
            energy: task.energy,
            subjectId: task.subjectId,
            reason: "Одоогийн блок",
          }))),
    ...result.blocks,
  ].sort((a, b) => a.startMinute - b.startMinute);

  return {
    result,
    preview: {
      blocks: previewBlocks,
      unplacedTitles: result.unplaced.map((task) => task.title),
      loadMinutes: result.loadMinutes,
      deepMinutes: result.deepMinutes,
      breaks: result.breaks,
      windowLabel: `${settingsData.dayStart} – ${settingsData.dayEnd}`,
    },
  };
}

export async function previewAutoPlan(dateISO: string, reschedule = false) {
  const { preview } = await buildAutoPlan(dateISO, reschedule);
  return preview;
}

export async function applyAutoPlan(dateISO: string, reschedule = false) {
  const { result } = await buildAutoPlan(dateISO, reschedule);
  if (reschedule) {
    await db
      .update(tasks)
      .set({ scheduledStart: null, scheduledEnd: null })
      .where(
        and(
          gte(tasks.scheduledStart, `${dateISO} 00:00:00`),
          lt(tasks.scheduledStart, `${addDaysISO(dateISO, 1)} 00:00:00`),
        ),
      );
  }
  for (const block of result.blocks) {
    if (block.kind !== "task" || !block.taskId || !block.startIso || !block.endIso) continue;
    await db
      .update(tasks)
      .set({ scheduledStart: block.startIso, scheduledEnd: block.endIso })
      .where(eq(tasks.id, block.taskId));
  }
  refresh();
  return {
    ok: true as const,
    placed: result.blocks.filter((block) => block.kind === "task").length,
    unplaced: result.unplaced.length,
  };
}

export async function clearDayPlan(dateISO: string) {
  await ensureSeeded();
  await db
    .update(tasks)
    .set({ scheduledStart: null, scheduledEnd: null })
    .where(
      and(
        gte(tasks.scheduledStart, `${dateISO} 00:00:00`),
        lt(tasks.scheduledStart, `${addDaysISO(dateISO, 1)} 00:00:00`),
      ),
    );
  refresh();
  return { ok: true as const };
}

export type GoalInput = {
  title: string;
  description?: string | null;
  subjectId?: number | null;
  targetDate?: string | null;
  weeklyMinutes?: number;
  priority?: number;
  firstMilestone?: string | null;
};

export async function createGoal(input: GoalInput) {
  await ensureSeeded();
  const title = input.title?.trim();
  if (!title) return { ok: false as const, error: "Зорилгын нэр хоосон." };
  const inserted = await db
    .insert(goals)
    .values({
      title: title.slice(0, 160),
      description: input.description?.slice(0, 600) ?? null,
      subjectId: input.subjectId ?? null,
      targetDate: input.targetDate || null,
      weeklyMinutes: clampInt(input.weeklyMinutes ?? 180, 30, 2400, 180),
      priority: clampInt(input.priority ?? 2, 1, 3, 2),
    })
    .returning({ id: goals.id });
  const goalId = inserted[0]?.id;
  if (goalId && input.firstMilestone?.trim()) {
    await db.insert(milestones).values({
      goalId,
      title: input.firstMilestone.trim().slice(0, 160),
      sortOrder: 1,
    });
  }
  refresh();
  return { ok: true as const, id: goalId };
}

export async function updateGoalStatus(id: number, status: "active" | "done" | "paused") {
  await ensureSeeded();
  await db.update(goals).set({ status }).where(eq(goals.id, id));
  refresh();
  return { ok: true as const };
}

export async function toggleMilestone(id: number, done: boolean) {
  await ensureSeeded();
  await db.update(milestones).set({ done }).where(eq(milestones.id, id));
  refresh();
  return { ok: true as const };
}

export async function addMilestone(goalId: number, title: string) {
  await ensureSeeded();
  const clean = title.trim();
  if (!clean) return { ok: false as const };
  const existing = await db
    .select({ sortOrder: milestones.sortOrder })
    .from(milestones)
    .where(eq(milestones.goalId, goalId));
  const nextOrder = existing.reduce((max, row) => Math.max(max, row.sortOrder), 0) + 1;
  await db.insert(milestones).values({ goalId, title: clean.slice(0, 160), sortOrder: nextOrder });
  refresh();
  return { ok: true as const };
}

export async function goalSuggestions() {
  await ensureSeeded();
  const activeGoals = await db
    .select()
    .from(goals)
    .where(eq(goals.status, "active"))
    .orderBy(goals.targetDate);
  return activeGoals
    .filter((goal) => goal.targetDate && daysBetweenISO(todayISO(), goal.targetDate) <= 30)
    .map((goal) => ({
      id: goal.id,
      title: goal.title,
      daysLeft: goal.targetDate ? daysBetweenISO(todayISO(), goal.targetDate) : null,
    }));
}

export async function shiftUnscheduledToTomorrow() {
  await ensureSeeded();
  const open = await db.select().from(tasks).where(eq(tasks.status, "todo"));
  const today = todayISO();
  for (const task of open) {
    if (task.dueDate && task.dueDate < today) {
      await db.update(tasks).set({ dueDate: addDaysISO(today, 1) }).where(eq(tasks.id, task.id));
    }
  }
  refresh();
  return { ok: true as const };
}


