import { LAYERS, PRESET_BY_ID, soundscapeName } from "@/lib/sound";

export function presetLabel(id: string | null | undefined): string {
  if (!id) return "Чимээгүй";
  return PRESET_BY_ID.get(id)?.name ?? soundscapeName(id);
}

export function layerLabel(id: string): string {
  return LAYERS.find((layer) => layer.id === id)?.name ?? id;
}

export const ENERGY_LABEL: Record<string, string> = {
  deep: "Гүн ажил",
  light: "Хөнгөн ажил",
  rest: "Амралт",
};

export const PRIORITY_TEXT: Record<number, string> = {
  1: "Бага",
  2: "Дунд",
  3: "Өндөр",
};

export const STATUS_TEXT: Record<string, string> = {
  todo: "Хийх",
  doing: "Хийж байгаа",
  done: "Дууссан",
};
