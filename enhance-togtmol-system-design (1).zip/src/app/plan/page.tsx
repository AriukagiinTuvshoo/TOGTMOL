import { getPlanData } from "@/lib/data";
import { Planner } from "@/components/plan/planner";
import { PageHeader } from "@/components/shell";
import { isValidISODate, todayISO } from "@/lib/date";

export const dynamic = "force-dynamic";

export default async function PlanPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string }>;
}) {
  const params = await searchParams;
  const date = isValidISODate(params.date) ? params.date : todayISO();
  const data = await getPlanData(date);

  return (
    <div>
      <PageHeader
        eyebrow="Цагийн систем"
        title="Өдрийн төлөвлөгөө"
        description="Ач холбогдол, эцсийн хугацаа, энергийн муруйгаар цагаа блокчил. Нэг товчоор бодит ачаалалд тааруулсан төлөвлөгөө гарга."
        actions={
          <>
            <span className="chip">
              {data.settings.dayStart} – {data.settings.dayEnd}
            </span>
            <span className="chip chip-accent">Гүн ажил {data.settings.deepStart}–{data.settings.deepEnd}</span>
          </>
        }
      />
      <Planner data={data} />
    </div>
  );
}
