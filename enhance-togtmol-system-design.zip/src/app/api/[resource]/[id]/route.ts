import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  subjects, notes, decks, cards, cardReviews, quizzes, quizAttempts,
  studySessions, goals, goalSteps, tasks, companionMoods, appSettings,
} from "@/db/schema";
import { eq } from "drizzle-orm";

const TABLES: Record<string, any> = {
  subjects,
  notes,
  decks,
  cards,
  card_reviews: cardReviews,
  quizzes,
  quiz_attempts: quizAttempts,
  study_sessions: studySessions,
  goals,
  goal_steps: goalSteps,
  tasks,
  companion_moods: companionMoods,
  app_settings: appSettings,
};

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  const { resource, id } = await params;
  const table = TABLES[resource];
  if (!table) return NextResponse.json({ error: "unknown" }, { status: 404 });
  const pk = resource === "app_settings" ? table.key : table.id;
  const rows = (await db.select().from(table).where(eq(pk, id)).limit(1)) as any[];
  if (!rows[0]) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json(rows[0]);
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  const { resource, id } = await params;
  const table = TABLES[resource];
  if (!table) return NextResponse.json({ error: "unknown" }, { status: 404 });
  try {
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const mapped: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(body)) {
      mapped[k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`)] = v;
    }
    const pk = resource === "app_settings" ? table.key : table.id;
    const rows = (await (db.update as any)(table).set(mapped).where(eq(pk, id)).returning()) as any[];
    return NextResponse.json(rows[0] ?? { ok: true });
  } catch (e) {
    console.error("PATCH", resource, e);
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ resource: string; id: string }> }
) {
  const { resource, id } = await params;
  const table = TABLES[resource];
  if (!table) return NextResponse.json({ error: "unknown" }, { status: 404 });
  try {
    const pk = resource === "app_settings" ? table.key : table.id;
    await db.delete(table).where(eq(pk, id));
    // cascade-ish: deleting deck removes its cards
    if (resource === "decks") await db.delete(cards).where(eq(cards.deckId, id));
    if (resource === "goals") await db.delete(goalSteps).where(eq(goalSteps.goalId, id));
    if (resource === "quizzes") await db.delete(quizAttempts).where(eq(quizAttempts.quizId, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("DELETE", resource, e);
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}
