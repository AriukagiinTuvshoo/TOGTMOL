// Tiny REST client over the generic /api/[resource] routes.
export type Resource =
  | "subjects" | "notes" | "decks" | "cards" | "card_reviews"
  | "quizzes" | "quiz_attempts" | "study_sessions"
  | "goals" | "goal_steps" | "tasks" | "companion_moods" | "app_settings";

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`API ${res.status}: ${t.slice(0, 200)}`);
  }
  return (await res.json()) as T;
}

export const api = {
  list: <T>(r: Resource, query = "") => req<T[]>(`/api/${r}${query}`),
  get: <T>(r: Resource, id: string) => req<T>(`/api/${r}/${id}`),
  create: <T>(r: Resource, body: unknown) =>
    req<T>(`/api/${r}`, { method: "POST", body: JSON.stringify(body) }),
  update: <T>(r: Resource, id: string, body: unknown) =>
    req<T>(`/api/${r}/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
  remove: (r: Resource, id: string) =>
    req<{ ok: boolean }>(`/api/${r}/${id}`, { method: "DELETE" }),
};
