import { cx } from "@/lib/utils";
import {
  formatDateShort,
  minutesLabel,
  percent,
  startOfWeekISO,
  weekdayLabel,
} from "@/lib/date";
import type { DayTotals, PlanBlock, Subject, SubjectStat } from "@/lib/types";
import { SubjectDot } from "@/components/ui";

export function Heatmap({ days, weeks = 14 }: { days: DayTotals[]; weeks?: number }) {
  const start = startOfWeekISO(days[0]?.date ?? new Date().toISOString().slice(0, 10));
  const cells = days.slice(-weeks * 7);
  const columns: DayTotals[][] = [];
  for (let index = 0; index < cells.length; index += 7) {
    columns.push(cells.slice(index, index + 7));
  }
  const level = (minutes: number) => {
    if (minutes <= 0) return 0;
    if (minutes < 25) return 1;
    if (minutes < 55) return 2;
    if (minutes < 90) return 3;
    return 4;
  };
  const backgrounds = [
    "rgba(255,255,255,0.055)",
    "rgba(201,247,90,0.22)",
    "rgba(201,247,90,0.42)",
    "rgba(201,247,90,0.68)",
    "rgba(201,247,90,0.95)",
  ];

  return (
    <div>
      <div className="flex gap-1.5">
        <div className="mr-1 flex flex-col justify-between py-0.5 text-[8.5px] font-semibold uppercase tracking-wider text-[var(--dim)]">
          {["Да", "", "Мя", "", "Пү", "", "Бя"].map((label, index) => (
            <span key={index} className="h-3 leading-3">
              {label}
            </span>
          ))}
        </div>
        <div className="flex flex-1 gap-1 overflow-hidden">
          {columns.map((column, columnIndex) => (
            <div key={columnIndex} className="flex flex-1 flex-col gap-1">
              {column.map((day) => (
                <span
                  key={day.date}
                  title={`${formatDateShort(day.date)} · ${minutesLabel(day.minutes)}`}
                  className="h-3 w-full rounded-[3px] transition hover:scale-110"
                  style={{ background: backgrounds[level(day.minutes)] }}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
      <div className="mt-2.5 flex items-center justify-between">
        <span className="text-[9.5px] text-[var(--dim)]">Сүүлийн {weeks} долоо хоног</span>
        <div className="flex items-center gap-1">
          <span className="mr-1 text-[9px] text-[var(--dim)]">Бага</span>
          {backgrounds.map((background, index) => (
            <span key={index} className="h-2 w-2 rounded-[2px]" style={{ background }} />
          ))}
          <span className="ml-1 text-[9px] text-[var(--dim)]">Их</span>
        </div>
      </div>
    </div>
  );
}

export function Bars({ days, target }: { days: DayTotals[]; target?: number }) {
  const max = Math.max(...days.map((day) => day.minutes), target ?? 0, 30);
  return (
    <div>
      <div className="flex h-28 items-end gap-1.5">
        {days.map((day) => {
          const height = Math.max(4, Math.round((day.minutes / max) * 100));
          const isToday = day.date === days[days.length - 1]?.date;
          return (
            <div key={day.date} className="group flex flex-1 flex-col items-center gap-1.5">
              <span className="mono text-[8.5px] text-[var(--dim)] opacity-0 transition group-hover:opacity-100">
                {day.minutes}
              </span>
              <div
                className={cx(
                  "w-full rounded-t-[4px] transition-all",
                  isToday
                    ? "bg-gradient-to-t from-[#6fa81e] to-[#d9ff8d]"
                    : "bg-gradient-to-t from-[rgba(201,247,90,0.18)] to-[rgba(201,247,90,0.55)] group-hover:from-[rgba(201,247,90,0.3)] group-hover:to-[rgba(201,247,90,0.85)]",
                )}
                style={{ height: `${height}%` }}
                title={`${weekdayLabel(day.date)} · ${minutesLabel(day.minutes)}`}
              />
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex justify-between text-[9px] font-semibold uppercase text-[var(--dim)]">
        {days.map((day) => (
          <span key={day.date} className="flex-1 text-center">
            {weekdayLabel(day.date, true)}
          </span>
        ))}
      </div>
    </div>
  );
}

export function Donut({
  subjects,
  total,
  size = 148,
}: {
  subjects: SubjectStat[];
  total?: number;
  size?: number;
}) {
  const sum = total ?? subjects.reduce((acc, subject) => acc + subject.minutes, 0);
  const active = subjects.filter((subject) => subject.minutes > 0);
  let cursor = 0;
  const stops = active
    .map((subject) => {
      const percentage = sum > 0 ? (subject.minutes / sum) * 100 : 0;
      const start = cursor;
      cursor += percentage;
      return `${subject.color} ${start}% ${cursor}%`;
    })
    .join(", ");
  const background =
    active.length > 0 ? `conic-gradient(from -90deg, ${stops})` : "rgba(255,255,255,0.08)";

  return (
    <div className="flex items-center gap-4">
      <div
        className="relative grid shrink-0 place-items-center rounded-full"
        style={{ width: size, height: size, background }}
      >
        <div className="grid place-items-center rounded-full bg-[#0b0e12] text-center" style={{ width: size - 30, height: size - 30 }}>
          <div>
            <p className="mono text-[19px] font-extrabold leading-none text-white">
              {Math.round(sum / 60 * 10) / 10}
            </p>
            <p className="mt-1 text-[9px] font-bold uppercase tracking-widest text-[var(--dim)]">цаг</p>
          </div>
        </div>
      </div>
      <div className="min-w-0 flex-1 space-y-2">
        {subjects.slice(0, 6).map((subject) => (
          <div key={subject.id} className="flex items-center gap-2">
            <SubjectDot color={subject.color} />
            <span className="min-w-0 flex-1 truncate text-[11.5px] text-[#c6cede]">{subject.name}</span>
            <span className="mono text-[10.5px] text-[var(--muted)]">{minutesLabel(subject.minutes)}</span>
          </div>
        ))}
        {sum === 0 ? <p className="text-[11px] text-[var(--dim)]">Энэ долоо хоногт бүртгэл алга.</p> : null}
      </div>
    </div>
  );
}

export function MiniTimeline({
  blocks,
  subjects,
  emptyHint,
}: {
  blocks: PlanBlock[];
  subjects: Subject[];
  emptyHint?: string;
}) {
  if (blocks.length === 0) {
    return (
      <p className="rounded-xl border border-dashed border-[var(--line-strong)] px-3 py-5 text-center text-[11.5px] text-[var(--dim)]">
        {emptyHint ?? "Өнөөдөр төлөвлөсөн блок алга."}
      </p>
    );
  }
  return (
    <div className="space-y-2">
      {blocks.slice(0, 6).map((block) => {
        const subject = subjects.find((item) => item.id === block.subjectId);
        const color = block.kind === "break" ? "#5eead4" : subject?.color ?? "#94a3b8";
        return (
          <div
            key={block.id}
            className="flex items-center gap-3 rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2"
          >
            <span className="mono w-[86px] shrink-0 text-[10.5px] text-[var(--muted)]">
              {block.startLabel}–{block.endLabel}
            </span>
            <span className="h-7 w-[3px] shrink-0 rounded-full" style={{ background: color }} />
            <span className="min-w-0 flex-1 truncate text-[12px] font-semibold text-[#dde3ec]">
              {block.title}
            </span>
            <span className="hidden shrink-0 text-[10px] text-[var(--dim)] sm:block">
              {block.kind === "break" ? "Амралт" : minutesLabel(block.endMinute - block.startMinute)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export function SubjectProgress({ subject }: { subject: SubjectStat }) {
  const percentage = percent(subject.minutes, subject.target);
  return (
    <div>
      <div className="flex items-center justify-between gap-2">
        <span className="flex min-w-0 items-center gap-1.5">
          <SubjectDot color={subject.color} />
          <span className="truncate text-[11px] font-semibold text-[#c6cede]">{subject.name}</span>
        </span>
        <span className="mono shrink-0 text-[10px] text-[var(--dim)]">
          {minutesLabel(subject.minutes)}/{minutesLabel(subject.target)}
        </span>
      </div>
      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/8">
        <div
          className="h-full rounded-full"
          style={{ width: `${Math.min(100, percentage)}%`, background: subject.color }}
        />
      </div>
    </div>
  );
}

export const chartClass = cx("w-full");
