"use client";

import { cx } from "@/lib/utils";
import { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  applyAutoPlan,
  clearDayPlan,
  createTask,
  deleteTask,
  previewAutoPlan,
  scheduleTask,
  toggleTaskDone,
  unscheduleTask,
  updateTask,
} from "@/app/actions";
import { Modal, Progress, SectionHeading, SubjectDot, Toast } from "@/components/ui";
import {
  addDaysISO,
  clockLabel,
  formatDateLong,
  minutesLabel,
  minutesOfDayFromClock,
  nowMinuteOfDay,
  percent,
  relativeDayLabel,
  todayISO,
} from "@/lib/date";
import { PRIORITY_TEXT } from "@/lib/labels";
import type { PlanBlock, PlanData, Task } from "@/lib/types";

const HOUR_HEIGHT = 62;

type Preview = {
  blocks: PlanBlock[];
  unplacedTitles: string[];
  loadMinutes: number;
  deepMinutes: number;
  breaks: number;
  windowLabel: string;
};

type TaskForm = {
  title: string;
  notes: string;
  subjectId: string;
  goalId: string;
  estimate: string;
  priority: string;
  energy: "deep" | "light";
  dueDate: string;
  startTime: string;
  scheduledDate: string;
};

const emptyForm = (date: string): TaskForm => ({
  title: "",
  notes: "",
  subjectId: "",
  goalId: "",
  estimate: "30",
  priority: "2",
  energy: "deep",
  dueDate: "",
  startTime: "",
  scheduledDate: date,
});

function taskToForm(task: Task, date: string): TaskForm {
  return {
    title: task.title,
    notes: task.notes ?? "",
    subjectId: task.subjectId ? String(task.subjectId) : "",
    goalId: task.goalId ? String(task.goalId) : "",
    estimate: String(task.estimateMinutes),
    priority: String(task.priority),
    energy: task.energy,
    dueDate: task.dueDate ?? "",
    startTime: task.startLabel ?? "",
    scheduledDate: task.scheduledStart?.slice(0, 10) ?? date,
  };
}

function nextFreeMinute(blocks: PlanBlock[], estimate: number, date: string, settings: PlanData["settings"]): number {
  const dayStart = minutesOfDayFromClock(settings.dayStart);
  const dayEnd = minutesOfDayFromClock(settings.dayEnd);
  let cursor = date === todayISO() ? Math.max(dayStart, Math.ceil((nowMinuteOfDay() + 5) / 5) * 5) : dayStart;
  const sorted = [...blocks].sort((a, b) => a.startMinute - b.startMinute);
  for (const block of sorted) {
    if (cursor + estimate <= block.startMinute) return cursor;
    cursor = Math.max(cursor, block.endMinute + 5);
  }
  if (cursor + estimate > dayEnd) return dayStart;
  return cursor;
}

export function Planner({ data }: { data: PlanData }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [form, setForm] = useState<TaskForm>(emptyForm(data.date));
  const [preview, setPreview] = useState<Preview | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [reschedule, setReschedule] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [quickTitle, setQuickTitle] = useState("");
  const [filter, setFilter] = useState<number | "all">("all");

  const now = nowMinuteOfDay();
  const rangeStart = Math.max(0, Math.min(minutesOfDayFromClock(data.settings.dayStart) - 60, 8 * 60));
  const rangeEnd = Math.max(rangeStart + 480, Math.min(24 * 60, minutesOfDayFromClock(data.settings.dayEnd) + 60));
  const hours = useMemo(() => {
    const list: number[] = [];
    for (let minute = Math.floor(rangeStart / 60) * 60; minute <= rangeEnd; minute += 60) list.push(minute);
    return list;
  }, [rangeEnd, rangeStart]);

  const scheduledTasks = data.tasks.filter((task) => task.startLabel && task.endLabel);
  const loadMinutes = scheduledTasks.reduce((sum, task) => sum + task.estimateMinutes, 0);
  const deepMinutes = scheduledTasks
    .filter((task) => task.energy === "deep")
    .reduce((sum, task) => sum + task.estimateMinutes, 0);
  const completedToday = data.tasks.filter(
    (task) => task.status === "done" && task.completedAt?.slice(0, 10) === data.date,
  ).length;
  const openBacklog = data.unscheduled.filter(
    (task) => filter === "all" || task.subjectId === filter,
  );
  const activeGoals = data.goals.filter((goal) => goal.status === "active");
  const nextFree = nextFreeMinute(data.blocks, 30, data.date, data.settings);

  const flash = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2600);
  };

  const openCreate = (startMinute?: number) => {
    setEditing(null);
    setForm({
      ...emptyForm(data.date),
      startTime: startMinute !== undefined ? clockLabel(startMinute) : "",
    });
    setFormOpen(true);
  };

  const openEdit = (task: Task) => {
    setEditing(task);
    setForm(taskToForm(task, data.date));
    setFormOpen(true);
  };

  const submitForm = () => {
    if (!form.title.trim()) return;
    startTransition(async () => {
      const payload = {
        title: form.title,
        notes: form.notes || null,
        subjectId: form.subjectId ? Number(form.subjectId) : null,
        goalId: form.goalId ? Number(form.goalId) : null,
        estimateMinutes: Number(form.estimate) || 30,
        priority: Number(form.priority) || 2,
        energy: form.energy,
        dueDate: form.dueDate || null,
        scheduledDate: form.startTime ? form.scheduledDate : null,
        scheduledMinute: form.startTime ? minutesOfDayFromClock(form.startTime) : null,
      };
      if (editing) {
        await updateTask(editing.id, payload);
      } else {
        await createTask(payload);
      }
      setFormOpen(false);
      flash(editing ? "Ажил шинэчлэгдлээ." : "Ажил нэмэгдлээ.");
      router.refresh();
    });
  };

  const handleQuickAdd = () => {
    if (!quickTitle.trim()) return;
    startTransition(async () => {
      await createTask({
        title: quickTitle,
        subjectId: filter === "all" ? null : filter,
        estimateMinutes: 30,
        priority: 2,
        energy: "deep",
        dueDate: data.date,
      });
      setQuickTitle("");
      flash("Хүлээгдэж буй ажилд нэмэгдлээ.");
      router.refresh();
    });
  };

  const doPreview = async (withReschedule: boolean) => {
    setReschedule(withReschedule);
    setPreviewLoading(true);
    setPreviewOpen(true);
    try {
      const result = await previewAutoPlan(data.date, withReschedule);
      setPreview(result);
    } catch {
      flash("Төлөвлөгч ажиллахад алдаа гарлаа.");
    } finally {
      setPreviewLoading(false);
    }
  };

  const doApply = () => {
    startTransition(async () => {
      const result = await applyAutoPlan(data.date, reschedule);
      setPreviewOpen(false);
      flash(`${result.placed} блок байрлалаа${result.unplaced ? ` · ${result.unplaced} ажил үлдсэн` : ""}.`);
      router.refresh();
    });
  };

  const quickSchedule = (task: Task) => {
    startTransition(async () => {
      await scheduleTask(task.id, data.date, nextFree);
      flash(`${task.title} → ${clockLabel(nextFree)}`);
      router.refresh();
    });
  };

  const openEditForSchedule = (task: Task) => {
    setEditing(task);
    setForm({
      ...taskToForm(task, data.date),
      startTime: clockLabel(nextFree),
      scheduledDate: data.date,
    });
    setFormOpen(true);
  };

  return (
    <div className="space-y-4">
      <div className="panel flex flex-wrap items-center justify-between gap-2.5 p-3">
        <div className="flex items-center gap-1.5">
          <Link href={`/plan?date=${addDaysISO(data.date, -1)}`} className="btn btn-icon btn-ghost" aria-label="Өмнөх өдөр">
            ←
          </Link>
          <Link href={`/plan?date=${addDaysISO(data.date, 1)}`} className="btn btn-icon btn-ghost" aria-label="Дараагийн өдөр">
            →
          </Link>
          <div className="ml-1">
            <p className="text-[13px] font-bold text-white">
              {data.isToday ? "Өнөөдөр" : relativeDayLabel(data.date)}
            </p>
            <p className="text-[10.5px] text-[var(--dim)]">{formatDateLong(data.date)}</p>
          </div>
          {!data.isToday ? (
            <Link href="/plan" className="chip ml-2 hover:border-white/30">
              Өнөөдөр
            </Link>
          ) : null}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={() => void doPreview(false)} className="btn btn-primary" disabled={pending}>
            ✨ Ухаалаг төлөвлөх
          </button>
          <button type="button" onClick={() => openCreate()} className="btn btn-ghost">
            + Ажил
          </button>
          <button
            type="button"
            onClick={() => {
              startTransition(async () => {
                await clearDayPlan(data.date);
                flash("Өдрийн блок цэвэрлэгдлээ.");
                router.refresh();
              });
            }}
            className="btn btn-ghost btn-icon"
            title="Өдрийн төлөвлөгөө цэвэрлэх"
            disabled={pending || data.blocks.length === 0}
          >
            ⌫
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Блоклогдсон</p>
          <p className="mono mt-1 text-[18px] font-bold text-white">
            {minutesLabel(loadMinutes)}
            <span className="text-[10px] text-[var(--dim)]"> / {minutesLabel(data.capacityMinutes)}</span>
          </p>
          <Progress className="mt-2" value={percent(loadMinutes, data.capacityMinutes)} height={4} />
        </div>
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Гүн ажил</p>
          <p className="mono mt-1 text-[18px] font-bold text-[var(--lime)]">{minutesLabel(deepMinutes)}</p>
          <p className="mt-1 text-[10px] text-[var(--dim)]">
            Цонх {data.settings.deepStart}–{data.settings.deepEnd}
          </p>
        </div>
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Чөлөөт цаг</p>
          <p className="mono mt-1 text-[18px] font-bold text-[var(--mint)]">
            {minutesLabel(Math.max(0, data.capacityMinutes - loadMinutes))}
          </p>
          <p className="mt-1 text-[10px] text-[var(--dim)]">Сэргээхэд зориулсан нөөц</p>
        </div>
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Гүйцэтгэл</p>
          <p className="mono mt-1 text-[18px] font-bold text-[var(--violet)]">
            {completedToday}
            <span className="text-[10px] text-[var(--dim)]"> / {scheduledTasks.length}</span>
          </p>
          <p className="mt-1 text-[10px] text-[var(--dim)]">Өнөөдрийн блок</p>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-4">
          <div className="panel p-4 sm:p-5">
            <SectionHeading
              label="Цагийн зураглал"
              title={data.dateLabel}
              hint={`${data.blocks.length} блок · ${minutesLabel(loadMinutes)} ачаалал`}
              action={
                <button type="button" onClick={() => openCreate(nextFree)} className="chip hover:border-white/30">
                  {clockLabel(nextFree)} → нэмэх
                </button>
              }
            />

            <div className="mt-4 overflow-hidden rounded-2xl border border-[var(--line)] bg-black/20">
              <div
                className="relative"
                style={{ height: ((rangeEnd - rangeStart) / 60) * HOUR_HEIGHT }}
              >
                {hours.map((minute) => (
                  <div
                    key={minute}
                    className="absolute inset-x-0 flex items-start"
                    style={{ top: ((minute - rangeStart) / 60) * HOUR_HEIGHT }}
                  >
                    <span className="mono w-[54px] shrink-0 -translate-y-1.5 pr-2 text-right text-[9.5px] text-[var(--dim)]">
                      {clockLabel(minute)}
                    </span>
                    <span className="mt-0.5 h-px flex-1 bg-white/[0.06]" />
                  </div>
                ))}

                {data.isToday && now >= rangeStart && now <= rangeEnd ? (
                  <div
                    className="pointer-events-none absolute inset-x-0 z-20"
                    style={{ top: ((now - rangeStart) / 60) * HOUR_HEIGHT }}
                  >
                    <div className="flex items-center">
                      <span className="mono w-[54px] shrink-0 pr-2 text-right text-[9px] font-bold text-[var(--lime)]">
                        {clockLabel(now)}
                      </span>
                      <span className="h-px flex-1 bg-[var(--lime)]/70" />
                      <span className="ml-1 h-1.5 w-1.5 rounded-full bg-[var(--lime)]" />
                    </div>
                  </div>
                ) : null}

                {data.blocks.map((block) => {
                  const top = ((block.startMinute - rangeStart) / 60) * HOUR_HEIGHT;
                  const height = Math.max(30, ((block.endMinute - block.startMinute) / 60) * HOUR_HEIGHT - 4);
                  const subject = data.subjects.find((item) => item.id === block.subjectId);
                  const task = data.tasks.find((item) => item.id === block.taskId);
                  const color = block.kind === "break" ? "#5eead4" : subject?.color ?? "#94a3b8";
                  const isDone = task?.status === "done";
                  return (
                    <button
                      key={block.id}
                      type="button"
                      disabled={!task}
                      onClick={() => task && openEdit(task)}
                      className={cx(
                        "timeline-block absolute left-[60px] right-2 overflow-hidden rounded-lg border px-2.5 py-1.5 text-left",
                        task ? "cursor-pointer" : "cursor-default",
                        isDone && "opacity-55",
                      )}
                      style={{
                        top,
                        height,
                        borderColor: `${color}55`,
                        background: `linear-gradient(100deg, ${color}2b, ${color}12 55%, rgba(255,255,255,0.02))`,
                        boxShadow: `inset 3px 0 0 ${color}`,
                      }}
                      title={`${block.startLabel}–${block.endLabel} · ${block.title}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p
                            className={cx(
                              "truncate text-[11.5px] font-bold leading-tight text-white",
                              isDone && "line-through",
                            )}
                          >
                            {block.title}
                          </p>
                          <p className="mono mt-0.5 truncate text-[9.5px] text-white/55">
                            {block.startLabel}–{block.endLabel} · {block.kind === "break" ? "Амралт" : `${block.endMinute - block.startMinute}м`}
                          </p>
                        </div>
                        {block.kind !== "break" ? (
                          <span className="shrink-0 text-[8.5px] font-bold uppercase tracking-wider text-white/45">
                            {block.energy === "deep" ? "ГҮН" : "ХӨНГӨН"}
                          </span>
                        ) : null}
                      </div>
                    </button>
                  );
                })}

                {data.blocks.length === 0 ? (
                  <div className="absolute inset-x-4 top-16 rounded-xl border border-dashed border-[var(--line-strong)] bg-black/30 p-4 text-center">
                    <p className="text-[12px] font-semibold text-white">Энэ өдөр блокгүй байна</p>
                    <p className="mx-auto mt-1 max-w-xs text-[10.5px] leading-relaxed text-[var(--dim)]">
                      «Ухаалаг төлөвлөх» дарвал ач холбогдол, хугацаа, энергийн муруйгаар цагийг
                      автоматаар хуваарилна.
                    </p>
                  </div>
                ) : null}
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-3 text-[10px] text-[var(--dim)]">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-sm bg-[var(--lime)]" /> Гүн ажил
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-sm bg-[var(--mint)]" /> Амралт
              </span>
              {data.subjects.slice(0, 5).map((subject) => (
                <span key={subject.id} className="flex items-center gap-1.5">
                  <SubjectDot color={subject.color} size={7} /> {subject.name}
                </span>
              ))}
            </div>
          </div>

          <div className="panel p-4 sm:p-5">
            <SectionHeading
              label="Бүртгэл"
              title="Энэ өдрийн анхаарал"
              hint={`${data.sessions.filter((session) => session.mode === "focus").length} сесс · ${minutesLabel(data.dayMinutes)}`}
            />
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {data.sessions.length > 0 ? (
                data.sessions.map((session) => (
                  <div key={session.id} className="flex items-center gap-2.5 rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2">
                    <span className="mono text-[10px] text-[var(--dim)]">{session.timeLabel}</span>
                    <SubjectDot color={session.subjectColor ?? "#94a3b8"} size={7} />
                    <span className="min-w-0 flex-1 truncate text-[11px] text-[#d6dde8]">
                      {session.taskTitle ?? session.subjectName ?? "Чөлөөт анхаарал"}
                    </span>
                    <span className="mono text-[10px] font-semibold text-white">
                      {minutesLabel(session.actualSeconds / 60)}
                    </span>
                  </div>
                ))
              ) : (
                <p className="col-span-2 rounded-xl border border-dashed border-[var(--line-strong)] px-3 py-4 text-center text-[11px] text-[var(--dim)]">
                  Энэ өдөр бүртгэгдсэн сесс алга.
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="panel p-4">
            <SectionHeading
              label="Хүлээгдэж буй"
              title={`${data.unscheduled.length} ажил`}
              hint={`Дараагийн чөлөөт цонх ${clockLabel(nextFree)}`}
            />
            <div className="mt-3">
              <div className="flex gap-1.5 overflow-x-auto pb-1 scroll-thin">
                <button
                  type="button"
                  onClick={() => setFilter("all")}
                  className={cx(
                    "shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-bold",
                    filter === "all"
                      ? "border-[rgba(201,247,90,0.4)] bg-[rgba(201,247,90,0.12)] text-[var(--lime)]"
                      : "border-[var(--line)] text-[var(--muted)]",
                  )}
                >
                  Бүгд
                </button>
                {data.subjects.map((subject) => (
                  <button
                    key={subject.id}
                    type="button"
                    onClick={() => setFilter(subject.id)}
                    className={cx(
                      "flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold",
                      filter === subject.id
                        ? "border-white/35 bg-white/[0.08] text-white"
                        : "border-[var(--line)] text-[var(--muted)]",
                    )}
                  >
                    <SubjectDot color={subject.color} size={6} /> {subject.name}
                  </button>
                ))}
              </div>

              <div className="mt-2.5 max-h-[420px] space-y-2 overflow-y-auto pr-1 scroll-thin">
                {openBacklog.length > 0 ? (
                  openBacklog.map((task) => {
                    const subject = data.subjects.find((item) => item.id === task.subjectId);
                    const overdue = task.dueDate !== null && task.dueDate < todayISO();
                    return (
                      <div key={task.id} className="rounded-xl border border-[var(--line)] bg-white/[0.028] p-2.5">
                        <div className="flex items-start gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              startTransition(async () => {
                                await toggleTaskDone(task.id, true);
                                router.refresh();
                              });
                            }}
                            className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-[5px] border border-white/25 text-[9px] text-transparent transition hover:border-[var(--lime)] hover:text-[var(--lime)]"
                            aria-label={`${task.title} дуусгах`}
                          >
                            ✓
                          </button>
                          <button
                            type="button"
                            onClick={() => openEditForSchedule(task)}
                            className="min-w-0 flex-1 text-left"
                          >
                            <p className="truncate text-[11.5px] font-semibold text-[#e2e8f0]">{task.title}</p>
                            <p className="mt-0.5 flex flex-wrap items-center gap-2 text-[9.5px] text-[var(--dim)]">
                              <SubjectDot color={subject?.color ?? "#94a3b8"} size={6} />
                              {task.estimateMinutes}м · P{task.priority}
                              {task.dueDate ? (
                                <span className={overdue ? "font-bold text-[var(--rose)]" : ""}>
                                  {overdue ? "Хугацаа хэтэрсэн" : relativeDayLabel(task.dueDate)}
                                </span>
                              ) : null}
                            </p>
                          </button>
                          <button
                            type="button"
                            onClick={() => quickSchedule(task)}
                            className="chip shrink-0"
                            title={`${clockLabel(nextFree)}-д төлөвлөх`}
                          >
                            {clockLabel(nextFree)}
                          </button>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p className="rounded-xl border border-dashed border-[var(--line-strong)] px-3 py-5 text-center text-[11px] text-[var(--dim)]">
                    Хүлээгдэж буй ажил алга. Шинэ ажил нэмээрэй.
                  </p>
                )}
              </div>

              <div className="mt-2.5 flex gap-1.5">
                <input
                  className="input"
                  placeholder="Шуурхай ажил нэмэх…"
                  value={quickTitle}
                  onChange={(event) => setQuickTitle(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") handleQuickAdd();
                  }}
                />
                <button type="button" className="btn btn-ghost px-3" onClick={handleQuickAdd} disabled={pending}>
                  +
                </button>
              </div>
              <button type="button" className="btn btn-ghost mt-2 w-full" onClick={() => openCreate(nextFree)}>
                Дэлгэрэнгүй ажил нэмэх
              </button>
            </div>
          </div>

          <div className="panel p-4">
            <SectionHeading
              label="Урт хугацаа"
              title="Зорилгын ачаалал"
              action={
                <Link href="/goals" className="text-[10px] font-semibold text-[var(--muted)] hover:text-white">
                  Бүгд →
                </Link>
              }
            />
            <div className="mt-3 space-y-3">
              {activeGoals.slice(0, 4).map((goal) => {
                const subject = data.subjects.find((item) => item.id === goal.subjectId);
                const done = goal.milestones.filter((milestone) => milestone.done).length;
                const goalPercent = percent(done, goal.milestones.length || 1);
                return (
                  <div key={goal.id}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex min-w-0 items-center gap-1.5">
                        <SubjectDot color={subject?.color ?? "#94a3b8"} size={7} />
                        <p className="truncate text-[11px] font-semibold text-[#dde3ec]">{goal.title}</p>
                      </div>
                      <span className="mono shrink-0 text-[9.5px] text-[var(--dim)]">
                        {done}/{goal.milestones.length}
                      </span>
                    </div>
                    <Progress className="mt-1.5" value={goalPercent} height={4} />
                  </div>
                );
              })}
            </div>
            {data.overloadedTasks.length > 0 ? (
              <div className="mt-3 rounded-xl border border-[rgba(253,164,175,0.3)] bg-[rgba(253,164,175,0.08)] px-3 py-2.5">
                <p className="text-[10.5px] font-bold text-[#fecdd3]">
                  {data.overloadedTasks.length} ажлын хугацаа хэтэрсэн
                </p>
                <p className="mt-0.5 text-[10px] leading-relaxed text-[#fda4af]/80">
                  Тэдгээрийг өнөөдрийн эхний блокт байрлуулж, үлдсэнийг маргааш руу шилжүүл.
                </p>
              </div>
            ) : null}
          </div>

          <div className="panel p-4">
            <SectionHeading label="Амбиент" title="Ажлын дуу" />
            <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">
              Блок бүрийг дуугаар холбо. Анхаарлын өрөөнд 11 давхаргат амбиент микс болон
              дараагийн сессийн тохиргоо бэлэн.
            </p>
            <Link href="/focus" className="btn btn-primary mt-3 w-full">
              Анхаарлын өрөө
            </Link>
          </div>
        </div>
      </div>

      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={editing ? "Ажил засах" : "Шинэ ажил"}
        subtitle={editing ? editing.title : "Тооцоо, ач холбогдол, энергийн төрлийг зөв өгвөл төлөвлөгч илүү ухаалаг ажиллана."}
        wide
        footer={
          <>
            {editing ? (
              <button
                type="button"
                className="btn btn-danger mr-auto"
                onClick={() => {
                  startTransition(async () => {
                    await deleteTask(editing.id);
                    setFormOpen(false);
                    flash("Ажил устгагдлаа.");
                    router.refresh();
                  });
                }}
              >
                Устгах
              </button>
            ) : null}
            <button type="button" className="btn btn-ghost" onClick={() => setFormOpen(false)}>
              Болих
            </button>
            <button type="button" className="btn btn-primary" onClick={submitForm} disabled={pending || !form.title.trim()}>
              {pending ? "Хадгалж байна…" : editing ? "Хадгалах" : "Ажил нэмэх"}
            </button>
          </>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="label" htmlFor="task-title">
              Гарчиг
            </label>
            <input
              id="task-title"
              className="input mt-1.5"
              placeholder="Жишээ: Интегралын 20 бодлого"
              value={form.title}
              onChange={(event) => setForm({ ...form, title: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="task-subject">
              Сэдэв
            </label>
            <select
              id="task-subject"
              className="select mt-1.5"
              value={form.subjectId}
              onChange={(event) => setForm({ ...form, subjectId: event.target.value })}
            >
              <option value="">Сэдэвгүй</option>
              {data.subjects.map((subject) => (
                <option key={subject.id} value={subject.id}>
                  {subject.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="task-goal">
              Зорилго
            </label>
            <select
              id="task-goal"
              className="select mt-1.5"
              value={form.goalId}
              onChange={(event) => setForm({ ...form, goalId: event.target.value })}
            >
              <option value="">Зорилгогүй</option>
              {data.goals.map((goal) => (
                <option key={goal.id} value={goal.id}>
                  {goal.title}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="task-estimate">
              Тооцоо (минут)
            </label>
            <input
              id="task-estimate"
              type="number"
              min={5}
              max={480}
              step={5}
              className="input mt-1.5"
              value={form.estimate}
              onChange={(event) => setForm({ ...form, estimate: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="task-priority">
              Ач холбогдол
            </label>
            <select
              id="task-priority"
              className="select mt-1.5"
              value={form.priority}
              onChange={(event) => setForm({ ...form, priority: event.target.value })}
            >
              {[3, 2, 1].map((value) => (
                <option key={value} value={value}>
                  {PRIORITY_TEXT[value]}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="task-energy">
              Энерги
            </label>
            <select
              id="task-energy"
              className="select mt-1.5"
              value={form.energy}
              onChange={(event) => setForm({ ...form, energy: event.target.value as "deep" | "light" })}
            >
              <option value="deep">Гүн ажил — өглөө</option>
              <option value="light">Хөнгөн ажил — орой</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="task-due">
              Эцсийн хугацаа
            </label>
            <input
              id="task-due"
              type="date"
              className="input mt-1.5"
              value={form.dueDate}
              onChange={(event) => setForm({ ...form, dueDate: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="task-date">
              Блок өдөр
            </label>
            <input
              id="task-date"
              type="date"
              className="input mt-1.5"
              value={form.scheduledDate}
              onChange={(event) => setForm({ ...form, scheduledDate: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="task-time">
              Эхлэх цаг
            </label>
            <input
              id="task-time"
              type="time"
              className="input mt-1.5"
              value={form.startTime}
              onChange={(event) => setForm({ ...form, startTime: event.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="task-notes">
              Тэмдэглэл
            </label>
            <textarea
              id="task-notes"
              rows={2}
              className="textarea mt-1.5"
              placeholder="Юу хийхээ тодорхой бич…"
              value={form.notes}
              onChange={(event) => setForm({ ...form, notes: event.target.value })}
            />
          </div>
          {editing ? (
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => {
                  startTransition(async () => {
                    await unscheduleTask(editing.id);
                    setFormOpen(false);
                    flash("Блокоос гаргалаа.");
                    router.refresh();
                  });
                }}
              >
                Блокоос гаргах
              </button>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => {
                  startTransition(async () => {
                    await toggleTaskDone(editing.id, true);
                    setFormOpen(false);
                    flash("Ажил дууссан гэж тэмдэглэгдлээ.");
                    router.refresh();
                  });
                }}
              >
                Дууссан гэж тэмдэглэх
              </button>
            </div>
          ) : null}
        </div>
      </Modal>

      <Modal
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        title="Ухаалаг төлөвлөгөө"
        subtitle="Ач холбогдол, эцсийн хугацаа, гүн ажлын цонхыг харгалзсан санал."
        wide
        footer={
          <>
            <button
              type="button"
              className="btn btn-ghost mr-auto"
              onClick={() => void doPreview(!reschedule)}
              disabled={previewLoading}
            >
              {reschedule ? "Одоогийн блок хадгалах" : "Бүгдийг дахин хуваарилах"}
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => setPreviewOpen(false)}>
              Болих
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={doApply}
              disabled={previewLoading || !preview || preview.blocks.length === 0 || pending}
            >
              {pending ? "Байршуулж байна…" : "Төлөвлөгөөг хэрэгжүүлэх"}
            </button>
          </>
        }
      >
        {previewLoading || !preview ? (
          <div className="space-y-2">
            {Array.from({ length: 4 }).map((_, index) => (
              <div key={index} className="h-12 animate-pulse rounded-xl bg-white/[0.05]" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2">
                <p className="label">Цонх</p>
                <p className="mono mt-1 text-[12px] text-white">{preview.windowLabel}</p>
              </div>
              <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2">
                <p className="label">Ачаалал</p>
                <p className="mono mt-1 text-[12px] text-[var(--lime)]">{minutesLabel(preview.loadMinutes)}</p>
              </div>
              <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2">
                <p className="label">Гүн ажил</p>
                <p className="mono mt-1 text-[12px] text-[var(--violet)]">{minutesLabel(preview.deepMinutes)}</p>
              </div>
              <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2">
                <p className="label">Амралт</p>
                <p className="mono mt-1 text-[12px] text-[var(--mint)]">{preview.breaks}</p>
              </div>
            </div>

            <div className="max-h-[320px] space-y-1.5 overflow-y-auto pr-1 scroll-thin">
              {preview.blocks.map((block) => {
                const subject = data.subjects.find((item) => item.id === block.subjectId);
                return (
                  <div
                    key={block.id}
                    className="flex items-center gap-2.5 rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2"
                  >
                    <span className="mono w-[92px] shrink-0 text-[10.5px] text-white/70">
                      {block.startLabel}–{block.endLabel}
                    </span>
                    <span
                      className="h-5 w-[3px] shrink-0 rounded-full"
                      style={{ background: block.kind === "break" ? "#5eead4" : subject?.color ?? "#94a3b8" }}
                    />
                    <span className="min-w-0 flex-1 truncate text-[11.5px] text-[#e2e8f0]">{block.title}</span>
                    <span className="hidden shrink-0 text-[9.5px] text-[var(--dim)] sm:block">{block.reason}</span>
                  </div>
                );
              })}
            </div>

            {preview.unplacedTitles.length > 0 ? (
              <div className="rounded-xl border border-[rgba(252,211,77,0.3)] bg-[rgba(252,211,77,0.08)] px-3 py-2.5">
                <p className="text-[10.5px] font-bold text-[#fde68a]">
                  Багтахгүй {preview.unplacedTitles.length} ажил — өдрийн цонх дүүрсэн
                </p>
                <p className="mt-0.5 line-clamp-2 text-[10px] text-[#fcd34d]/80">
                  {preview.unplacedTitles.join(" · ")}
                </p>
              </div>
            ) : (
              <p className="text-[10.5px] text-[var(--dim)]">
                Бүх ажил багтлаа. Хэрэгжүүлсний дараа анхаарлын өрөөнөөс шууд эхлээрэй.
              </p>
            )}
          </div>
        )}
      </Modal>

      {toast ? <Toast message={toast} /> : null}
    </div>
  );
}
