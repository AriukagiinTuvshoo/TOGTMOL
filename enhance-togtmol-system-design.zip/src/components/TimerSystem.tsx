"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Play, Pause, Square, RotateCcw, Timer, Hourglass, Infinity as InfinityIcon,
  Waves, Bell, BellOff, Zap, Plus, Minus, BookOpen, CheckCircle2,
} from "lucide-react";
import { fmtClock, focusScore } from "@/lib/focus";
import { engine } from "@/lib/audio-engine";
import { api } from "@/lib/api";
import type { Subject } from "@/db/schema";

export type TimerMode = "pomodoro" | "stopwatch" | "countdown" | "flowtime";

const POMODORO_PRESETS = [
  { label: "25/5", focus: 25, break: 5, desc: "Хөнгөн" },
  { label: "50/10", focus: 50, break: 10, desc: "Гүн" },
  { label: "90/20", focus: 90, break: 20, desc: "Урсгал" },
];

interface Props {
  subjects: Subject[];
  roomId: string;
  accent: string;
  onSessionComplete: (info: { seconds: number; score: number; xp: number; completed: boolean }) => void;
  onRunningChange?: (running: boolean) => void;
}

export default function TimerSystem({ subjects, roomId, accent, onSessionComplete, onRunningChange }: Props) {
  const [mode, setMode] = useState<TimerMode>("pomodoro");
  const [preset, setPreset] = useState(1); // 50/10 default
  const [customMin, setCustomMin] = useState(50);
  const [subjectId, setSubjectId] = useState<string>("");
  const [phase, setPhase] = useState<"focus" | "break">("focus");
  const [status, setStatus] = useState<"idle" | "running" | "paused">("idle");
  const [elapsed, setElapsed] = useState(0); // seconds elapsed in current phase
  const [interruptions, setInterruptions] = useState(0);
  const [soundOn, setSoundOn] = useState(true);
  const [cycle, setCycle] = useState(1);
  const [note, setNote] = useState("");
  const [lastResult, setLastResult] = useState<string | null>(null);

  const endAtRef = useRef(0);
  const elapsedRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const wakeLockRef = useRef<any>(null);
  const sessionStartRef = useRef<Date>(new Date());
  const totalFocusRef = useRef(0);

  const focusLen = mode === "pomodoro" ? POMODORO_PRESETS[preset].focus * 60 : customMin * 60;
  const breakLen = mode === "pomodoro" ? POMODORO_PRESETS[preset].break * 60 : 5 * 60;
  const planned = phase === "focus" ? focusLen : mode === "pomodoro" ? breakLen : focusLen;
  const isCountUp = mode === "stopwatch" || mode === "flowtime";

  const display = isCountUp ? elapsed : Math.max(0, planned - elapsed);
  const progress = isCountUp
    ? Math.min(1, elapsed / (customMin * 60 || 3600))
    : planned > 0 ? Math.min(1, elapsed / planned) : 0;

  const requestWake = useCallback(async () => {
    try {
      const nav = navigator as any;
      if (nav.wakeLock) wakeLockRef.current = await nav.wakeLock.request("screen");
    } catch { /* noop */ }
  }, []);
  const releaseWake = useCallback(() => {
    try { wakeLockRef.current?.release?.(); } catch { /* noop */ }
    wakeLockRef.current = null;
  }, []);

  const notify = useCallback((title: string, body: string) => {
    try {
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification(title, { body });
      }
    } catch { /* noop */ }
  }, []);

  useEffect(() => {
    try {
      if ("Notification" in window && Notification.permission === "default") {
        void Notification.requestPermission();
      }
    } catch { /* noop */ }
  }, []);

  const tick = useCallback(() => {
    const now = Date.now();
    if (isCountUp) {
      elapsedRef.current += 0.25;
      setElapsed(Math.floor(elapsedRef.current));
    } else {
      const remain = Math.max(0, (endAtRef.current - now) / 1000);
      const el = planned - remain;
      elapsedRef.current = el;
      setElapsed(Math.floor(el));
      if (remain <= 0) {
        // phase complete
        if (mode === "pomodoro" && phase === "focus") {
          totalFocusRef.current += planned;
          if (soundOn) engine.chime("complete");
          notify("Фокус дууслаа! 🎉", `${Math.round(planned / 60)} минут гүн ажил — одоо амраарай.`);
          setPhase("break");
          elapsedRef.current = 0;
          setElapsed(0);
          const bl = POMODORO_PRESETS[preset].break * 60;
          endAtRef.current = Date.now() + bl * 1000;
        } else if (mode === "pomodoro" && phase === "break") {
          if (soundOn) engine.chime("break");
          notify("Амралт дууслаа ⚡", "Дараагийн гүн фокус эхэллээ.");
          setPhase("focus");
          setCycle((c) => c + 1);
          elapsedRef.current = 0;
          setElapsed(0);
          const fl = POMODORO_PRESETS[preset].focus * 60;
          endAtRef.current = Date.now() + fl * 1000;
        } else {
          // countdown complete -> finish session
          void finish(true);
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isCountUp, planned, mode, phase, preset, soundOn]);

  const start = useCallback(() => {
    sessionStartRef.current = status === "paused" ? sessionStartRef.current : new Date();
    if (status === "idle") {
      elapsedRef.current = 0;
      setElapsed(0);
      totalFocusRef.current = 0;
      setLastResult(null);
    }
    if (!isCountUp) {
      endAtRef.current = Date.now() + (planned - elapsedRef.current) * 1000;
    }
    setStatus("running");
    onRunningChange?.(true);
    void requestWake();
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(tick, 250);
  }, [status, isCountUp, planned, tick, requestWake, onRunningChange]);

  const pause = useCallback(() => {
    setStatus("paused");
    onRunningChange?.(false);
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
  }, [releaseWake, onRunningChange]);

  const finish = useCallback(async (completed: boolean) => {
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
    setStatus("idle");
    onRunningChange?.(false);
    const actualPhase = Math.floor(elapsedRef.current);
    const totalActual = mode === "pomodoro"
      ? totalFocusRef.current + (phase === "focus" ? actualPhase : 0)
      : actualPhase;
    const realSeconds = Math.max(1, totalActual);
    const score = focusScore({
      plannedSeconds: mode === "pomodoro" ? POMODORO_PRESETS[preset].focus * 60 * cycle : planned,
      actualSeconds: realSeconds,
      completed,
      interruptions,
      mode,
      hourOfDay: new Date().getHours(),
    });
    const xp = Math.floor(realSeconds / 60) * 2 + (completed ? 15 : 0) + Math.floor(score / 10);
    try {
      await api.create("study_sessions", {
        subjectId: subjectId || null,
        roomId,
        mode,
        plannedSeconds: planned,
        actualSeconds: realSeconds,
        completed,
        interruptions,
        focusScore: score,
        startedAt: sessionStartRef.current.toISOString(),
        endedAt: new Date().toISOString(),
        note,
      });
    } catch { /* offline — still celebrate */ }
    if (completed && soundOn) engine.chime("complete");
    setLastResult(completed
      ? `+${xp} XP · Фокус ${score}/100 · ${Math.floor(realSeconds / 60)} мин`
      : `Хадгаллаа · ${Math.floor(realSeconds / 60)} мин · Фокус ${score}`);
    setElapsed(0);
    elapsedRef.current = 0;
    totalFocusRef.current = 0;
    setInterruptions(0);
    setPhase("focus");
    setCycle(1);
    onSessionComplete({ seconds: realSeconds, score, xp, completed });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, phase, planned, preset, cycle, interruptions, subjectId, roomId, note, soundOn]);

  const reset = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
    setStatus("idle");
    onRunningChange?.(false);
    setElapsed(0);
    elapsedRef.current = 0;
    setPhase("focus");
    setCycle(1);
    setInterruptions(0);
  }, [releaseWake, onRunningChange]);

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
  }, [releaseWake]);

  // tab title countdown
  useEffect(() => {
    if (status === "running") {
      document.title = `${fmtClock(display)} · ${phase === "break" ? "Амралт" : "Фокус"} — ТОГТМОЛ`;
    } else {
      document.title = "ТОГТМОЛ v8 — Гүн төвлөрлийн өрөө";
    }
  }, [display, status, phase]);

  const R = 92;
  const C = 2 * Math.PI * R;

  const MODES: { id: TimerMode; label: string; icon: any }[] = [
    { id: "pomodoro", label: "Помодоро", icon: Timer },
    { id: "stopwatch", label: "Секундомер", icon: Hourglass },
    { id: "countdown", label: "Тоолуур", icon: Hourglass },
    { id: "flowtime", label: "Урсгал", icon: InfinityIcon },
  ];

  return (
    <div className="glass rounded-3xl p-4 md:p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="grid h-10 w-10 place-items-center rounded-2xl" style={{ background: `${accent}22`, border: `1px solid ${accent}44` }}>
            <Timer size={20} style={{ color: accent }} />
          </div>
          <div>
            <h3 className="font-display text-[15px] font-bold text-white">Цагийн систем</h3>
            <p className="text-[11px] text-white/55">
              {mode === "pomodoro" ? `Цикл ${cycle} · ${phase === "focus" ? "Гүн фокус" : "Амралт"}` : mode === "flowtime" ? "Зогсолтгүй урсгал" : "Чөлөөт хэмжилт"}
            </p>
          </div>
        </div>
        <button
          onClick={() => setSoundOn(!soundOn)}
          className="grid h-9 w-9 place-items-center rounded-xl bg-white/8 text-white/70 transition hover:bg-white/15"
          title="Дуусах дохио"
        >
          {soundOn ? <Bell size={16} /> : <BellOff size={16} />}
        </button>
      </div>

      {/* mode tabs */}
      <div className="mt-3 grid grid-cols-4 gap-1.5">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => { if (status === "idle") setMode(m.id); }}
            disabled={status !== "idle"}
            className={`flex flex-col items-center gap-1 rounded-2xl px-1 py-2 text-[11px] font-bold ring-1 transition ${
              mode === m.id ? "text-white" : "bg-white/5 text-white/55 ring-white/10 hover:bg-white/10"
            } ${status !== "idle" ? "opacity-60" : ""}`}
            style={mode === m.id ? { background: `${accent}2e`, borderColor: `${accent}55`, boxShadow: `0 0 20px ${accent}33` } : undefined}
          >
            <m.icon size={16} />
            {m.label}
          </button>
        ))}
      </div>

      {/* the clock */}
      <div className="relative mx-auto mt-4 h-[220px] w-[220px]">
        <svg viewBox="0 0 220 220" className="h-full w-full -rotate-90">
          <circle cx="110" cy="110" r={R} fill="none" stroke="rgba(255,255,255,.1)" strokeWidth="12" />
          <circle
            cx="110" cy="110" r={R} fill="none"
            stroke={phase === "break" ? "#4ade80" : accent}
            strokeWidth="12" strokeLinecap="round"
            strokeDasharray={C}
            strokeDashoffset={C * (1 - progress)}
            style={{ transition: "stroke-dashoffset .3s linear, stroke .5s", filter: `drop-shadow(0 0 10px ${accent})` }}
          />
          {/* tick marks */}
          {Array.from({ length: 60 }).map((_, i) => {
            const a = (i / 60) * Math.PI * 2;
            const big = i % 5 === 0;
            const r1 = R - (big ? 22 : 18);
            const r2 = R - 26;
            return (
              <line
                key={i}
                x1={110 + Math.cos(a) * r1} y1={110 + Math.sin(a) * r1}
                x2={110 + Math.cos(a) * r2} y2={110 + Math.sin(a) * r2}
                stroke={big ? "rgba(255,255,255,.4)" : "rgba(255,255,255,.15)"}
                strokeWidth={big ? 2 : 1}
              />
            );
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="font-display text-[42px] font-bold tabular-nums leading-none text-white" style={{ textShadow: `0 0 30px ${accent}66` }}>
            {fmtClock(display)}
          </div>
          <div
            className="mt-2 flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-bold"
            style={{
              background: phase === "break" ? "rgba(74,222,128,.15)" : `${accent}22`,
              color: phase === "break" ? "#86efac" : accent,
              border: `1px solid ${phase === "break" ? "rgba(74,222,128,.4)" : accent + "55"}`,
            }}
          >
            {status === "running" ? (
              <span className="relative flex h-2 w-2">
                <span className="absolute h-full w-full animate-ping rounded-full bg-current opacity-60" />
                <span className="h-2 w-2 rounded-full bg-current" />
              </span>
            ) : <Zap size={12} />}
            {phase === "break" ? "☕ АМРАЛТ" : status === "running" ? "ГЭН ФОКУС" : status === "paused" ? "ТҮР ЗОГСОН" : "БЭЛЭН"}
          </div>
        </div>
      </div>

      {/* pomodoro presets */}
      {mode === "pomodoro" && status === "idle" && (
        <div className="mt-3 grid grid-cols-3 gap-1.5">
          {POMODORO_PRESETS.map((p, i) => (
            <button
              key={p.label}
              onClick={() => setPreset(i)}
              className={`rounded-2xl px-2 py-2 ring-1 transition ${
                preset === i ? "text-white" : "bg-white/5 text-white/60 ring-white/10 hover:bg-white/10"
              }`}
              style={preset === i ? { background: `${accent}2e`, borderColor: `${accent}66` } : undefined}
            >
              <div className="text-[15px] font-bold">{p.label}</div>
              <div className="text-[10px] opacity-70">{p.desc}</div>
            </button>
          ))}
        </div>
      )}

      {/* custom minutes */}
      {(mode === "countdown" || mode === "stopwatch" || mode === "flowtime") && status === "idle" && (
        <div className="mt-3 flex items-center justify-center gap-3 rounded-2xl bg-white/5 py-2 ring-1 ring-white/10">
          <button onClick={() => setCustomMin(Math.max(5, customMin - 5))} className="grid h-8 w-8 place-items-center rounded-xl bg-white/10 transition hover:bg-white/20"><Minus size={14} /></button>
          <div className="text-center">
            <div className="font-display text-xl font-bold text-white">{customMin} <span className="text-xs font-medium text-white/50">мин</span></div>
            <div className="text-[10px] text-white/45">{mode === "flowtime" ? "зорилтот урсгал" : "зорилтот хугацаа"}</div>
          </div>
          <button onClick={() => setCustomMin(Math.min(240, customMin + 5))} className="grid h-8 w-8 place-items-center rounded-xl bg-white/10 transition hover:bg-white/20"><Plus size={14} /></button>
        </div>
      )}

      {/* subject + note */}
      {status === "idle" && (
        <div className="mt-3 space-y-2">
          <div className="flex items-center gap-2">
            <BookOpen size={14} className="shrink-0 text-white/50" />
            <div className="flex flex-1 gap-1.5 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setSubjectId("")}
                className={`shrink-0 rounded-xl px-2.5 py-1.5 text-[11px] font-bold ring-1 transition ${!subjectId ? "bg-white/20 text-white ring-white/40" : "bg-white/5 text-white/55 ring-white/10"}`}
              >
                Чөлөөт
              </button>
              {subjects.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSubjectId(s.id)}
                  className={`flex shrink-0 items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-bold ring-1 transition ${
                    subjectId === s.id ? "bg-white/20 text-white ring-white/40" : "bg-white/5 text-white/60 ring-white/10 hover:bg-white/10"
                  }`}
                >
                  <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                  {s.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {lastResult && status === "idle" && (
        <div className="anim-pop mt-3 flex items-center gap-2 rounded-2xl bg-emerald-400/12 px-3 py-2.5 text-[12px] font-bold text-emerald-200 ring-1 ring-emerald-400/30">
          <CheckCircle2 size={16} /> {lastResult}
        </div>
      )}

      {/* controls */}
      <div className="mt-4 flex items-center justify-center gap-2.5">
        {status === "idle" ? (
          <button
            onClick={start}
            className="anim-ring flex items-center gap-2 rounded-2xl px-8 py-3.5 font-display text-[15px] font-bold text-white transition hover:scale-105 active:scale-95"
            style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)`, boxShadow: `0 8px 32px ${accent}55` }}
          >
            <Play size={18} fill="currentColor" /> Эхлэх
          </button>
        ) : (
          <>
            {status === "running" ? (
              <button onClick={pause} className="flex items-center gap-2 rounded-2xl bg-amber-400/20 px-6 py-3 text-[14px] font-bold text-amber-200 ring-1 ring-amber-400/40 transition hover:scale-105">
                <Pause size={17} /> Түр зогс
              </button>
            ) : (
              <button
                onClick={start}
                className="flex items-center gap-2 rounded-2xl px-6 py-3 text-[14px] font-bold text-white transition hover:scale-105"
                style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}
              >
                <Play size={17} /> Үргэлжлүүл
              </button>
            )}
            <button onClick={() => finish(false)} className="flex items-center gap-2 rounded-2xl bg-emerald-400/20 px-5 py-3 text-[14px] font-bold text-emerald-200 ring-1 ring-emerald-400/40 transition hover:scale-105" title="Дуусгаж хадгалах">
              <Square size={15} /> Дуусгах
            </button>
            <button onClick={reset} className="grid h-[46px] w-[46px] place-items-center rounded-2xl bg-white/8 text-white/60 ring-1 ring-white/10 transition hover:bg-white/15" title="Цуцлах">
              <RotateCcw size={17} />
            </button>
          </>
        )}
      </div>

      {/* interruptions */}
      {status !== "idle" && (
        <div className="mt-3 flex items-center justify-center gap-2">
          <button
            onClick={() => setInterruptions((i) => i + 1)}
            className="flex items-center gap-1.5 rounded-xl bg-white/5 px-3 py-1.5 text-[11px] font-bold text-white/60 ring-1 ring-white/10 transition hover:bg-white/10"
            title="Сатаарал тэмдэглэх"
          >
            <Waves size={13} /> Сатаарал: {interruptions}
          </button>
          <span className="text-[11px] text-white/35">Сатаарсан бол товшоод буц — энэ нь фокус оноонд нөлөөлнө</span>
        </div>
      )}
    </div>
  );
}
