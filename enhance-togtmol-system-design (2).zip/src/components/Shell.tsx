"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  House, Volume2, Timer as TimerIcon, Brain, Target, ChartColumn,
  Flame, Clock3, Search, X, Sparkles, ShieldCheck, ChevronRight,
  Play, DoorOpen, Zap, PartyPopper,
} from "lucide-react";
import RoomBackground from "./RoomBackground";
import Bondook, { type BondookMood, BondookAvatar } from "./Bondook";
import AudioMixer from "./AudioMixer";
import TimerSystem from "./TimerSystem";
import Breathing from "./Breathing";
import Knowledge from "./Knowledge";
import Goals from "./Goals";
import Stats from "./Stats";
import { ROOMS, roomById } from "@/lib/rooms";
import { PRESETS, engine } from "@/lib/audio-engine";
import { fmtMnDuration, BONDOOK_TIPS } from "@/lib/focus";
import { api } from "@/lib/api";
import type { Subject, Note, Deck, Card, Quiz, StudySession, Goal, GoalStep, Task } from "@/db/schema";

type View = "room" | "sound" | "time" | "mind" | "goals" | "stats";

interface Toast { id: number; title: string; desc?: string; emoji?: string }

let toastId = 1;

export default function Shell() {
  const [roomId, setRoomId] = useState("night");
  const [view, setView] = useState<View>("room");
  const [loading, setLoading] = useState(true);
  const [mood, setMood] = useState<BondookMood>("happy");
  const [bondookMsg, setBondookMsg] = useState<string | undefined>(undefined);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [showRooms, setShowRooms] = useState(false);
  const [showPalette, setShowPalette] = useState(false);
  const [paletteQ, setPaletteQ] = useState("");
  const [shield, setShield] = useState(false);
  const [timerRunning, setTimerRunning] = useState(false);
  const [soundCount, setSoundCount] = useState(0);
  const [tipIdx, setTipIdx] = useState(0);
  const [focusClock, setFocusClock] = useState("00:00");
  const [focusPhase, setFocusPhase] = useState("focus");

  const onDisplayChange = useCallback((clock: string, phase: string) => {
    setFocusClock((prev) => (prev === clock ? prev : clock));
    setFocusPhase((prev) => (prev === phase ? prev : phase));
  }, []);

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [decks, setDecks] = useState<Deck[]>([]);
  const [cards, setCards] = useState<Card[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [steps, setSteps] = useState<GoalStep[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);

  const room = roomById(roomId);
  const accent = room.accent;

  const pushToast = useCallback((t: Omit<Toast, "id">) => {
    const id = toastId++;
    setToasts((prev) => [...prev.slice(-3), { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 4200);
  }, []);

  const celebrate = useCallback((xp: number, label: string) => {
    pushToast({ title: label, desc: "Үргэлжлүүл — тогтмол байдал ялна ✨", emoji: "⚡" });
    setMood("party");
    setTimeout(() => setMood("happy"), 5000);
  }, [pushToast]);

  const load = useCallback(async () => {
    try {
      const [s1, s2, s3, s4, s5, s6, s7, s8, s9] = await Promise.all([
        api.list<Subject>("subjects"),
        api.list<Note>("notes"),
        api.list<Deck>("decks"),
        api.list<Card>("cards", "?limit=500"),
        api.list<Quiz>("quizzes"),
        api.list<StudySession>("study_sessions", "?limit=300"),
        api.list<Goal>("goals"),
        api.list<GoalStep>("goal_steps", "?limit=500"),
        api.list<Task>("tasks"),
      ]);
      setSubjects(s1); setNotes(s2); setDecks(s3); setCards(s4);
      setQuizzes(s5); setSessions(s6); setGoals(s7); setSteps(s8); setTasks(s9);
      return s1.length;
    } catch (e) {
      console.error(e);
      return -1;
    }
  }, []);

  useEffect(() => {
    try {
      const r = localStorage.getItem("togtmol-room-v8");
      if (r) setRoomId(r);
    } catch { /* noop */ }
    (async () => {
      const n = await load();
      if (n === 0) {
        try {
          await fetch("/api/seed", { method: "POST" });
          await load();
          pushToast({ title: "Тавтай морил! 🎉", desc: "Жишээ хичээл, карт, сорил бэлдлээ", emoji: "🐾" });
        } catch { /* noop */ }
      }
      setLoading(false);
    })();
    const tipT = setInterval(() => setTipIdx((i) => (i + 1) % BONDOOK_TIPS.length), 15000);
    return () => clearInterval(tipT);
  }, [load, pushToast]);

  useEffect(() => {
    try { localStorage.setItem("togtmol-room-v8", roomId); } catch { /* noop */ }
  }, [roomId]);

  // Cmd+K palette
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setShowPalette((v) => !v);
      }
      if (e.key === "Escape") {
        setShowPalette(false);
        setShowRooms(false);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  const todaySec = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return sessions
      .filter((s) => new Date(s.startedAt).toISOString().slice(0, 10) === today)
      .reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
  }, [sessions]);

  const streak = useMemo(() => {
    const set = new Set(sessions.map((s) => new Date(s.startedAt).toISOString().slice(0, 10)));
    let n = 0;
    const d = new Date();
    const key = (x: Date) => x.toISOString().slice(0, 10);
    if (!set.has(key(d))) d.setDate(d.getDate() - 1);
    while (set.has(key(d))) { n++; d.setDate(d.getDate() - 1); }
    return n;
  }, [sessions]);

  const dueCards = useMemo(
    () => cards.filter((c) => new Date(c.nextReview) <= new Date()).length,
    [cards]
  );

  const openTasks = tasks.filter((t) => !t.done).length;

  const onSessionComplete = useCallback((info: { seconds: number; score: number; xp: number; completed: boolean }) => {
    void load();
    setMood("party");
    setBondookMsg(
      info.completed
        ? `Гайхалтай! ${fmtMnDuration(info.seconds)} гүн ажил — фокус ${info.score}/100. +${info.xp} XP! 🎉`
        : `Сайн оролдлого! ${fmtMnDuration(info.seconds)} — фокус ${info.score}. Дараа нь бүр гүнзгийрье 💪`
    );
    pushToast({
      title: `+${info.xp} XP · Фокус ${info.score}/100`,
      desc: `${fmtMnDuration(info.seconds)} суралцлаа`,
      emoji: info.completed ? "🎉" : "💪",
    });
    setTimeout(() => { setMood("happy"); setBondookMsg(undefined); }, 9000);
  }, [load, pushToast]);

  const applyPresetQuick = (id: string) => {
    const p = PRESETS.find((x) => x.id === id);
    if (!p) return;
    engine.ensure();
    const full: Record<string, number> = {};
    Object.entries(p.mix).forEach(([k, v]) => { full[k] = v ?? 0; });
    engine.applyMix(full as any);
    pushToast({ title: p.nameMn, desc: p.desc, emoji: p.emoji });
    setShowPalette(false);
  };

  const NAV: { id: View; label: string; icon: any; badge?: number }[] = [
    { id: "room", label: "Миний өрөө", icon: House },
    { id: "sound", label: "Дуу", icon: Volume2, badge: soundCount || undefined },
    { id: "time", label: "Цаг", icon: TimerIcon },
    { id: "mind", label: "Мэдлэг", icon: Brain, badge: dueCards || undefined },
    { id: "goals", label: "Зорилго", icon: Target, badge: openTasks || undefined },
    { id: "stats", label: "Статистик", icon: ChartColumn },
  ];

  const paletteActions = useMemo(() => {
    const q = paletteQ.toLowerCase();
    const items: { label: string; hint: string; emoji: string; run: () => void }[] = [
      ...NAV.map((n) => ({
        label: `${n.label} нээх`, hint: "Хуудас", emoji: "📄",
        run: () => { setView(n.id); setShowPalette(false); },
      })),
      ...ROOMS.map((r) => ({
        label: `${r.nameMn} өрөөнд орох`, hint: "Өрөө", emoji: r.emoji,
        run: () => {
          setRoomId(r.id);
          const p = PRESETS.find((x) => x.id === r.preset);
          if (p) {
            engine.ensure();
            engine.applyMix({ ...(p.mix as any) });
          }
          pushToast({ title: r.nameMn, desc: r.greeting, emoji: r.emoji });
          setShowPalette(false);
        },
      })),
      ...PRESETS.map((p) => ({
        label: `${p.nameMn} сонсох`, hint: "Дуу", emoji: p.emoji,
        run: () => applyPresetQuick(p.id),
      })),
      {
        label: "Фокус бамбай асаах", hint: "Төвлөрөл", emoji: "🛡️",
        run: () => { setShield(true); setShowPalette(false); },
      },
    ];
    if (!q) return items.slice(0, 14);
    return items.filter((i) => i.label.toLowerCase().includes(q)).slice(0, 14);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paletteQ, soundCount]);

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#070714]">
        <div className="flex flex-col items-center gap-4">
          <BondookAvatar mood="think" size={110} />
          <div className="font-display text-xl font-bold text-white shimmer-text" style={{ ["--shimmer" as any]: "#a78bfa" }}>
            ТОГТМОЛ ачааллаж байна…
          </div>
          <div className="flex gap-1.5">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-2 w-8 animate-pulse rounded-full bg-violet-400/60" style={{ animationDelay: `${i * 200}ms` }} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const tip = BONDOOK_TIPS[tipIdx];

  return (
    <div className="relative min-h-screen">
      <RoomBackground room={room} />

      {/* ── FOCUS SHIELD overlay ── */}
      {shield && (
        <div className="fixed inset-0 z-[80] flex flex-col items-center justify-center bg-black/85 p-6 backdrop-blur-xl">
          <div className="anim-pop flex max-w-md flex-col items-center text-center">
            <ShieldCheck size={44} style={{ color: accent }} />
            <h2 className="mt-3 font-display text-2xl font-bold text-white">Фокус бамбай 🛡️</h2>
            <p className="mt-1 text-[13px] text-white/60">
              Дэлхий түр хүлээнэ. Зөвхөн чи, амьсгал, зорилго.
            </p>
            <div className="mt-5">
              <BondookAvatar mood={timerRunning ? "focus" : "sleep"} size={120} />
            </div>
            <div className="mt-4 grid w-full grid-cols-3 gap-2">
              <div className="rounded-2xl bg-white/8 p-3 ring-1 ring-white/12">
                <Clock3 size={16} className="mx-auto text-white/60" />
                <div className="mt-1 font-display text-[15px] font-bold text-white">{fmtMnDuration(todaySec)}</div>
                <div className="text-[10px] text-white/50">өнөөдөр</div>
              </div>
              <div className="rounded-2xl bg-white/8 p-3 ring-1 ring-white/12">
                <Flame size={16} className="mx-auto text-orange-400" />
                <div className="mt-1 font-display text-[15px] font-bold text-white">{streak} өдөр</div>
                <div className="text-[10px] text-white/50">цуврал</div>
              </div>
              <div className="rounded-2xl bg-white/8 p-3 ring-1 ring-white/12">
                <Volume2 size={16} className="mx-auto text-white/60" />
                <div className="mt-1 font-display text-[15px] font-bold text-white">{soundCount}</div>
                <div className="text-[10px] text-white/50">суваг</div>
              </div>
            </div>
            <p className="mt-4 rounded-2xl bg-white/6 px-4 py-2.5 text-[13px] italic text-white/75 ring-1 ring-white/10">
              “{tip.title} — {tip.body}”
            </p>
            <button
              onClick={() => setShield(false)}
              className="mt-5 flex items-center gap-2 rounded-2xl px-8 py-3 font-display text-[14px] font-bold text-white transition hover:scale-105"
              style={{ background: `linear-gradient(135deg, ${accent}, ${accent}77)` }}
            >
              <DoorOpen size={16} /> Бамбай буулгах
            </button>
          </div>
        </div>
      )}

      {/* ── header ── */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-black/30 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center gap-2 px-3 py-2.5 md:px-6">
          <button onClick={() => setView("room")} className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-2xl font-display text-[15px] font-bold text-white" style={{ background: `linear-gradient(135deg, ${accent}, ${accent}66)`, boxShadow: `0 4px 18px ${accent}55` }}>
              Т
            </span>
            <span className="text-left leading-tight">
              <span className="block font-display text-[15px] font-bold tracking-wide text-white">ТОГТМОЛ <span className="text-[10px] font-bold" style={{ color: accent }}>v8</span></span>
              <span className="hidden text-[10px] text-white/50 sm:block">Гүн төвлөрлийн өрөө</span>
            </span>
          </button>

          <div className="ml-2 hidden items-center gap-1.5 md:flex">
            <span className="flex items-center gap-1 rounded-full bg-orange-400/15 px-2.5 py-1 text-[11px] font-bold text-orange-300 ring-1 ring-orange-400/25">
              <Flame size={12} /> {streak}
            </span>
            <span className="flex items-center gap-1 rounded-full bg-sky-400/15 px-2.5 py-1 text-[11px] font-bold text-sky-300 ring-1 ring-sky-400/25">
              <Clock3 size={12} /> {fmtMnDuration(todaySec)}
            </span>
            {timerRunning && (
              <button
                onClick={() => setView("time")}
                className="flex items-center gap-1.5 rounded-full bg-red-400/15 px-2.5 py-1 text-[11px] font-bold text-red-300 ring-1 ring-red-400/30 transition hover:bg-red-400/25"
                title="Цаг нээх"
              >
                <span className="relative flex h-2 w-2">
                  <span className="absolute h-full w-full animate-ping rounded-full bg-red-400" />
                  <span className="h-2 w-2 rounded-full bg-red-400" />
                </span>
                ФОКУС
                <span className="font-display tabular-nums text-[13px] text-white">{focusClock}</span>
                {focusPhase === "break" && <span className="text-emerald-300">☕</span>}
              </button>
            )}
            <LiveClock />
          </div>

          <div className="ml-auto flex items-center gap-1.5">
            <button
              onClick={() => setShowPalette(true)}
              className="hidden items-center gap-2 rounded-xl bg-white/8 px-3 py-2 text-[12px] text-white/55 ring-1 ring-white/10 transition hover:bg-white/12 sm:flex"
            >
              <Search size={14} /> Хайх…
              <kbd className="rounded-md bg-white/10 px-1.5 py-0.5 text-[10px] font-bold">⌘K</kbd>
            </button>
            <button
              onClick={() => setShield(true)}
              className="grid h-9 w-9 place-items-center rounded-xl bg-white/8 text-white/70 ring-1 ring-white/10 transition hover:bg-white/15"
              title="Фокус бамбай"
            >
              <ShieldCheck size={17} />
            </button>
            <button
              onClick={() => setShowRooms(true)}
              className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-[12px] font-bold text-white ring-1 transition hover:scale-[1.03]"
              style={{ background: `${accent}30`, borderColor: `${accent}55` }}
            >
              <span className="text-base">{room.emoji}</span>
              <span className="hidden sm:inline">{room.nameMn}</span>
            </button>
          </div>
        </div>
        {/* desktop nav */}
        <nav className="mx-auto hidden max-w-7xl gap-1.5 px-6 pb-2.5 lg:flex">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => setView(n.id)}
              className={`relative flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[13px] font-bold transition ${
                view === n.id ? "text-white" : "text-white/55 hover:bg-white/8 hover:text-white/85"
              }`}
              style={view === n.id ? { background: `${accent}2c`, boxShadow: `inset 0 0 0 1px ${accent}55` } : undefined}
            >
              <n.icon size={15} />
              {n.label}
              {n.badge ? (
                <span className="grid h-5 min-w-5 place-items-center rounded-full bg-red-400 px-1 text-[10px] font-bold text-white">
                  {n.badge}
                </span>
              ) : null}
            </button>
          ))}
        </nav>
      </header>

      {/* ── main ── */}
      <main className="relative z-10 mx-auto max-w-7xl px-3 pb-28 pt-4 md:px-6 lg:pb-12">
        {/* greeting */}
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-[22px] font-bold leading-tight text-white md:text-[28px]">
              {room.greeting.split(".")[0]}.
            </h1>
            <p className="mt-0.5 flex items-center gap-1.5 text-[12px] text-white/55 md:text-[13px]">
              <Sparkles size={13} style={{ color: accent }} />
              {room.tip}
            </p>
          </div>
        </div>

        {view === "room" && (
          <div className="grid gap-3.5 lg:grid-cols-12">
            <div className="space-y-3.5 lg:col-span-5">
              <TimerSystem
                subjects={subjects} roomId={roomId} accent={accent} goals={goals}
                dueCards={dueCards}
                openTasks={tasks.filter((t) => !t.done).map((t) => ({ id: t.id, title: t.title }))}
                onSessionComplete={onSessionComplete}
                onRunningChange={setTimerRunning}
                onDisplayChange={onDisplayChange}
              />
              <Bondook mood={timerRunning ? "focus" : mood} message={bondookMsg} onMood={setMood} />
            </div>
            <div className="space-y-3.5 lg:col-span-4">
              <AudioMixer accent={accent} onPlayingChange={setSoundCount} />
            </div>
            <div className="space-y-3.5 lg:col-span-3">
              {/* today */}
              <div className="glass rounded-3xl p-4">
                <div className="text-[12px] font-bold uppercase tracking-widest text-white/45">Өнөөдөр</div>
                <div className="mt-1 font-display text-[30px] font-bold text-white">{fmtMnDuration(todaySec)}</div>
                <div className="mt-1 flex items-center gap-2 text-[12px] text-white/55">
                  <span className="flex items-center gap-1"><Flame size={13} className="text-orange-400" /> {streak} өдрийн цуврал</span>
                  <span>·</span>
                  <span>{dueCards} карт хүлээгдэж байна</span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-1.5">
                  <button onClick={() => setView("mind")} className="rounded-2xl bg-white/8 py-2.5 text-[12px] font-bold text-white/85 ring-1 ring-white/10 transition hover:bg-white/12">
                    🃏 Карт давтах
                  </button>
                  <button onClick={() => setView("goals")} className="rounded-2xl bg-white/8 py-2.5 text-[12px] font-bold text-white/85 ring-1 ring-white/10 transition hover:bg-white/12">
                    🎯 {openTasks} даалгавар
                  </button>
                </div>
              </div>
              <Breathing accent={accent} onDone={(c) => celebrate(c * 2, `Амьсгал +${c * 2} XP`)} />
              {/* tip of moment */}
              <div className="glass rounded-3xl p-4">
                <div className="flex items-center gap-1.5 text-[12px] font-bold uppercase tracking-widest text-white/45">
                  <Zap size={12} style={{ color: accent }} /> Фокус зөвлөгөө
                </div>
                <div className="mt-1.5 text-[13px] font-bold text-white">{tip.title}</div>
                <div className="mt-0.5 text-[12px] leading-relaxed text-white/60">{tip.body}</div>
              </div>
            </div>
          </div>
        )}

        {view === "sound" && (
          <div className="grid gap-3.5 lg:grid-cols-2">
            <AudioMixer accent={accent} onPlayingChange={setSoundCount} />
            <div className="space-y-3.5">
              <div className="glass rounded-3xl p-5">
                <h3 className="font-display text-[16px] font-bold text-white">Дууны шинжлэх ухаан 🎧</h3>
                <div className="mt-3 space-y-2.5 text-[13px] leading-relaxed text-white/70">
                  <div className="rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
                    <b className="text-white">Ягаан/бор чимээ</b> — тархины “санамсаргүй яриа” мэдрэмжийг дарж, унших ойлголтыг 15-25% нэмэгдүүлдэг.
                  </div>
                  <div className="rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
                    <b className="text-white">Бороо + кафе (~70dB)</b> — Чикагогийн судалгаагаар дунд зэргийн орчны чимээ бүтээлч сэтгэлгээг идэвхжүүлдэг.
                  </div>
                  <div className="rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
                    <b className="text-white">Альфа бинаурал 10Hz</b> — чихэвчтэй сонсоход тайван сэргэг байдал (relaxed alertness) нэмэгддэг.
                  </div>
                  <div className="rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
                    <b className="text-white">Муурны хурхираа 25Hz</b> — бага давтамжийн чичиргээ стрессийн кортизолыг бууруулдаг.
                  </div>
                </div>
              </div>
              <Bondook mood="love" compact message="Дуртай хослолоо хадгал — тархи чинь тэр дууг 'фокусын дохио' гэж сурна. Тархины зан үйл!" />
            </div>
          </div>
        )}

        {view === "time" && (
          <div className="grid gap-3.5 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <TimerSystem
                subjects={subjects} roomId={roomId} accent={accent} goals={goals}
                dueCards={dueCards}
                openTasks={tasks.filter((t) => !t.done).map((t) => ({ id: t.id, title: t.title }))}
                onSessionComplete={onSessionComplete}
                onRunningChange={setTimerRunning}
                onDisplayChange={onDisplayChange}
              />
            </div>
            <div className="space-y-3.5 lg:col-span-4">
              <Breathing accent={accent} onDone={(c) => celebrate(c * 2, `Амьсгал +${c * 2} XP`)} />
            </div>
            <div className="lg:col-span-3">
              <div className="glass rounded-3xl p-4">
                <div className="mb-2 text-[13px] font-bold text-white">Сүүлийн сессүүд</div>
                <div className="max-h-[420px] space-y-1.5 overflow-y-auto pr-1">
                  {sessions.slice(0, 20).map((s) => {
                    const sub = subjects.find((x) => x.id === s.subjectId);
                    return (
                      <div key={s.id} className="rounded-2xl bg-white/5 px-3 py-2 ring-1 ring-white/8">
                        <div className="flex items-center justify-between text-[12px]">
                          <span className="flex items-center gap-1.5 font-bold text-white/90">
                            {sub && <span className="h-2 w-2 rounded-full" style={{ background: sub.color }} />}
                            {sub?.name ?? "Чөлөөт"}
                          </span>
                          <span className="font-display font-bold" style={{ color: accent }}>
                            {s.focusScore}
                          </span>
                        </div>
                        <div className="mt-0.5 flex justify-between text-[11px] text-white/45">
                          <span>{fmtMnDuration(s.actualSeconds)} · {s.mode}</span>
                          <span>{new Date(s.startedAt).toLocaleDateString("mn-MN", { month: "short", day: "numeric" })}</span>
                        </div>
                      </div>
                    );
                  })}
                  {sessions.length === 0 && (
                    <div className="rounded-2xl bg-white/4 p-4 text-center text-[12px] text-white/45">
                      Сесс алга — анхны фокусоо эхлүүл ⏱️
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {view === "mind" && (
          <div className="mx-auto max-w-3xl">
            <Knowledge subjects={subjects} notes={notes} decks={decks} cards={cards} quizzes={quizzes} accent={accent} refresh={() => void load()} onXp={celebrate} />
          </div>
        )}

        {view === "goals" && (
          <div className="mx-auto max-w-3xl">
            <Goals goals={goals} steps={steps} tasks={tasks} subjects={subjects} accent={accent} refresh={() => void load()} onXp={celebrate} />
          </div>
        )}

        {view === "stats" && (
          <div className="mx-auto max-w-4xl">
            <Stats sessions={sessions} subjects={subjects} accent={accent} />
          </div>
        )}
      </main>

      {/* ── mobile bottom nav ── */}
      <nav className="fixed inset-x-3 bottom-3 z-40 lg:hidden">
        <div className="glass-deep flex items-center justify-around rounded-3xl px-1 py-2 shadow-2xl">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => setView(n.id)}
              className={`relative flex flex-col items-center gap-0.5 rounded-2xl px-3 py-1.5 text-[10px] font-bold transition ${
                view === n.id ? "text-white" : "text-white/45"
              }`}
              style={view === n.id ? { background: `${accent}30` } : undefined}
            >
              <n.icon size={19} style={view === n.id ? { color: accent } : undefined} />
              {n.label}
              {n.badge ? (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-red-400 px-1 text-[9px] text-white">
                  {n.badge}
                </span>
              ) : null}
            </button>
          ))}
        </div>
      </nav>

      {/* ── rooms modal ── */}
      {showRooms && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/60 backdrop-blur-sm sm:items-center sm:p-6" onClick={() => setShowRooms(false)}>
          <div className="glass-deep anim-pop max-h-[85vh] w-full max-w-3xl overflow-y-auto rounded-t-3xl p-4 sm:rounded-3xl md:p-6" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-[18px] font-bold text-white">10 өрөө — орчноо сонго</h2>
              <button onClick={() => setShowRooms(false)} className="grid h-9 w-9 place-items-center rounded-xl bg-white/10 hover:bg-white/20">
                <X size={17} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {ROOMS.map((r) => (
                <button
                  key={r.id}
                  onClick={() => {
                    setRoomId(r.id);
                    setShowRooms(false);
                    const p = PRESETS.find((x) => x.id === r.preset);
                    setBondookMsg(r.greeting);
                    setMood("happy");
                    if (p) {
                      engine.ensure();
                      engine.applyMix({ ...(p.mix as any) });
                      pushToast({ title: `${r.emoji} ${r.nameMn}`, desc: `Дуу: ${p.nameMn} 🎶`, emoji: r.emoji });
                    }
                    setTimeout(() => setBondookMsg(undefined), 8000);
                  }}
                  className={`group relative overflow-hidden rounded-3xl p-4 text-left ring-1 transition hover:scale-[1.02] ${
                    roomId === r.id ? "ring-2" : "ring-white/15"
                  }`}
                  style={{
                    background: `linear-gradient(150deg, ${r.bg[1]}, ${r.bg[2]})`,
                    ["--tw-ring-color" as any]: roomId === r.id ? r.accent : undefined,
                  }}
                >
                  <div
                    className="absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-40 blur-2xl"
                    style={{ background: r.accent }}
                  />
                  <div className="text-3xl">{r.emoji}</div>
                  <div className="mt-2 font-display text-[14px] font-bold text-white">{r.nameMn}</div>
                  <div className="text-[11px] text-white/55">{r.tagline}</div>
                  {roomId === r.id && (
                    <span className="mt-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold text-white" style={{ background: `${r.accent}55` }}>
                      <Play size={10} /> Одоо
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── command palette ── */}
      {showPalette && (
        <div className="fixed inset-0 z-[70] flex items-start justify-center bg-black/60 p-4 pt-[12vh] backdrop-blur-sm" onClick={() => setShowPalette(false)}>
          <div className="glass-deep anim-pop w-full max-w-xl overflow-hidden rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
              <Search size={17} className="text-white/50" />
              <input
                autoFocus
                value={paletteQ}
                onChange={(e) => setPaletteQ(e.target.value)}
                placeholder="Өрөө, дуу, хуудас хайх…"
                className="w-full bg-transparent text-[14px] text-white outline-none placeholder:text-white/35"
              />
              <kbd className="rounded-md bg-white/10 px-1.5 py-0.5 text-[10px] font-bold text-white/60">esc</kbd>
            </div>
            <div className="max-h-[50vh] overflow-y-auto p-2">
              {paletteActions.map((a, i) => (
                <button
                  key={i}
                  onClick={a.run}
                  className="flex w-full items-center gap-2.5 rounded-2xl px-3 py-2.5 text-left transition hover:bg-white/10"
                >
                  <span className="text-lg">{a.emoji}</span>
                  <span className="flex-1 text-[13px] font-bold text-white/90">{a.label}</span>
                  <span className="text-[11px] text-white/40">{a.hint}</span>
                  <ChevronRight size={14} className="text-white/30" />
                </button>
              ))}
              {paletteActions.length === 0 && (
                <div className="p-6 text-center text-[13px] text-white/45">Юу ч олдсонгүй</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── toasts ── */}
      <div className="pointer-events-none fixed right-3 top-20 z-[90] flex w-[300px] flex-col gap-2" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className="anim-pop glass-deep pointer-events-auto flex items-start gap-2.5 rounded-2xl p-3 shadow-2xl">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-lg" style={{ background: `${accent}2a` }}>
              {t.emoji ?? <PartyPopper size={17} style={{ color: accent }} />}
            </span>
            <div className="min-w-0">
              <div className="text-[13px] font-bold text-white">{t.title}</div>
              {t.desc && <div className="text-[11px] leading-snug text-white/60">{t.desc}</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/** Жинхэнэ цаг (StudyOS-аас авсан санаа — дээд цэсэнд байнгын цаг) */
function LiveClock() {
  const [t, setT] = useState(() => new Date());
  useEffect(() => {
    const i = setInterval(() => setT(new Date()), 1000);
    return () => clearInterval(i);
  }, []);
  const hh = String(t.getHours()).padStart(2, "0");
  const mm = String(t.getMinutes()).padStart(2, "0");
  const ss = String(t.getSeconds()).padStart(2, "0");
  const day = t.toLocaleDateString("mn-MN", { weekday: "short", month: "short", day: "numeric" });
  return (
    <span
      className="hidden items-baseline gap-1.5 rounded-xl bg-white/8 px-3 py-2 ring-1 ring-white/10 sm:flex"
      title={`${day} · Жинхэнэ цаг`}
    >
      <span className="font-display text-[15px] font-bold leading-none tabular-nums text-white">
        {hh}:{mm}
      </span>
      <span className="text-[11px] font-bold tabular-nums text-white/40">:{ss}</span>
      <span className="ml-1 text-[11px] text-white/45">{day}</span>
    </span>
  );
}
