import { getDashboardData } from "@/lib/data";
import { PageHeader } from "@/components/shell";
import { GoalsView } from "@/components/goals/goals-view";

export const dynamic = "force-dynamic";

export default async function GoalsPage() {
  const data = await getDashboardData();

  return (
    <div>
      <PageHeader
        eyebrow="Урт хугацааны чиглэл"
        title="Зорилгын систем"
        description="Том зорилгыг жижиг үе шат болгон хуваа. Үе шат бүр өдрийн блоктой холбогдож, ахиц бодит минутаар хэмжигдэнэ."
        actions={
          <>
            <span className="chip">{data.goals.length} зорилго</span>
            <span className="chip chip-accent">{data.activeStreak} өдрийн цуваа</span>
          </>
        }
      />
      <GoalsView goals={data.goals} subjects={data.subjects} />
    </div>
  );
}
