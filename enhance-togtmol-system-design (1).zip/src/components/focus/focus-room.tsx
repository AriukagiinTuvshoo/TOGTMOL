"use client";

import { cx } from "@/lib/utils";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { rateSession, saveSession, toggleTaskDone } from "@/app/actions";
import { useSound } from "@/components/sound/provider";
import { SoundMixer } from "@/components/sound/mixer";
import { Modal, Progress, SectionHeading, SubjectDot, Toast } from "@/components/ui";
import { timerLabel, minutesLabel, percent } from "@/lib/date";
import { presetLabel } from "@/lib/labels";
import type { FocusData, Task } from "@/lib/types";

type Mode = "focus" | "short" | "long" | "stopwatch";

const MODES: { id: Mode; label: string; glyph: string }[] = [
  { id: "focus", label: "Анхаарал", glyph: "◎" },
  { id: "short", label: "Богино амралт", glyph: "☁" },
  { id: "long", label: "Урт амралт", glyph: "☾" },
  { id: "stopwatch", label: "Секундомер", glyph: "⏱" },
];

function pad(value: number) {
  return String(value).padStart(2, "0");
}

function naiveClient(epoch = Date.now()): string {
  const date = new Date(epoch);
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(
    date.getHours(),
  )}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

type Summary = {
  mode: Mode;
  minutes: number;
  taskTitle: string | null;
  sessionId: number | null;
  nextMode: Mode;
  completed: boolean;
};

export function FocusRoom({
  data,
  initialTaskId,
}: {
  data: FocusData;
  initialTaskId: number | null;
}) {
  const router = useRouter();
  const sound = useSound();
  const { settings } = data;

  const durations = useMemo<Record<Mode, number>>(
    () => ({
      focus: settings.focusMinutes * 60,
      short: settings.shortBreakMinutes * 60,
      long: settings.longBreakMinutes * 60,
      stopwatch: 0,
    }),
    [settings.focusMinutes, settings.shortBreakMinutes, settings.longBreakMinutes],
  );

  const [mode, setMode] = useState<Mode>("focus");
  const initialTask = data.tasks.find((task) => task.id === initialTaskId) ?? null;
  const [taskId, setTaskId] = useState<number | null>(initialTask?.id ?? null);
  const [freeSubjectId, setFreeSubjectId] = useState<number | null>(null);
  const [remaining, setRemaining] = useState(durations.focus);
  const [running, setRunning] = useState(false);
  const [cyclesDone, setCyclesDone] = useState(0);
  const [interruptions, setInterruptions] = useState(0);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [rating, setRating] = useState(4);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const endAtRef = useRef(0);
  const sessionStartNaiveRef = useRef<string | null>(null);
  const sessionStartEpochRef = useRef(0);
  const finishingRef = useRef(false);
  const finishRef = useRef<(completed: boolean) => void>(() => undefined);
  const taskIdRef = useRef<number | null>(taskId);
  const stopwatchAccumRef = useRef(0);
  const stopwatchRunRef = useRef(0);

  useEffect(() => {
    taskIdRef.current = taskId;
  }, [taskId]);

  const total = mode === "stopwatch" ? 0 : durations[mode];
  const elapsed = mode === "stopwatch" ? remaining : Math.max(0, total - remaining);
  const progress = mode === "stopwatch" ? 0 : total > 0 ? ((total - remaining) / total) * 100 : 0;
  const activeTask: Task | null = data.tasks.find((task) => task.id === taskId) ?? null;
  const subjectId = activeTask?.subjectId ?? freeSubjectId;
  const taskMinutesToday = Math.round(data.todayMinutes);
  const dailyPercent = percent(taskMinutesToday, settings.dailyGoalMinutes || 1);

  const flash = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2600);
  }, []);

  const requestNotifications = useCallback(() => {
    if (!settings.notifications) return;
    if (typeof window === "undefined" || !("Notification" in window)) return;
    if (Notification.permission === "default") {
      void Notification.requestPermission();
    }
  }, [settings.notifications]);

  const prepareMode = useCallback(
    (next: Mode) => {
      finishingRef.current = false;
      setMode(next);
      setRunning(false);
      setRemaining(durations[next]);
      setInterruptions(0);
      sessionStartNaiveRef.current = null;
      sessionStartEpochRef.current = 0;
      endAtRef.current = 0;
    },
    [durations],
  );

  const finishSession = useCallback(
    async (completedNaturally: boolean) => {
      if (finishingRef.current) return;
      finishingRef.current = true;
      setRunning(false);

      const nowEpoch = Date.now();
      const startNaive =
        sessionStartNaiveRef.current ??
        naiveClient(sessionStartEpochRef.current || nowEpoch - elapsed * 1000);
      const actualSeconds =
        mode === "stopwatch"
          ? Math.max(1, elapsed)
          : completedNaturally
            ? total
            : Math.max(1, total - remaining);
      const plannedSeconds = mode === "stopwatch" ? actualSeconds : total;

      if (settings.chime) sound.chime();
      if (settings.notifications && typeof window !== "undefined" && "Notification" in window) {
        if (Notification.permission === "granted") {
          new Notification(mode === "focus" ? "Блок дууслаа" : "Амралт дууслаа", {
            body:
              mode === "focus"
                ? `${minutesLabel(actualSeconds / 60)} гүн ажил бүртгэгдлээ. Одоо сэргээх цаг.`
                : "Дараагийн блок руу буцах цаг боллоо.",
          });
        }
      }

      const nextCycle = cyclesDone + (mode === "focus" ? 1 : 0);
      if (mode === "focus") setCyclesDone(nextCycle);
      const nextMode: Mode =
        mode === "focus"
          ? nextCycle % settings.cyclesBeforeLong === 0
            ? "long"
            : "short"
          : "focus";

      let sessionId: number | null = null;
      if (actualSeconds >= 5) {
        const result = await saveSession({
          mode,
          plannedSeconds,
          actualSeconds,
          startedAt: startNaive,
          endedAt: naiveClient(nowEpoch),
          localDate: startNaive.slice(0, 10),
          taskId: taskIdRef.current,
          subjectId,
          soundscape: sound.preset,
          interruptions,
          completed: completedNaturally,
        });
        if (result.ok) sessionId = result.id ?? null;
      }

      setSummary({
        mode,
        minutes: Math.max(1, Math.round(actualSeconds / 60)),
        taskTitle: activeTask?.title ?? null,
        sessionId,
        nextMode,
        completed: completedNaturally,
      });
      setRating(4);
      setNotes("");
      setRunning(false);
      router.refresh();
    },
    [
      activeTask?.title,
      cyclesDone,
      elapsed,
      interruptions,
      mode,
      remaining,
      router,
      settings.chime,
      settings.cyclesBeforeLong,
      settings.notifications,
      sound,
      subjectId,
      total,
    ],
  );

  useEffect(() => {
    finishRef.current = (completed: boolean) => {
      void finishSession(completed);
    };
  }, [finishSession]);

  useEffect(() => {
    if (!running) return;
    const tick = () => {
      const now = Date.now();
      if (mode === "stopwatch") {
        const elapsedMs = stopwatchAccumRef.current + (now - stopwatchRunRef.current);
        setRemaining(Math.floor(elapsedMs / 1000));
        return;
      }
      const left = Math.max(0, Math.round((endAtRef.current - now) / 1000));
      setRemaining(left);
      if (left <= 0) {
        finishRef.current(true);
      }
    };
    tick();
    const timer = window.setInterval(tick, 250);
    return () => window.clearInterval(timer);
  }, [running, mode]);

  useEffect(() => {
    if (!running) return;
    document.title = `${timerLabel(mode === "stopwatch" ? remaining : remaining)} · ТОГТМОЛ`;
    return () => {
      document.title = "ТОГТМОЛ · Study OS";
    };
  }, [running, remaining]);

  const startTimer = useCallback(() => {
    if (running) return;
    const fresh = sessionStartNaiveRef.current === null;
    if (fresh) {
      const now = Date.now();
      sessionStartEpochRef.current = now;
      sessionStartNaiveRef.current = naiveClient(now);
      setInterruptions(0);
      if (mode === "focus" && settings.soundOnFocus && !sound.running) {
        sound.start();
      }
    }
    if (mode !== "stopwatch") {
      const seconds = remaining > 0 ? remaining : total;
      if (remaining <= 0) setRemaining(total);
      endAtRef.current = Date.now() + seconds * 1000;
    } else {
      stopwatchRunRef.current = Date.now();
    }
    requestNotifications();
    setRunning(true);
  }, [mode, remaining, requestNotifications, running, settings.soundOnFocus, sound, total]);

  const pauseTimer = useCallback(() => {
    setRunning(false);
    if (mode === "stopwatch") {
      stopwatchAccumRef.current += Date.now() - stopwatchRunRef.current;
    }
    setInterruptions((count) => count + 1);
  }, [mode]);

  const resetTimer = useCallback(() => {
    setRunning(false);
    setRemaining(durations[mode]);
    setInterruptions(0);
    finishingRef.current = false;
    sessionStartNaiveRef.current = null;
    sessionStartEpochRef.current = 0;
    stopwatchAccumRef.current = 0;
    stopwatchRunRef.current = 0;
  }, [durations, mode]);

  const changeMode = useCallback(
    (next: Mode) => {
      if (next === mode) return;
      setRunning(false);
      setMode(next);
      setRemaining(durations[next]);
      setInterruptions(0);
      finishingRef.current = false;
      sessionStartNaiveRef.current = null;
      sessionStartEpochRef.current = 0;
      endAtRef.current = 0;
      stopwatchAccumRef.current = 0;
      stopwatchRunRef.current = 0;
    },
    [durations, mode],
  );

  const startMode = useCallback(
    (next: Mode) => {
      changeMode(next);
      window.setTimeout(() => {
        if (next === "stopwatch") {
          sessionStartEpochRef.current = Date.now();
          sessionStartNaiveRef.current = naiveClient();
          stopwatchAccumRef.current = 0;
          stopwatchRunRef.current = Date.now();
          setInterruptions(0);
          setRemaining(0);
          setRunning(true);
        } else {
          const seconds = durations[next];
          sessionStartEpochRef.current = Date.now();
          sessionStartNaiveRef.current = naiveClient();
          setInterruptions(0);
          endAtRef.current = Date.now() + seconds * 1000;
          setRemaining(seconds);
          setRunning(true);
          if (next === "focus" && settings.soundOnFocus && !sound.running) sound.start();
        }
      }, 30);
    },
    [changeMode, durations, settings.soundOnFocus, sound],
  );

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (summary) return;
      if (event.code === "Space") {
        event.preventDefault();
        if (running) pauseTimer();
        else startTimer();
      }
      if (event.key.toLowerCase() === "r") resetTimer();
      if (event.key.toLowerCase() === "f") void finishSession(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [finishSession, pauseTimer, resetTimer, running, startTimer, summary]);

  const saveSummary = async (startNext: boolean) => {
    if (!summary) return;
    setSaving(true);
    try {
      if (summary.sessionId) {
        await rateSession(summary.sessionId, rating, notes || null);
      }
      const nextMode = summary.nextMode;
      const autoNext = nextMode === "focus" ? settings.autoStartFocus : settings.autoStartBreaks;
      setSummary(null);
      prepareMode(nextMode);
      if (startNext || autoNext) {
        startMode(nextMode);
      } else {
        flash("Сесс хадгалагдлаа. Дараагийн блокоо төлөвлөөрэй.");
      }
      router.refresh();
    } finally {
      setSaving(false);
    }
  };

  const markTaskDone = async (task: Task) => {
    await toggleTaskDone(task.id, true);
    router.refresh();
  };

  const primaryLabel = mode === "stopwatch" ? (running ? "Түр зогсоох" : "Эхлүүлэх") : running ? "Түр зогсоох" : remaining < total && remaining > 0 ? "Үргэлжлүүлэх" : "Эхлүүлэх";

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Өнөөдөр</p>
          <p className="mono mt-1 text-[18px] font-bold text-white">
            {minutesLabel(taskMinutesToday)}
            <span className="text-[10px] text-[var(--dim)]"> / {settings.dailyGoalMinutes}м</span>
          </p>
        </div>
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Цуваа</p>
          <p className="mono mt-1 text-[18px] font-bold text-[var(--lime)]">{data.streak} өдөр</p>
        </div>
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Цикл</p>
          <p className="mono mt-1 text-[18px] font-bold text-[var(--violet)]">
            {cyclesDone}
            <span className="text-[10px] text-[var(--dim)]"> / {settings.cyclesBeforeLong}</span>
          </p>
        </div>
        <div className="panel-quiet px-3.5 py-2.5">
          <p className="label">Амбиент</p>
          <p className="mt-1 truncate text-[12px] font-bold text-[var(--mint)]">{presetLabel(sound.preset)}</p>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_350px]">
        <div className="space-y-4">
          <div className="panel-glow overflow-hidden p-5 sm:p-7">
            <div className="pointer-events-none absolute inset-0 hero-grid opacity-30" aria-hidden />
            <div className="relative">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap gap-1.5">
                  {MODES.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => changeMode(item.id)}
                      className={cx(
                        "rounded-full border px-3 py-1.5 text-[11px] font-bold transition",
                        mode === item.id
                          ? "border-[rgba(201,247,90,0.5)] bg-[rgba(201,247,90,0.14)] text-[#e6ffb8]"
                          : "border-[var(--line)] bg-white/[0.03] text-[var(--muted)] hover:text-white",
                      )}
                    >
                      <span className="mr-1" aria-hidden>
                        {item.glyph}
                      </span>
                      {item.label}
                    </button>
                  ))}
                </div>
                <span className={cx("chip", running ? "chip-live" : "")}>
                  <span
                    className={cx(
                      "h-1.5 w-1.5 rounded-full",
                      running ? "pulse-dot bg-[var(--mint)]" : "bg-white/35",
                    )}
                  />
                  {running ? "Ажиллаж байна" : remaining < total ? "Түр зогссон" : "Бэлэн"}
                </span>
              </div>

              <div className="mt-4 grid items-center gap-5 md:grid-cols-[270px_minmax(0,1fr)]">
                <div className="relative mx-auto aspect-square w-full max-w-[270px]">
                  <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90" aria-hidden>
                    <defs>
                      <linearGradient id="timer-ring" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#e2ff96" />
                        <stop offset="55%" stopColor="#b8ef4a" />
                        <stop offset="100%" stopColor="#5eead4" />
                      </linearGradient>
                    </defs>
                    <circle cx="100" cy="100" r="88" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="5" />
                    <circle
                      cx="100"
                      cy="100"
                      r="88"
                      fill="none"
                      stroke="rgba(255,255,255,0.045)"
                      strokeWidth="1"
                      strokeDasharray="2 7"
                    />
                    <circle
                      cx="100"
                      cy="100"
                      r="88"
                      fill="none"
                      stroke="url(#timer-ring)"
                      strokeWidth="6"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * 88}
                      strokeDashoffset={2 * Math.PI * 88 * (1 - progress / 100)}
                      style={{ transition: "stroke-dashoffset 0.4s linear", filter: "drop-shadow(0 0 10px rgba(201,247,90,0.35))" }}
                    />
                  </svg>
                  <div className="absolute inset-0 grid place-items-center text-center">
                    <div>
                      <p className="label">
                        {mode === "focus" ? "Гүн анхаарал" : mode === "stopwatch" ? "Чөлөөт цаг" : "Сэргээх"}
                      </p>
                      <p className="mono mt-2 text-[48px] font-extrabold leading-none tracking-tight text-white sm:text-[54px]">
                        {timerLabel(mode === "stopwatch" ? remaining : remaining)}
                      </p>
                      <p className="mt-2 text-[10.5px] font-semibold text-[var(--muted)]">
                        {interruptions > 0 ? `${interruptions} тасалдал` : "Тасалдалгүй"} ·{" "}
                        {minutesLabel(elapsed / 60)} өнгөрсөн
                      </p>
                    </div>
                  </div>
                </div>

                <div className="min-w-0">
                  <div className="rounded-2xl border border-[var(--line)] bg-black/25 p-3.5">
                    <div className="flex items-center justify-between gap-2">
                      <p className="label">Хавсарсан ажил</p>
                      {activeTask ? (
                        <button
                          type="button"
                          onClick={() => setTaskId(null)}
                          className="text-[10px] font-semibold text-[var(--dim)] hover:text-white"
                        >
                          Салгах
                        </button>
                      ) : null}
                    </div>
                    {activeTask ? (
                      <div className="mt-2">
                        <p className="text-[13px] font-bold leading-snug text-white">{activeTask.title}</p>
                        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[10.5px] text-[var(--dim)]">
                          <span className="chip">
                            <SubjectDot
                              color={
                                data.subjects.find((subject) => subject.id === activeTask.subjectId)?.color ??
                                "#94a3b8"
                              }
                            />
                            {data.subjects.find((subject) => subject.id === activeTask.subjectId)?.name ??
                              "Сэдэвгүй"}
                          </span>
                          <span>{activeTask.estimateMinutes} мин тооцоо</span>
                          <span>{minutesLabel(activeTask.focusSeconds / 60)} бүртгэлтэй</span>
                        </div>
                      </div>
                    ) : (
                      <p className="mt-2 text-[11.5px] leading-relaxed text-[var(--muted)]">
                        Ажил сонгоогүй — чөлөөт анхаарал. Баруун талын дарааллаас сонгож болно.
                      </p>
                    )}
                    <div className="mt-2.5 grid gap-2">
                      <select
                        className="select"
                        value={taskId ?? ""}
                        onChange={(event) => setTaskId(event.target.value ? Number(event.target.value) : null)}
                        aria-label="Ажил сонгох"
                      >
                        <option value="">Чөлөөт анхаарал</option>
                        {data.tasks.map((task) => (
                          <option key={task.id} value={task.id}>
                            {task.title} · {task.estimateMinutes}м
                          </option>
                        ))}
                      </select>
                      {!activeTask ? (
                        <select
                          className="select"
                          value={freeSubjectId ?? ""}
                          onChange={(event) =>
                            setFreeSubjectId(event.target.value ? Number(event.target.value) : null)
                          }
                          aria-label="Сэдэв сонгох"
                        >
                          <option value="">Сэдэвгүй</option>
                          {data.subjects.map((subject) => (
                            <option key={subject.id} value={subject.id}>
                              {subject.name}
                            </option>
                          ))}
                        </select>
                      ) : null}
                    </div>
                  </div>

                  <div className="mt-3 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={running ? pauseTimer : startTimer}
                      className="btn btn-primary h-12 flex-1 text-[14px]"
                    >
                      {running ? "❚❚ Түр зогсоох" : `▶ ${primaryLabel}`}
                    </button>
                    <button type="button" onClick={resetTimer} className="btn btn-ghost h-12 px-3" title="Дахин тохируулах (R)">
                      ↺
                    </button>
                    <button
                      type="button"
                      onClick={() => void finishSession(false)}
                      disabled={elapsed < 5 && !running}
                      className="btn btn-ghost h-12"
                    >
                      Дуусгах
                    </button>
                  </div>
                  <div className="mt-3 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      {Array.from({ length: settings.cyclesBeforeLong }).map((_, index) => (
                        <span
                          key={index}
                          className={cx(
                            "h-1.5 rounded-full transition-all",
                            index < cyclesDone % (settings.cyclesBeforeLong || 1) || (cyclesDone > 0 && cyclesDone % settings.cyclesBeforeLong === 0)
                              ? "w-6 bg-[var(--lime)]"
                              : "w-3 bg-white/15",
                          )}
                        />
                      ))}
                      <span className="ml-1 text-[10px] text-[var(--dim)]">
                        {settings.focusMinutes}м фокус · {settings.shortBreakMinutes}м амралт
                      </span>
                    </div>
                    <span className="hidden text-[10px] text-[var(--dim)] sm:block">
                      Space эхлүүлэх · R дахин · F дуусгах
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-5 rounded-xl border border-[var(--line)] bg-black/20 px-3.5 py-2.5">
                <div className="flex items-center justify-between text-[10.5px] text-[var(--muted)]">
                  <span>Өдрийн зорилт</span>
                  <span className="mono">
                    {minutesLabel(taskMinutesToday)} / {minutesLabel(settings.dailyGoalMinutes)}
                  </span>
                </div>
                <Progress className="mt-2" value={dailyPercent} height={5} />
              </div>
            </div>
          </div>

          <div className="panel p-5">
            <SoundMixer />
          </div>
        </div>

        <div className="space-y-4">
          <div className="panel p-4">
            <SectionHeading
              label="Фокусын дараалал"
              title={`${data.tasks.length} нээлттэй ажил`}
              action={
                <Link href="/plan" className="text-[10.5px] font-semibold text-[var(--muted)] hover:text-white">
                  Төлөвлөх →
                </Link>
              }
            />
            <div className="mt-3 max-h-[420px] space-y-2 overflow-y-auto pr-1 scroll-thin">
              {data.tasks.slice(0, 14).map((task) => {
                const subject = data.subjects.find((item) => item.id === task.subjectId);
                const selected = task.id === taskId;
                return (
                  <div
                    key={task.id}
                    className={cx(
                      "group rounded-xl border p-2.5 transition",
                      selected
                        ? "border-[rgba(201,247,90,0.45)] bg-[rgba(201,247,90,0.09)]"
                        : "border-[var(--line)] bg-white/[0.025] hover:border-white/20",
                    )}
                  >
                    <div className="flex items-start gap-2">
                      <button
                        type="button"
                        onClick={() => void markTaskDone(task)}
                        className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-[5px] border border-white/25 text-[9px] text-transparent transition hover:border-[var(--lime)] hover:text-[var(--lime)]"
                        aria-label={`${task.title} дуусгах`}
                      >
                        ✓
                      </button>
                      <button
                        type="button"
                        onClick={() => setTaskId(task.id)}
                        className="min-w-0 flex-1 text-left"
                      >
                        <p className="truncate text-[11.5px] font-semibold text-[#e2e8f0]">{task.title}</p>
                        <p className="mt-0.5 flex items-center gap-1.5 text-[10px] text-[var(--dim)]">
                          <SubjectDot color={subject?.color ?? "#94a3b8"} size={6} />
                          {subject?.name ?? "Сэдэвгүй"} · {task.estimateMinutes}м
                          {task.dueDate ? ` · ${task.dueDate.slice(5)}` : ""}
                        </p>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTaskId(task.id);
                          startMode("focus");
                        }}
                        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-[var(--line)] text-[10px] text-[var(--muted)] transition hover:border-[var(--lime)] hover:text-[var(--lime)]"
                        aria-label={`${task.title} эхлүүлэх`}
                      >
                        ▶
                      </button>
                    </div>
                  </div>
                );
              })}
              {data.tasks.length === 0 ? (
                <p className="rounded-xl border border-dashed border-[var(--line-strong)] px-3 py-6 text-center text-[11px] text-[var(--dim)]">
                  Бүх ажил дууссан. Чөлөөт анхаарлаа бүртгээрэй.
                </p>
              ) : null}
            </div>
          </div>

          <div className="panel p-4">
            <SectionHeading label="Бүртгэл" title="Өнөөдрийн сессүүд" />
            <div className="mt-3 space-y-2">
              {data.todaySessions.length > 0 ? (
                data.todaySessions.slice(0, 8).map((session) => (
                  <div key={session.id} className="flex items-center gap-2.5 rounded-xl border border-[var(--line)] bg-white/[0.025] px-2.5 py-2">
                    <span className="mono text-[10px] text-[var(--dim)]">{session.timeLabel}</span>
                    <SubjectDot color={session.subjectColor ?? "#94a3b8"} size={6} />
                    <span className="min-w-0 flex-1 truncate text-[11px] text-[#d6dde8]">
                      {session.taskTitle ?? session.subjectName ?? "Чөлөөт"}
                    </span>
                    <span className="mono text-[10px] font-semibold text-white">
                      {minutesLabel(session.actualSeconds / 60)}
                    </span>
                  </div>
                ))
              ) : (
                <p className="rounded-xl border border-dashed border-[var(--line-strong)] px-3 py-5 text-center text-[11px] text-[var(--dim)]">
                  Өнөөдөр бүртгэл алга. Эхний блокоо эхлүүл.
                </p>
              )}
            </div>
            <div className="mt-3 rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2.5">
              <div className="flex items-center justify-between text-[10.5px]">
                <span className="text-[var(--muted)]">Нийт анхаарал</span>
                <span className="mono font-bold text-[var(--lime)]">{minutesLabel(taskMinutesToday)}</span>
              </div>
              <div className="mt-1.5 flex items-center justify-between text-[10.5px]">
                <span className="text-[var(--muted)]">Анхаарлын чанар</span>
                <span className="mono font-bold text-[var(--violet)]">
                  {data.todaySessions.filter((session) => session.rating).length > 0
                    ? (
                        data.todaySessions.reduce((sum, session) => sum + (session.rating ?? 0), 0) /
                        data.todaySessions.filter((session) => session.rating).length
                      ).toFixed(1)
                    : "—"}
                </span>
              </div>
            </div>
          </div>

          <div className="panel p-4">
            <SectionHeading label="Протокол" title="Гүн ажлын дүрэм" />
            <ul className="mt-3 space-y-2.5 text-[11.5px] leading-relaxed text-[var(--muted)]">
              <li className="flex gap-2">
                <span className="text-[var(--lime)]">01</span>
                <span>Нэг блокт нэг л ажил. Утасны мэдэгдлийг хаа.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-[var(--lime)]">02</span>
                <span>Амралтад дэлгэцээс холдох — 5 минут хангалттай.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-[var(--lime)]">03</span>
                <span>Сесс бүрийн дараа 1–5 үнэлгээ өг. Чанар → тохируулга.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-[var(--mint)]">04</span>
                <span>Чихэвчтэй ажиллаж, бинауралыг туршиж үз.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <Modal
        open={summary !== null}
        onClose={() => {
          if (!summary) return;
          setSummary(null);
          prepareMode(summary.nextMode);
        }}
        title={summary?.mode === "focus" ? "Блок бүртгэгдлээ" : "Сэргээх цаг дууслаа"}
        subtitle={
          summary
            ? `${summary.minutes} минут · ${summary.completed ? "бүрэн гүйцэтгэл" : "түр зогсолт"} · ${presetLabel(sound.preset)}`
            : undefined
        }
      >
        {summary ? (
          <div className="space-y-4">
            <div className="rounded-2xl border border-[var(--line)] bg-white/[0.03] p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="label">Бүртгэсэн хугацаа</p>
                  <p className="mono mt-1 text-[28px] font-extrabold leading-none text-[var(--lime)]">
                    {summary.minutes} мин
                  </p>
                </div>
                <div className="text-right">
                  <p className="label">Ажил</p>
                  <p className="mt-1 max-w-[180px] truncate text-[12px] font-semibold text-white">
                    {summary.taskTitle ?? "Чөлөөт анхаарал"}
                  </p>
                </div>
              </div>
            </div>

            <div>
              <p className="label">Анхаарлын чанар</p>
              <div className="mt-2 flex gap-1.5">
                {[1, 2, 3, 4, 5].map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setRating(value)}
                    className={cx(
                      "flex-1 rounded-xl border py-2 text-[14px] transition",
                      value <= rating
                        ? "border-[rgba(201,247,90,0.5)] bg-[rgba(201,247,90,0.16)] text-[var(--lime)]"
                        : "border-[var(--line)] bg-white/[0.03] text-[var(--dim)]",
                    )}
                    aria-label={`${value} үнэлгээ`}
                  >
                    ★
                  </button>
                ))}
              </div>
              <p className="mt-1.5 text-[10px] text-[var(--dim)]">
                {["Маш сул", "Сул", "Хэвийн", "Сайн", "Гүнзгий"][rating - 1]} төвлөрөл
              </p>
            </div>

            <div>
              <label className="label" htmlFor="session-notes">
                Тэмдэглэл (сонголтоор)
              </label>
              <textarea
                id="session-notes"
                className="textarea mt-2"
                rows={3}
                placeholder="Юу ажилласан, дараа юу үргэлжлүүлэх вэ?"
                value={notes}
                onChange={(event) => setNotes(event.target.value)}
              />
            </div>

            <div className="flex flex-wrap justify-end gap-2">
              <button type="button" className="btn btn-ghost" onClick={() => void saveSummary(false)} disabled={saving}>
                Хадгалаад хаах
              </button>
              <button type="button" className="btn btn-primary" onClick={() => void saveSummary(true)} disabled={saving}>
                {saving ? "Хадгалж байна…" : summary.nextMode === "focus" ? "Дараагийн фокус" : "Амралт эхлүүлэх"}
              </button>
            </div>
          </div>
        ) : null}
      </Modal>

      {toast ? <Toast message={toast} /> : null}
    </div>
  );
}
