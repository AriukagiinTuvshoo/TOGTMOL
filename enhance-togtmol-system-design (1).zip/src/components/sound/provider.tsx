"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import Link from "next/link";
import { updateSettings } from "@/app/actions";
import { getEngine } from "@/components/sound/engine";
import { PRESET_BY_ID, PRESETS, type LayerId } from "@/lib/sound";

type SoundContextValue = {
  mix: Record<string, number>;
  preset: string;
  volume: number;
  running: boolean;
  supported: boolean;
  setLayerVolume: (id: LayerId, value: number) => void;
  setMasterVolume: (value: number) => void;
  applyPreset: (id: string) => void;
  toggle: () => void;
  start: () => void;
  pause: () => void;
  chime: () => void;
  activeLayers: number;
};

const SoundContext = createContext<SoundContextValue | null>(null);

export function SoundProvider({
  children,
  initialMix,
  initialPreset,
  initialVolume,
}: {
  children: ReactNode;
  initialMix: Record<string, number>;
  initialPreset: string;
  initialVolume: number;
}) {
  const presetMix = PRESET_BY_ID.get(initialPreset)?.mix ?? PRESETS[0].mix;
  const [mix, setMix] = useState<Record<string, number>>(() =>
    Object.keys(initialMix ?? {}).length > 0 ? initialMix : presetMix,
  );
  const [preset, setPreset] = useState(initialPreset);
  const [volume, setVolume] = useState(initialVolume);
  const [running, setRunning] = useState(false);
  const [supported, setSupported] = useState(true);
  const dirty = useRef(false);

  useEffect(() => {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    setSupported(Boolean(Ctor));
  }, []);

  useEffect(() => {
    if (!dirty.current) return;
    const timer = window.setTimeout(() => {
      void updateSettings({ soundMix: mix, masterVolume: volume, lastPreset: preset });
    }, 900);
    return () => window.clearTimeout(timer);
  }, [mix, volume, preset]);

  const start = useCallback(() => {
    const engine = getEngine();
    engine.setMix(mix, volume);
    void engine
      .start()
      .then(() => setRunning(true))
      .catch(() => setSupported(false));
  }, [mix, volume]);

  const pause = useCallback(() => {
    void getEngine().pause();
    setRunning(false);
  }, []);

  const toggle = useCallback(() => {
    if (running) pause();
    else start();
  }, [running, pause, start]);

  const setLayerVolume = useCallback((id: LayerId, value: number) => {
    dirty.current = true;
    setMix((current) => ({ ...current, [id]: value }));
    const engine = getEngine();
    engine.setLayer(id, value);
    if (value > 0.01) {
      void engine.start().then(() => setRunning(true)).catch(() => undefined);
    }
  }, []);

  const setMasterVolume = useCallback((value: number) => {
    dirty.current = true;
    setVolume(value);
    getEngine().setMaster(value);
  }, []);

  const applyPreset = useCallback(
    (id: string) => {
      const next = PRESET_BY_ID.get(id);
      if (!next) return;
      dirty.current = true;
      setPreset(id);
      setMix({ ...next.mix });
      const engine = getEngine();
      engine.setMix(next.mix, volume);
      if (Object.keys(next.mix).length === 0) {
        engine.stopAll();
        void engine.pause();
        setRunning(false);
        return;
      }
      void engine.start().then(() => setRunning(true)).catch(() => undefined);
    },
    [volume],
  );

  const chime = useCallback(() => {
    try {
      getEngine().chime("complete");
    } catch {
      /* audio not available */
    }
  }, []);

  const value = useMemo<SoundContextValue>(
    () => ({
      mix,
      preset,
      volume,
      running,
      supported,
      setLayerVolume,
      setMasterVolume,
      applyPreset,
      toggle,
      start,
      pause,
      chime,
      activeLayers: Object.values(mix).filter((level) => level > 0.01).length,
    }),
    [
      mix,
      preset,
      volume,
      running,
      supported,
      setLayerVolume,
      setMasterVolume,
      applyPreset,
      toggle,
      start,
      pause,
      chime,
    ],
  );

  return <SoundContext.Provider value={value}>{children}</SoundContext.Provider>;
}

export function useSound(): SoundContextValue {
  const context = useContext(SoundContext);
  if (!context) throw new Error("useSound must be used inside SoundProvider");
  return context;
}

export function MiniPlayer() {
  const { running, preset, toggle, activeLayers, volume, setMasterVolume } = useSound();
  const name = PRESET_BY_ID.get(preset)?.name ?? "Чимээгүй";

  return (
    <div className="rounded-2xl border border-[var(--line)] bg-white/[0.035] p-3">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={toggle}
          aria-label={running ? "Дуу түр зогсоох" : "Дуу тоглуулах"}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-[rgba(201,247,90,0.35)] bg-[rgba(201,247,90,0.14)] text-[13px] text-[var(--lime)]"
        >
          {running ? "❚❚" : "▶"}
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[12.5px] font-bold text-white">{name}</p>
          <p className="mt-0.5 truncate text-[10.5px] text-[var(--dim)]">
            {running ? `${activeLayers} давхарга · тоглож байна` : "Амбиент зогссон"}
          </p>
        </div>
        {running ? (
          <span className="equalizer" aria-hidden>
            <span />
            <span />
            <span />
            <span />
          </span>
        ) : null}
      </div>
      <div className="mt-2.5 flex items-center gap-2">
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(volume * 100)}
          onChange={(event) => setMasterVolume(Number(event.target.value) / 100)}
          className="slider flex-1"
          aria-label="Ерөнхий дууны түвшин"
        />
        <Link href="/focus" className="text-[10.5px] font-semibold text-[var(--muted)] underline-offset-2 hover:text-white hover:underline">
          Микс
        </Link>
      </div>
    </div>
  );
}
