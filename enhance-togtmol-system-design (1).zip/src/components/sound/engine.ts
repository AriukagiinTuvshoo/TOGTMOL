import type { LayerId } from "@/lib/sound";

type LayerHandle = { gain: GainNode; stop: () => void };

type Builder = (ctx: AudioContext, destination: GainNode) => () => void;

function noiseBuffer(ctx: AudioContext, seconds: number, kind: "white" | "pink" | "brown"): AudioBuffer {
  const length = Math.floor(ctx.sampleRate * seconds);
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  let b0 = 0;
  let b1 = 0;
  let b2 = 0;
  let b3 = 0;
  let b4 = 0;
  let b5 = 0;
  let b6 = 0;
  for (let index = 0; index < length; index += 1) {
    const white = Math.random() * 2 - 1;
    if (kind === "brown") {
      last = (last + 0.02 * white) / 1.02;
      data[index] = last * 3.2;
    } else if (kind === "pink") {
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.969 * b2 + white * 0.153852;
      b3 = 0.8665 * b3 + white * 0.3104856;
      b4 = 0.55 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.016898;
      data[index] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.1;
      b6 = white * 0.115926;
    } else {
      data[index] = white;
    }
  }
  return buffer;
}

function makeLfo(ctx: AudioContext, rate: number, depth: number, target: AudioParam): OscillatorNode {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "sine";
  osc.frequency.value = rate;
  gain.gain.value = depth;
  osc.connect(gain);
  gain.connect(target);
  osc.start();
  return osc;
}

function loopNoise(ctx: AudioContext, destination: GainNode, seconds: number, kind: "white" | "pink" | "brown") {
  const source = ctx.createBufferSource();
  source.buffer = noiseBuffer(ctx, seconds, kind);
  source.loop = true;
  source.connect(destination);
  source.start();
  return source;
}

const builders: Record<LayerId, Builder> = {
  rain: (ctx, out) => {
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer(ctx, 4, "pink");
    source.loop = true;
    const high = ctx.createBiquadFilter();
    high.type = "highpass";
    high.frequency.value = 620;
    const low = ctx.createBiquadFilter();
    low.type = "lowpass";
    low.frequency.value = 5400;
    low.Q.value = 0.4;
    const body = ctx.createGain();
    body.gain.value = 0.85;
    source.connect(high).connect(low).connect(body).connect(out);
    const lfo = makeLfo(ctx, 0.07, 900, low.frequency);
    source.start();
    return () => {
      lfo.stop();
      source.stop();
    };
  },
  brown: (ctx, out) => {
    const source = loopNoise(ctx, out, 4, "brown");
    const low = ctx.createBiquadFilter();
    low.type = "lowpass";
    low.frequency.value = 780;
    source.disconnect();
    source.connect(low).connect(out);
    return () => source.stop();
  },
  ocean: (ctx, out) => {
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer(ctx, 5, "brown");
    source.loop = true;
    const low = ctx.createBiquadFilter();
    low.type = "lowpass";
    low.frequency.value = 520;
    const swell = ctx.createGain();
    swell.gain.value = 0.55;
    source.connect(low).connect(swell).connect(out);
    const lfo = makeLfo(ctx, 0.075, 0.42, swell.gain);
    source.start();
    return () => {
      lfo.stop();
      source.stop();
    };
  },
  wind: (ctx, out) => {
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer(ctx, 5, "pink");
    source.loop = true;
    const band = ctx.createBiquadFilter();
    band.type = "bandpass";
    band.frequency.value = 480;
    band.Q.value = 0.6;
    const gain = ctx.createGain();
    gain.gain.value = 0.6;
    source.connect(band).connect(gain).connect(out);
    const filterLfo = makeLfo(ctx, 0.045, 220, band.frequency);
    const gainLfo = makeLfo(ctx, 0.09, 0.18, gain.gain);
    source.start();
    return () => {
      filterLfo.stop();
      gainLfo.stop();
      source.stop();
    };
  },
  cafe: (ctx, out) => {
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer(ctx, 4, "pink");
    source.loop = true;
    const band = ctx.createBiquadFilter();
    band.type = "bandpass";
    band.frequency.value = 900;
    band.Q.value = 0.7;
    const gain = ctx.createGain();
    gain.gain.value = 0.5;
    source.connect(band).connect(gain).connect(out);
    const lfo = makeLfo(ctx, 0.32, 140, band.frequency);
    source.start();
    return () => {
      lfo.stop();
      source.stop();
    };
  },
  fire: (ctx, out) => {
    const bed = ctx.createBufferSource();
    bed.buffer = noiseBuffer(ctx, 4, "brown");
    bed.loop = true;
    const low = ctx.createBiquadFilter();
    low.type = "lowpass";
    low.frequency.value = 950;
    bed.connect(low).connect(out);
    bed.start();
    const burstBuffer = noiseBuffer(ctx, 0.22, "white");
    const timer = window.setInterval(() => {
      if (Math.random() > 0.62) return;
      const source = ctx.createBufferSource();
      source.buffer = burstBuffer;
      source.playbackRate.value = 0.7 + Math.random() * 0.9;
      const band = ctx.createBiquadFilter();
      band.type = "bandpass";
      band.frequency.value = 1200 + Math.random() * 2400;
      band.Q.value = 1.1;
      const gain = ctx.createGain();
      const now = ctx.currentTime;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.16 + Math.random() * 0.2, now + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);
      source.connect(band).connect(gain).connect(out);
      source.start(now);
      source.stop(now + 0.2);
    }, 210);
    return () => {
      window.clearInterval(timer);
      bed.stop();
    };
  },
  night: (ctx, out) => {
    const bed = ctx.createBufferSource();
    bed.buffer = noiseBuffer(ctx, 4, "pink");
    bed.loop = true;
    const high = ctx.createBiquadFilter();
    high.type = "highpass";
    high.frequency.value = 3600;
    const bedGain = ctx.createGain();
    bedGain.gain.value = 0.16;
    bed.connect(high).connect(bedGain).connect(out);
    bed.start();
    const timer = window.setInterval(() => {
      if (Math.random() > 0.7) return;
      const now = ctx.currentTime;
      for (let index = 0; index < 3; index += 1) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = 3900 + Math.random() * 700;
        const start = now + index * 0.085;
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.05, start + 0.012);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.07);
        osc.connect(gain).connect(out);
        osc.start(start);
        osc.stop(start + 0.09);
      }
    }, 1500);
    return () => {
      window.clearInterval(timer);
      bed.stop();
    };
  },
  pad: (ctx, out) => {
    const chords = [
      [220, 261.63, 329.63, 392],
      [174.61, 220, 261.63, 329.63],
      [196, 246.94, 293.66, 392],
      [261.63, 329.63, 392, 493.88],
    ];
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 1250;
    filter.Q.value = 0.5;
    const gain = ctx.createGain();
    gain.gain.value = 0.32;
    filter.connect(gain).connect(out);
    const oscillators = chords[0].map((frequency) => {
      const osc = ctx.createOscillator();
      osc.type = "triangle";
      osc.frequency.value = frequency;
      osc.detune.value = (Math.random() - 0.5) * 8;
      const voice = ctx.createGain();
      voice.gain.value = 0.16;
      osc.connect(voice).connect(filter);
      osc.start();
      return { osc, voice };
    });
    const filterLfo = makeLfo(ctx, 0.03, 400, filter.frequency);
    let chordIndex = 0;
    const timer = window.setInterval(() => {
      chordIndex = (chordIndex + 1) % chords.length;
      const chord = chords[chordIndex];
      const now = ctx.currentTime;
      oscillators.forEach(({ osc, voice }, index) => {
        osc.frequency.setTargetAtTime(chord[index] ?? chord[0], now, 2.4);
        voice.gain.setTargetAtTime(0.1 + Math.random() * 0.1, now, 3);
      });
    }, 14_000);
    return () => {
      window.clearInterval(timer);
      filterLfo.stop();
      oscillators.forEach(({ osc }) => osc.stop());
    };
  },
  piano: (ctx, out) => {
    const scale = [261.63, 293.66, 329.63, 392, 440, 523.25, 587.33, 659.25];
    const play = () => {
      const frequency = scale[Math.floor(Math.random() * scale.length)];
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const overtone = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 2600;
      osc.type = "sine";
      overtone.type = "triangle";
      osc.frequency.value = frequency;
      overtone.frequency.value = frequency * 2.01;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.22, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.4);
      const overtoneGain = ctx.createGain();
      overtoneGain.gain.value = 0.22;
      osc.connect(filter);
      overtone.connect(overtoneGain).connect(filter);
      filter.connect(gain).connect(out);
      osc.start(now);
      overtone.start(now);
      osc.stop(now + 3.5);
      overtone.stop(now + 3.5);
    };
    play();
    const timer = window.setInterval(play, 2350);
    return () => window.clearInterval(timer);
  },
  bells: (ctx, out) => {
    const bell = () => {
      const now = ctx.currentTime;
      const roots = [523.25, 587.33, 659.25, 783.99];
      const root = roots[Math.floor(Math.random() * roots.length)];
      [1, 2.76, 5.4].forEach((ratio, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = root * ratio;
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.12 / (index + 1), now + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 5.2 - index * 0.9);
        osc.connect(gain).connect(out);
        osc.start(now);
        osc.stop(now + 5.4);
      });
    };
    const first = window.setTimeout(bell, 2500);
    const timer = window.setInterval(bell, 26_000);
    return () => {
      window.clearTimeout(first);
      window.clearInterval(timer);
    };
  },
  binaural: (ctx, out) => {
    const merge = ctx.createChannelMerger(2);
    const left = ctx.createOscillator();
    const right = ctx.createOscillator();
    left.type = "sine";
    right.type = "sine";
    left.frequency.value = 190;
    right.frequency.value = 200;
    const leftGain = ctx.createGain();
    const rightGain = ctx.createGain();
    leftGain.gain.value = 0.18;
    rightGain.gain.value = 0.18;
    left.connect(leftGain).connect(merge, 0, 0);
    right.connect(rightGain).connect(merge, 0, 1);
    merge.connect(out);
    left.start();
    right.start();
    return () => {
      left.stop();
      right.stop();
    };
  },
};

export class AmbienceEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private active = new Map<LayerId, LayerHandle>();
  private desired: Record<string, number> = {};
  private masterVolume = 0.7;
  private paused = false;

  get running(): boolean {
    return Boolean(this.ctx) && this.ctx?.state === "running" && !this.paused;
  }

  private ensureContext(): AudioContext {
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) throw new Error("Web Audio API дэмжигдэхгүй байна.");
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.masterVolume;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  setMaster(volume: number) {
    this.masterVolume = Math.max(0, Math.min(1, volume));
    if (this.ctx && this.master) {
      this.master.gain.setTargetAtTime(this.masterVolume, this.ctx.currentTime, 0.12);
    }
  }

  setMix(mix: Record<string, number>, master?: number) {
    this.desired = { ...mix };
    if (typeof master === "number") this.setMaster(master);
    if (this.ctx) this.reconcile();
  }

  setLayer(id: LayerId, volume: number) {
    this.desired[id] = Math.max(0, Math.min(1, volume));
    if (!this.ctx) return;
    this.reconcile();
  }

  private reconcile() {
    const ctx = this.ctx;
    const master = this.master;
    if (!ctx || !master) return;
    const now = ctx.currentTime;
    (Object.keys(builders) as LayerId[]).forEach((id) => {
      const target = this.desired[id] ?? 0;
      const existing = this.active.get(id);
      if (target <= 0.002) {
        if (existing) {
          existing.gain.gain.setTargetAtTime(0.0001, now, 0.18);
          const handle = existing;
          window.setTimeout(() => {
            try {
              handle.stop();
              handle.gain.disconnect();
            } catch {
              /* node already stopped */
            }
          }, 900);
          this.active.delete(id);
        }
        return;
      }
      if (!existing) {
        const gain = ctx.createGain();
        gain.gain.value = 0.0001;
        gain.connect(master);
        const stop = builders[id](ctx, gain);
        gain.gain.setTargetAtTime(target, now + 0.05, 0.6);
        this.active.set(id, { gain, stop });
      } else {
        existing.gain.gain.setTargetAtTime(target, now, 0.18);
      }
    });
  }

  async start() {
    const ctx = this.ensureContext();
    this.paused = false;
    await ctx.resume();
    this.reconcile();
  }

  async pause() {
    this.paused = true;
    if (this.ctx) await this.ctx.suspend();
  }

  stopAll() {
    this.active.forEach((handle) => {
      try {
        handle.gain.gain.setTargetAtTime(0.0001, this.ctx?.currentTime ?? 0, 0.1);
        handle.stop();
      } catch {
        /* ignore */
      }
    });
    this.active.clear();
    this.desired = {};
  }

  chime(kind: "complete" | "start" = "complete") {
    const ctx = this.ensureContext();
    const notes = kind === "complete" ? [523.25, 659.25, 783.99, 1046.5] : [392, 523.25];
    const now = ctx.currentTime + 0.05;
    notes.forEach((frequency, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = frequency;
      const start = now + index * (kind === "complete" ? 0.16 : 0.1);
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(kind === "complete" ? 0.22 : 0.1, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 2.1);
      osc.connect(gain).connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 2.2);
    });
  }
}

let engineInstance: AmbienceEngine | null = null;

export function getEngine(): AmbienceEngine {
  if (typeof window === "undefined") {
    engineInstance = new AmbienceEngine();
    return engineInstance;
  }
  const holder = window as unknown as { __togtmolEngine?: AmbienceEngine };
  if (!holder.__togtmolEngine) holder.__togtmolEngine = new AmbienceEngine();
  return holder.__togtmolEngine;
}
