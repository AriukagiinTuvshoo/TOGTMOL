"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  CloudRain, Waves, Trees, Coffee, Flame, Wind, AudioLines, AudioWaveform,
  WavesLadder, Orbit, Brain, Disc3, Cat, Volume2, VolumeX, Play, Square,
  Sparkles, Headphones, ChevronDown, SlidersHorizontal,
} from "lucide-react";
import { CHANNELS, PRESETS, engine, type ChannelId } from "@/lib/audio-engine";

const ICONS: Record<string, any> = {
  "cloud-rain": CloudRain, waves: Waves, trees: Trees, coffee: Coffee,
  flame: Flame, wind: Wind, "audio-lines": AudioLines, "audio-waveform": AudioWaveform,
  "waves-ladder": WavesLadder, orbit: Orbit, brain: Brain, disc: Disc3, cat: Cat,
};

const DEFAULT_MIX: Record<ChannelId, number> = {
  rain: 0, ocean: 0, forest: 0, cafe: 0, fire: 0, wind: 0,
  white: 0, pink: 0, brown: 0, drone: 0, binaural: 0, lofi: 0, purr: 0,
};

export default function AudioMixer({
  accent, onPlayingChange,
}: { accent: string; onPlayingChange?: (n: number) => void }) {
  const [mix, setMix] = useState<Record<ChannelId, number>>(DEFAULT_MIX);
  const [master, setMaster] = useState(0.8);
  const [activePreset, setActivePreset] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [muted, setMuted] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mixRef = useRef(mix);
  mixRef.current = mix;

  // load persisted
  useEffect(() => {
    try {
      const raw = localStorage.getItem("togtmol-mix-v8");
      if (raw) {
        const { mix: m, master: ms, preset } = JSON.parse(raw);
        if (m) setMix({ ...DEFAULT_MIX, ...m });
        if (typeof ms === "number") setMaster(ms);
        if (preset) setActivePreset(preset);
      }
    } catch { /* noop */ }
  }, []);

  // persist
  useEffect(() => {
    try {
      localStorage.setItem("togtmol-mix-v8", JSON.stringify({ mix, master, preset: activePreset }));
    } catch { /* noop */ }
  }, [mix, master, activePreset]);

  useEffect(() => {
    engine.setMaster(muted ? 0 : master);
  }, [master, muted]);

  const activeCount = Object.values(mix).filter((v) => v > 0.01).length;

  useEffect(() => {
    onPlayingChange?.(activeCount);
  }, [activeCount, onPlayingChange]);

  const setChannel = useCallback((id: ChannelId, v: number) => {
    setMix((prev) => ({ ...prev, [id]: v }));
    engine.setChannel(id, v);
    setActivePreset(null);
  }, []);

  const applyPreset = useCallback((id: string) => {
    const p = PRESETS.find((x) => x.id === id);
    if (!p) return;
    const next = { ...DEFAULT_MIX, ...p.mix } as Record<ChannelId, number>;
    setMix(next);
    engine.applyMix(next);
    setActivePreset(id);
  }, []);

  const stopAll = useCallback(() => {
    setMix({ ...DEFAULT_MIX });
    engine.stopAll();
    setActivePreset(null);
  }, []);

  // visualizer loop
  useEffect(() => {
    let raf = 0;
    const draw = () => {
      const cv = canvasRef.current;
      if (cv) {
        const ctx = cv.getContext("2d");
        if (ctx) {
          const W = cv.width, H = cv.height;
          ctx.clearRect(0, 0, W, H);
          const spec = engine.spectrum(40);
          const bw = W / 40;
          spec.forEach((v, i) => {
            const h = Math.max(2, v * H);
            const g = ctx.createLinearGradient(0, H - h, 0, H);
            g.addColorStop(0, accent);
            g.addColorStop(1, accent + "33");
            ctx.fillStyle = g;
            const x = i * bw + 1;
            ctx.beginPath();
            ctx.roundRect(x, H - h, bw - 2, h, 3);
            ctx.fill();
          });
          // idle wave when nothing playing
          if (activeCount === 0) {
            ctx.fillStyle = "rgba(255,255,255,.12)";
            const t = Date.now() / 900;
            for (let i = 0; i < 40; i++) {
              const h = 3 + Math.sin(t + i * 0.4) * 2;
              ctx.beginPath();
              ctx.roundRect(i * bw + 1, H / 2 - h / 2, bw - 2, h, 2);
              ctx.fill();
            }
          }
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [accent, activeCount]);

  const sliderStyle = (v: number, color: string) =>
    ({ "--p": `${v * 100}%`, "--fill": color } as React.CSSProperties);

  return (
    <div className="glass rounded-3xl p-4 md:p-5">
      {/* header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div
            className="grid h-10 w-10 place-items-center rounded-2xl"
            style={{ background: `${accent}22`, border: `1px solid ${accent}44` }}
          >
            <AudioWaveform size={20} style={{ color: accent }} />
          </div>
          <div>
            <h3 className="font-display text-[15px] font-bold text-white">Дууны систем</h3>
            <p className="text-[11px] text-white/55">
              {activeCount === 0 ? "13 суваг бэлэн — пресет сонго" : `${activeCount} суваг тоглож байна`}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setMuted(!muted)}
            className="grid h-9 w-9 place-items-center rounded-xl bg-white/8 text-white/75 transition hover:bg-white/15"
            title={muted ? "Дуу нээх" : "Хаах"}
          >
            {muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
          </button>
          <button
            onClick={stopAll}
            className="grid h-9 w-9 place-items-center rounded-xl bg-white/8 text-white/75 transition hover:bg-red-500/30 hover:text-red-200"
            title="Бүгдийг зогсоох"
          >
            <Square size={15} />
          </button>
        </div>
      </div>

      {/* visualizer */}
      <div className="mt-3 overflow-hidden rounded-2xl bg-black/40 p-2 ring-1 ring-white/10">
        <canvas ref={canvasRef} width={560} height={64} className="h-16 w-full" />
      </div>

      {/* master */}
      <div className="mt-3 flex items-center gap-3 rounded-2xl bg-white/5 px-3 py-2.5 ring-1 ring-white/10">
        <Volume2 size={16} className="shrink-0 text-white/60" />
        <input
          type="range" min={0} max={1} step={0.01} value={muted ? 0 : master}
          onChange={(e) => { setMuted(false); setMaster(Number(e.target.value)); }}
          className="w-full" style={sliderStyle(muted ? 0 : master, accent)}
        />
        <span className="w-10 shrink-0 text-right text-xs font-bold text-white/70">
          {Math.round((muted ? 0 : master) * 100)}%
        </span>
      </div>

      {/* presets */}
      <div className="mt-3">
        <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-white/50">
          <Sparkles size={12} /> Бэлэн орчин
        </div>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => applyPreset(p.id)}
              title={p.desc}
              className={`group rounded-2xl px-2.5 py-2 text-left ring-1 transition-all hover:scale-[1.02] ${
                activePreset === p.id
                  ? "bg-white/15 ring-white/30"
                  : "bg-white/5 ring-white/10 hover:bg-white/10"
              }`}
            >
              <div className="flex items-center gap-1.5">
                <span className="text-base">{p.emoji}</span>
                <span className="truncate text-[12px] font-bold text-white">{p.nameMn}</span>
                {activePreset === p.id && <Play size={11} style={{ color: accent }} className="ml-auto shrink-0" />}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* channels */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-white/5 py-2 text-[12px] font-bold text-white/70 ring-1 ring-white/10 transition hover:bg-white/10"
      >
        <SlidersHorizontal size={14} />
        {expanded ? "Микшер хураах" : `Микшер нээх — 13 суваг`}
        <ChevronDown size={14} className={`transition-transform ${expanded ? "rotate-180" : ""}`} />
      </button>

      {expanded && (
        <div className="anim-pop mt-2 space-y-1.5">
          {CHANNELS.map((ch) => {
            const Icon = ICONS[ch.icon] ?? AudioLines;
            const v = mix[ch.id];
            const on = v > 0.01;
            return (
              <div
                key={ch.id}
                className={`flex items-center gap-2.5 rounded-2xl px-2.5 py-2 ring-1 transition ${
                  on ? "bg-white/8 ring-white/15" : "bg-white/[.03] ring-white/5"
                }`}
              >
                <div
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-xl"
                  style={{
                    background: on ? `${ch.color}26` : "rgba(255,255,255,.05)",
                    border: `1px solid ${on ? ch.color + "55" : "rgba(255,255,255,.08)"}`,
                  }}
                >
                  <Icon size={15} style={{ color: on ? ch.color : "rgba(255,255,255,.4)" }} />
                </div>
                <div className="w-[86px] shrink-0">
                  <div className="truncate text-[12px] font-bold text-white">{ch.nameMn}</div>
                  <div className="truncate text-[10px] text-white/45">{ch.desc}</div>
                </div>
                <input
                  type="range" min={0} max={1} step={0.01} value={v}
                  onChange={(e) => setChannel(ch.id, Number(e.target.value))}
                  className="w-full" style={sliderStyle(v, ch.color)}
                />
                <span className="w-8 shrink-0 text-right text-[11px] font-bold text-white/60">
                  {Math.round(v * 100)}
                </span>
              </div>
            );
          })}
          <div className="flex items-start gap-2 rounded-2xl bg-violet-400/10 p-3 text-[11px] leading-relaxed text-violet-200/90 ring-1 ring-violet-400/25">
            <Headphones size={15} className="mt-0.5 shrink-0" />
            <span>
              <b>Хоёр чихний долгион (Binaural α 10Hz)</b> нь чихэвчтэй үед хамгийн үр дүнтэй.
              Альфа долгион нь тайван төвлөрлийг дэмждэг нь судалгаагаар батлагдсан.
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
