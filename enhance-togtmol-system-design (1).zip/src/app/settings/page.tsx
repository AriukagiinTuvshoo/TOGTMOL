import { getSettings } from "@/lib/data";
import { PageHeader } from "@/components/shell";
import { SettingsForm } from "@/components/settings/settings-form";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const settings = await getSettings();

  return (
    <div>
      <PageHeader
        eyebrow="Системийн тохиргоо"
        title="Хувийн протокол"
        description="Циклийн урт, гүн ажлын цонх, амбиент дуу, мэдэгдлийг өөрийн хэмнэлд тааруул. Бүх өөрчлөлт серверт хадгалагдана."
        actions={<span className="chip chip-accent">PostgreSQL · Drizzle</span>}
      />
      <SettingsForm settings={settings} />
    </div>
  );
}
