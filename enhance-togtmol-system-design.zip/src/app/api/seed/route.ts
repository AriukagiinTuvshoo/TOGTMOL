import { NextResponse } from "next/server";
import { db } from "@/db";
import { subjects, notes, decks, cards, quizzes, goals, goalSteps, tasks, studySessions } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function POST() {
  try {
    const existing = await db.execute(sql`select count(*)::int as c from subjects`);
    const count = Number((existing.rows[0] as any)?.c ?? 0);
    if (count > 0) return NextResponse.json({ ok: true, seeded: false });

    const [math, eng, bio] = await db.insert(subjects).values([
      { name: "Математик", color: "#8b5cf6", icon: "sigma" },
      { name: "Англи хэл", color: "#38bdf8", icon: "languages" },
      { name: "Биологи", color: "#4ade80", icon: "dna" },
    ]).returning();

    await db.insert(notes).values([
      {
        subjectId: math.id, title: "Квадрат тэгшитгэл — Виетийн теорем",
        content: "ax² + bx + c = 0 бол x₁+x₂ = -b/a, x₁·x₂ = c/a.\n\nЖишээ: x² - 5x + 6 = 0 → нийлбэр 5, үржвэр 6 → (2, 3).",
        tags: ["томъёо", "алгебр"], favorite: true,
      },
      {
        subjectId: eng.id, title: "100 үг — 7 хоногийн төлөвлөгөө",
        content: "Өдөрт 15 үг: өглөө 5, өдөр 5, орой давтлага 15.\nКарт ашиглаж, өгүүлбэр зохиож цээжил.",
        tags: ["vocabulary", "төлөвлөгөө"],
      },
      {
        subjectId: bio.id, title: "Митозын үе шатууд",
        content: "Профаз → Метафаз → Анафаз → Телофаз.\n'ПМАТ' гэж цээжил. Интерфаз бол бэлтгэл үе.",
        tags: ["цитологи"],
      },
    ]);

    const [deck] = await db.insert(decks).values([
      { subjectId: eng.id, name: "Англи үг — A2", description: "Өдөр тутмын 20 үг" },
    ]).returning();

    const words: [string, string][] = [
      ["resilient", "уян хатан, тэсвэртэй — She is resilient after failure."],
      ["meticulous", "нягт нямбай — meticulous notes"],
      ["inevitable", "зайлашгүй — Change is inevitable."],
      ["profound", "гүн гүнзгий — profound impact"],
      ["diligent", "хичээнгүй — diligent student"],
      ["ambiguous", "эргэлзээтэй — ambiguous answer"],
      ["pragmatic", "практик — pragmatic plan"],
      ["vivid", "тод, амьд — vivid memory"],
    ];
    await db.insert(cards).values(words.map(([front, back]) => ({
      deckId: deck.id, front, back,
    })));

    const [deck2] = await db.insert(decks).values([
      { subjectId: math.id, name: "Томъёо — Алгебр", description: "Шалгалтын өмнөх давтлага" },
    ]).returning();
    await db.insert(cards).values([
      { deckId: deck2.id, front: "(a+b)² = ?", back: "a² + 2ab + b²" },
      { deckId: deck2.id, front: "a² - b² = ?", back: "(a-b)(a+b)" },
      { deckId: deck2.id, front: "Квадрат тэгшитгэлийн ялгавар D = ?", back: "D = b² - 4ac" },
      { deckId: deck2.id, front: "x₁ + x₂ = ? (Виет)", back: "-b/a" },
    ]);

    await db.insert(quizzes).values([
      {
        subjectId: eng.id, title: "Үгийн сан — шалгалт 1",
        questions: [
          { q: "'Resilient' гэдэг үгийн утга?", type: "choice", options: ["Уян хатан", "Залхуу", "Шуурхай", "Чимээгүй"], answer: 0 },
          { q: "'Inevitable' = зайлашгүй. Үнэн үү?", type: "bool", answer: true },
          { q: "'Diligent student' — diligent-ийн утгыг бич", type: "short", answer: "хичээнгүй" },
          { q: "'Ambiguous' гэдэг нь?", type: "choice", options: ["Тодорхой", "Эргэлзээтэй", "Хурдан", "Удаан"], answer: 1 },
        ],
      },
      {
        subjectId: math.id, title: "Алгебр — мини сорил",
        questions: [
          { q: "(a+b)² = ?", type: "choice", options: ["a²+b²", "a²+2ab+b²", "a²-2ab+b²", "2a+2b"], answer: 1 },
          { q: "x²-5x+6=0-ийн шийдүүд?", type: "choice", options: ["1, 6", "2, 3", "-2, -3", "0, 5"], answer: 1 },
          { q: "D = b²-4ac. Үнэн үү?", type: "bool", answer: true },
        ],
      },
    ]);

    const [goal] = await db.insert(goals).values([
      {
        subjectId: eng.id, title: "IELTS 6.5 авах", description: "3 сарын төлөвлөгөө — өдөрт 1 цаг",
        targetDate: new Date(Date.now() + 90 * 864e5).toISOString().slice(0, 10), progress: 20, xp: 120,
      },
    ]).returning();
    await db.insert(goalSteps).values([
      { goalId: goal.id, title: "500 үг цээжлэх", done: true, position: 0 },
      { goalId: goal.id, title: "10 эссэ бичих", done: false, position: 1 },
      { goalId: goal.id, title: "20 listening тест", done: false, position: 2 },
      { goalId: goal.id, title: "Speaking өдөр бүр 10 мин", done: false, position: 3 },
    ]);

    await db.insert(tasks).values([
      { subjectId: math.id, title: "Квадрат тэгшитгэл — 20 бодлого", estMinutes: 50, priority: "high" },
      { subjectId: eng.id, title: "15 шинэ үг + давтлага", estMinutes: 25, priority: "medium" },
      { subjectId: bio.id, title: "Митозын зургаар тайлбарла", estMinutes: 30, priority: "low" },
    ]);

    // past week sessions for stats
    const now = Date.now();
    for (let d = 6; d >= 1; d--) {
      const n = 1 + (d % 3);
      for (let i = 0; i < n; i++) {
        const actual = [1500, 3000, 1800, 2700][(d + i) % 4];
        const start = new Date(now - d * 864e5 - i * 36e5);
        await db.insert(studySessions).values({
          subjectId: [math.id, eng.id, bio.id][(d + i) % 3],
          roomId: ["night", "rainy", "forest", "library"][d % 4],
          mode: "pomodoro",
          plannedSeconds: 1500,
          actualSeconds: actual,
          completed: actual >= 1500,
          interruptions: d % 3,
          focusScore: 62 + ((d * 7 + i * 5) % 30),
          startedAt: start,
          endedAt: new Date(start.getTime() + actual * 1000),
        });
      }
    }

    return NextResponse.json({ ok: true, seeded: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "seed failed" }, { status: 500 });
  }
}
