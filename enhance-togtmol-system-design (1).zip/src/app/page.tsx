import Link from "next/link";
import { getDashboardData } from "@/lib/data";
import { PageHeader, TodayBadge } from "@/components/shell";
import { MiniTimeline, Donut, Heatmap, SubjectProgress } from "@/components/charts";
import { EmptyState, Progress, RadialProgress, SectionHeading, Stat, SubjectDot } from "@/components/ui";
import { taskBlocks } from "@/lib/plan";
import {
  focusLabel,
  formatDateNumeric,
  minutesLabel,
  percent,
  relativeDayLabel,
  todayISO,
} from "@/lib/date";
import { PRESET_BY_ID } from "@/lib/sound";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const data = await getDashboardData();
  const focusPercent = percent(data.todayMinutes, data.settings.dailyGoalMinutes || 1);
  const blocks = taskBlocks(data.todayTasks);
  const activeGoals = data.goals.filter((goal) => goal.status === "active");
  const presetName = PRESET_BY_ID.get(data.settings.lastPreset)?.name ?? "Чимээгүй";
  const todayTasksDone = data.completedToday;

  return (
    <div className="space-y-4 sm:space-y-5">
      <PageHeader
        eyebrow="ТОГТМОЛ · Өнөөдрийн систем"
        title={`${data.greeting}, ${data.settings.displayName}`}
        description="Анхаарал, цаг, төлөвлөлт нэг дор. Өнөөдрийн хамгийн чухал ажлаа сонгоод, нэг блокоор эхэл."
        actions={
          <>
            <TodayBadge />
            <Link href="/plan" className="btn btn-ghost">
              Төлөвлөгөө
            </Link>
            <Link href="/focus" className="btn btn-primary">
              Анхаарал эхлүүлэх
            </Link>
          </>
        }
      />

      <section className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
        <div className="panel-glow p-5 sm:p-6">
          <div className="pointer-events-none absolute inset-0 hero-grid opacity-40" aria-hidden />
          <div className="relative">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="label text-[rgba(201,247,90,0.85)]">Анхаарлын пульс</p>
                <h2 className="mt-1.5 text-[19px] font-extrabold tracking-tight text-white">
                  Өнөөдрийн гүн ажил
                </h2>
              </div>
              <span className="chip chip-accent">
                🔥 <span className="mono">{data.activeStreak}</span> өдрийн цуваа
              </span>
            </div>

            <div className="mt-5 flex flex-col gap-6 sm:flex-row sm:items-center">
              <RadialProgress value={focusPercent} size={158} stroke={11}>
                <div>
                  <p className="mono text-[30px] font-extrabold leading-none text-white">
                    {data.todayMinutes}
                  </p>
                  <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--dim)]">
                    минут / {data.settings.dailyGoalMinutes}
                  </p>
                </div>
              </RadialProgress>

              <div className="min-w-0 flex-1">
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="rounded-xl border border-[var(--line)] bg-black/20 px-3 py-2.5">
                    <p className="label">Сесс</p>
                    <p className="mono mt-1 text-[19px] font-bold text-white">
                      {data.todaySessions.filter((session) => session.mode === "focus").length}
                    </p>
                  </div>
                  <div className="rounded-xl border border-[var(--line)] bg-black/20 px-3 py-2.5">
                    <p className="label">Чанар</p>
                    <p className="mono mt-1 text-[19px] font-bold text-[var(--violet)]">
                      {data.averageRating ? data.averageRating.toFixed(1) : "—"}
                    </p>
                  </div>
                  <div className="rounded-xl border border-[var(--line)] bg-black/20 px-3 py-2.5">
                    <p className="label">Ажил</p>
                    <p className="mono mt-1 text-[19px] font-bold text-[var(--mint)]">
                      {todayTasksDone}
                      <span className="text-[11px] text-[var(--dim)]"> / {blocks.length}</span>
                    </p>
                  </div>
                  <div className="rounded-xl border border-[var(--line)] bg-black/20 px-3 py-2.5">
                    <p className="label">Амбиент</p>
                    <p className="mt-1 truncate text-[11.5px] font-bold text-white">{presetName}</p>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  <Link href="/focus" className="btn btn-primary flex-1">
                    ▶ Фокус горим
                  </Link>
                  <Link href="/plan" className="btn btn-ghost flex-1">
                    Автоматаар төлөвлөх
                  </Link>
                </div>
              </div>
            </div>

            <div className="mt-5">
              <div className="flex items-center justify-between text-[10.5px] font-semibold text-[var(--muted)]">
                <span>Өдрийн зорилт</span>
                <span className="mono">{focusPercent}%</span>
              </div>
              <Progress className="mt-2" value={focusPercent} height={7} />
            </div>
          </div>
        </div>

        <div className="panel flex flex-col p-5">
          <SectionHeading
            label="Цагийн систем"
            title={data.nextBlock ? "Дараагийн блок" : "Чөлөөт цонх"}
            action={
              data.nextBlock ? (
                <span className="chip chip-live">
                  {data.minutesToNextBlock === 0 ? "Одоо" : `${data.minutesToNextBlock} мин`}
                </span>
              ) : null
            }
          />

          {data.nextBlock ? (
            <div className="mt-4 flex flex-1 flex-col">
              <p className="mono text-[27px] font-extrabold leading-none tracking-tight text-[var(--lime)]">
                {data.nextBlock.startLabel}
                <span className="text-white/25"> — </span>
                {data.nextBlock.endLabel}
              </p>
              <p className="mt-3 text-[15px] font-bold leading-snug text-white">{data.nextBlock.title}</p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {data.subjects
                  .filter((subject) => subject.id === data.nextBlock?.subjectId)
                  .map((subject) => (
                    <span key={subject.id} className="chip">
                      <SubjectDot color={subject.color} /> {subject.name}
                    </span>
                  ))}
                <span className="chip">
                  {minutesLabel(data.nextBlock.endMinute - data.nextBlock.startMinute)}
                </span>
                <span className="chip">{data.nextBlock.energy === "deep" ? "Гүн ажил" : "Хөнгөн ажил"}</span>
              </div>
              <p className="mt-3 text-[11.5px] leading-relaxed text-[var(--muted)]">
                {data.nextBlock.reason}. Утасны мэдэгдлийг хааж, нэг зорилтод төвлөр.
              </p>
              <div className="mt-auto flex gap-2 pt-4">
                <Link
                  href={data.nextBlock.taskId ? `/focus?task=${data.nextBlock.taskId}` : "/focus"}
                  className="btn btn-primary flex-1"
                >
                  Блок эхлүүлэх
                </Link>
                <Link href="/plan" className="btn btn-ghost">
                  Засах
                </Link>
              </div>
            </div>
          ) : (
            <div className="mt-4 flex-1">
              <EmptyState
                title="Дараагийн блок тодорхойгүй"
                text="Чөлөөт цагаа ухаалаг төлөвлөгчөөр дүүргэж, өнөөдрийн хамгийн үнэ цэнэтэй ажлаас эхэл."
                action={
                  <Link href="/plan" className="btn btn-primary">
                    Төлөвлөгөө нээх
                  </Link>
                }
              />
            </div>
          )}
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Өнөөдөр" value={data.todayMinutes} unit="минут" hint={`${focusLabel(data.focusSecondsToday)} бодит анхаарал`} tone="lime" />
        <Stat label="Энэ долоо хоног" value={Math.round(data.weekMinutes / 60 * 10) / 10} unit="цаг" hint={`${data.weekSessions} сесс`} />
        <Stat label="Цуваа" value={data.activeStreak} unit="өдөр" hint={`Дээд амжилт ${data.bestStreak} өдөр`} tone="violet" />
        <Stat label="Нээлттэй ажил" value={data.totalOpenTasks} unit="ажил" hint={`${data.goals.length} зорилгын хүрээнд`} tone="mint" />
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5 lg:col-span-2">
          <SectionHeading
            label="Өнөөдрийн урсгал"
            title="Блокчилсон цаг"
            hint={`${data.todayLabel} · ${blocks.length} блок`}
            action={
              <Link href="/plan" className="chip hover:border-white/30">
                Бүгдийг харах →
              </Link>
            }
          />
          <div className="mt-4">
            <MiniTimeline
              blocks={blocks}
              subjects={data.subjects}
              emptyHint="Өнөөдөр блок алга — төлөвлөгчөөр цагаа хуваарилаарай."
            />
          </div>

          <div className="mt-4 border-t border-[var(--line)] pt-3.5">
            <div className="flex items-center justify-between">
              <p className="label">Дараагийн ажлууд</p>
              <Link href="/plan" className="text-[10.5px] font-semibold text-[var(--muted)] hover:text-white">
                Бүгд
              </Link>
            </div>
            <div className="mt-2.5 grid gap-2 sm:grid-cols-2">
              {data.upcomingTasks.length > 0 ? (
                data.upcomingTasks.slice(0, 4).map((task) => {
                  const subject = data.subjects.find((item) => item.id === task.subjectId);
                  return (
                    <Link
                      key={task.id}
                      href={`/focus?task=${task.id}`}
                      className="flex items-center gap-2.5 rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2.5 transition hover:border-white/25 hover:bg-white/[0.055]"
                    >
                      <SubjectDot color={subject?.color ?? "#8b93a3"} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[11.5px] font-semibold text-[#dde3ec]">
                          {task.title}
                        </span>
                        <span className="block text-[10px] text-[var(--dim)]">
                          {task.estimateMinutes} мин ·{" "}
                          {task.dueDate ? relativeDayLabel(task.dueDate) : "хугацаагүй"}
                        </span>
                      </span>
                      <span className="text-[var(--dim)]">→</span>
                    </Link>
                  );
                })
              ) : (
                <p className="col-span-2 rounded-xl border border-dashed border-[var(--line-strong)] px-3 py-4 text-center text-[11px] text-[var(--dim)]">
                  Бүх ажил блоклогдсон байна. Сайн байна!
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="panel p-5">
          <SectionHeading
            label="Хуваарилалт"
            title="Долоо хоногийн сэдэв"
            hint="Энэ долоо хоногийн бодит минутаар"
          />
          <div className="mt-4">
            <Donut subjects={data.subjectStats} size={132} />
          </div>
          <div className="mt-4 space-y-2.5">
            {data.subjectStats.slice(0, 4).map((subject) => (
              <SubjectProgress key={subject.id} subject={subject} />
            ))}
          </div>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5 lg:col-span-2">
          <SectionHeading
            label="Урт хугацааны чиглэл"
            title="Зорилгын ахиц"
            hint="Амжилттай гүйцэтгэсэн үе шат ба зорилтот хугацаа"
            action={
              <Link href="/goals" className="chip hover:border-white/30">
                Зорилго →
              </Link>
            }
          />
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {activeGoals.slice(0, 4).map((goal) => {
              const total = goal.milestones.length || 1;
              const goalPercent = Math.round((goal.doneMilestones / total) * 100);
              const subject = data.subjects.find((item) => item.id === goal.subjectId);
              const daysLeft = goal.targetDate
                ? Math.max(
                    0,
                    Math.round(
                      (new Date(`${goal.targetDate}T00:00:00`).getTime() - new Date(`${todayISO()}T00:00:00`).getTime()) /
                        86_400_000,
                    ),
                  )
                : null;
              return (
                <div
                  key={goal.id}
                  className="rounded-2xl border border-[var(--line)] bg-white/[0.03] p-3.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-[12.5px] font-bold leading-snug text-white">{goal.title}</p>
                    {daysLeft !== null ? (
                      <span className="chip shrink-0">{daysLeft} хон</span>
                    ) : null}
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <SubjectDot color={subject?.color ?? "#94a3b8"} />
                    <span className="text-[10.5px] text-[var(--dim)]">
                      {goal.doneMilestones}/{goal.milestones.length} үе шат · {minutesLabel(goal.weeklyMinutes)}/долоо хоног
                    </span>
                  </div>
                  <Progress className="mt-2.5" value={goalPercent} height={5} />
                  {goal.targetDate ? (
                    <p className="mt-2 text-[10px] text-[var(--dim)]">
                      Зорилтот огноо {formatDateNumeric(goal.targetDate)}
                    </p>
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>

        <div className="panel p-5">
          <SectionHeading label="Тогтвортой байдал" title="Анхаарлын зураглал" />
          <div className="mt-4">
            <Heatmap days={data.heatmap} weeks={14} />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2.5">
              <p className="label">Идэвхтэй</p>
              <p className="mono mt-1 text-[18px] font-bold text-[var(--lime)]">{data.activeStreak} өдөр</p>
            </div>
            <div className="rounded-xl border border-[var(--line)] bg-white/[0.03] px-3 py-2.5">
              <p className="label">Дээд</p>
              <p className="mono mt-1 text-[18px] font-bold text-white">{data.bestStreak} өдөр</p>
            </div>
          </div>
        </div>
      </section>

      <section className="panel p-5">
        <SectionHeading
          label="Бүртгэл"
          title="Сүүлийн анхаарлын сессүүд"
          action={
            <Link href="/stats" className="chip hover:border-white/30">
              Статистик →
            </Link>
          }
        />
        <div className="mt-4 space-y-2">
          {data.recentSessions.length > 0 ? (
            data.recentSessions.map((session) => (
              <div
                key={session.id}
                className="flex items-center gap-3 rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2.5"
              >
                <span className="mono w-[78px] shrink-0 text-[10.5px] text-[var(--dim)]">
                  {relativeDayLabel(session.localDate, data.today)} · {session.timeLabel}
                </span>
                <SubjectDot color={session.subjectColor ?? "#94a3b8"} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[11.5px] font-semibold text-[#dde3ec]">
                    {session.taskTitle ?? session.subjectName ?? "Чөлөөт анхаарал"}
                  </span>
                  <span className="block text-[10px] text-[var(--dim)]">
                    {session.subjectName ?? "Сэдэвгүй"} ·{" "}
                    {PRESET_BY_ID.get(session.soundscape ?? "")?.name ?? "Чимээгүй"}
                  </span>
                </span>
                <span className="mono shrink-0 text-[11px] font-semibold text-white">
                  {minutesLabel(session.actualSeconds / 60)}
                </span>
                <span className="hidden shrink-0 text-[10px] text-[var(--amber)] sm:block">
                  {"★".repeat(session.rating ?? 0)}
                  <span className="text-white/15">{"★".repeat(5 - (session.rating ?? 0))}</span>
                </span>
              </div>
            ))
          ) : (
            <EmptyState
              title="Бүртгэл хоосон"
              text="Эхний анхаарлын сессээ бүртгэвэл энэ хэсэг амьд болно."
              action={
                <Link href="/focus" className="btn btn-primary">
                  Эхлэх
                </Link>
              }
            />
          )}
        </div>
      </section>
    </div>
  );
}
