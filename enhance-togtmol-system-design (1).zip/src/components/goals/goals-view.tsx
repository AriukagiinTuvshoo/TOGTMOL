"use client";

import { cx } from "@/lib/utils";
import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { addMilestone, createGoal, toggleMilestone, updateGoalStatus } from "@/app/actions";
import { Modal, Progress, SectionHeading, Stat, SubjectDot, Toast } from "@/components/ui";
import { formatDateNumeric, minutesLabel, percent, relativeDayLabel, todayISO, daysBetweenISO } from "@/lib/date";
import type { Goal, Subject } from "@/lib/types";

export function GoalsView({ goals, subjects }: { goals: Goal[]; subjects: Subject[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [milestoneDraft, setMilestoneDraft] = useState<Record<number, string>>({});
  const [form, setForm] = useState({
    title: "",
    description: "",
    subjectId: "",
    targetDate: "",
    weeklyMinutes: "240",
    priority: "2",
    firstMilestone: "",
  });

  const active = goals.filter((goal) => goal.status === "active");
  const archived = goals.filter((goal) => goal.status !== "active");
  const totalMilestones = goals.reduce((sum, goal) => sum + goal.milestones.length, 0);
  const doneMilestones = goals.reduce((sum, goal) => sum + goal.doneMilestones, 0);
  const weeklyPlan = active.reduce((sum, goal) => sum + goal.weeklyMinutes, 0);
  const focusHours = goals.reduce((sum, goal) => sum + goal.focusSeconds, 0) / 3600;

  const flash = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2400);
  };

  const submit = () => {
    if (!form.title.trim()) return;
    startTransition(async () => {
      await createGoal({
        title: form.title,
        description: form.description || null,
        subjectId: form.subjectId ? Number(form.subjectId) : null,
        targetDate: form.targetDate || null,
        weeklyMinutes: Number(form.weeklyMinutes) || 180,
        priority: Number(form.priority) || 2,
        firstMilestone: form.firstMilestone || null,
      });
      setOpen(false);
      setForm({
        title: "",
        description: "",
        subjectId: "",
        targetDate: "",
        weeklyMinutes: "240",
        priority: "2",
        firstMilestone: "",
      });
      flash("Зорилго үүслээ.");
      router.refresh();
    });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        <Stat label="Идэвхтэй зорилго" value={active.length} unit="зорилго" tone="lime" />
        <Stat
          label="Үе шат"
          value={`${doneMilestones}/${totalMilestones}`}
          hint={`${percent(doneMilestones, totalMilestones || 1)}% гүйцэтгэл`}
        />
        <Stat label="Долоо хоногийн төлөвлөгөө" value={Math.round(weeklyPlan / 60)} unit="цаг" tone="violet" />
        <Stat label="Хөрөнгө оруулсан" value={Math.round(focusHours * 10) / 10} unit="цаг" tone="mint" hint="Бүх зорилгын ажилд" />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <SectionHeading
          label="Урт хугацааны систем"
          title="Зорилго ба үе шат"
          hint="Зорилго → үе шат → ажил → блок. Бүх түвшин холбоотой."
        />
        <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
          + Зорилго нэмэх
        </button>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {active.map((goal) => {
          const subject = subjects.find((item) => item.id === goal.subjectId);
          const goalPercent = percent(goal.doneMilestones, goal.milestones.length || 1);
          const daysLeft = goal.targetDate ? daysBetweenISO(todayISO(), goal.targetDate) : null;
          return (
            <div key={goal.id} className="panel p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="chip">
                      <SubjectDot color={subject?.color ?? "#94a3b8"} size={7} />
                      {subject?.name ?? "Ерөнхий"}
                    </span>
                    {daysLeft !== null ? (
                      <span className={cx("chip", daysLeft <= 14 ? "chip-accent" : "")}>
                        {daysLeft < 0 ? "Хугацаа хэтэрсэн" : `${daysLeft} хоног үлдсэн`}
                      </span>
                    ) : null}
                    <span className="chip">P{goal.priority}</span>
                  </div>
                  <h3 className="mt-2.5 text-[15px] font-extrabold leading-snug text-white">{goal.title}</h3>
                  {goal.description ? (
                    <p className="mt-1 line-clamp-2 text-[11.5px] leading-relaxed text-[var(--muted)]">
                      {goal.description}
                    </p>
                  ) : null}
                </div>
                <div className="shrink-0 text-right">
                  <p className="mono text-[24px] font-extrabold leading-none text-[var(--lime)]">{goalPercent}%</p>
                  <p className="mt-1 text-[9.5px] text-[var(--dim)]">
                    {goal.doneMilestones}/{goal.milestones.length} үе шат
                  </p>
                </div>
              </div>

              <Progress className="mt-3" value={goalPercent} height={5} />

              <div className="mt-3 space-y-1.5">
                {goal.milestones.map((milestone) => (
                  <div key={milestone.id} className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        startTransition(async () => {
                          await toggleMilestone(milestone.id, !milestone.done);
                          router.refresh();
                        });
                      }}
                      className={cx(
                        "grid h-4 w-4 shrink-0 place-items-center rounded-[5px] border text-[9px] transition",
                        milestone.done
                          ? "border-[var(--lime)] bg-[rgba(201,247,90,0.18)] text-[var(--lime)]"
                          : "border-white/25 text-transparent hover:border-[var(--lime)] hover:text-[var(--lime)]",
                      )}
                      aria-label={`${milestone.title} төлөв солих`}
                    >
                      ✓
                    </button>
                    <span
                      className={cx(
                        "min-w-0 flex-1 truncate text-[11.5px]",
                        milestone.done ? "text-[var(--dim)] line-through" : "text-[#d6dde8]",
                      )}
                    >
                      {milestone.title}
                    </span>
                    {milestone.dueDate ? (
                      <span className="shrink-0 text-[9px] text-[var(--dim)]">
                        {relativeDayLabel(milestone.dueDate)}
                      </span>
                    ) : null}
                  </div>
                ))}
                <div className="flex gap-1.5 pt-1">
                  <input
                    className="input h-8 py-1 text-[11px]"
                    placeholder="Үе шат нэмэх…"
                    value={milestoneDraft[goal.id] ?? ""}
                    onChange={(event) =>
                      setMilestoneDraft({ ...milestoneDraft, [goal.id]: event.target.value })
                    }
                    onKeyDown={(event) => {
                      if (event.key !== "Enter") return;
                      const title = milestoneDraft[goal.id] ?? "";
                      if (!title.trim()) return;
                      startTransition(async () => {
                        await addMilestone(goal.id, title);
                        setMilestoneDraft({ ...milestoneDraft, [goal.id]: "" });
                        router.refresh();
                      });
                    }}
                  />
                  <button
                    type="button"
                    className="btn btn-ghost h-8 px-2.5 text-[11px]"
                    onClick={() => {
                      const title = milestoneDraft[goal.id] ?? "";
                      if (!title.trim()) return;
                      startTransition(async () => {
                        await addMilestone(goal.id, title);
                        setMilestoneDraft({ ...milestoneDraft, [goal.id]: "" });
                        router.refresh();
                      });
                    }}
                    disabled={pending}
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[var(--line)] pt-3">
                <span className="text-[10px] text-[var(--dim)]">
                  {goal.targetDate ? `Зорилтот огноо ${formatDateNumeric(goal.targetDate)} · ` : ""}
                  Долоо хоногт {minutesLabel(goal.weeklyMinutes)} · {minutesLabel(goal.focusSeconds / 60)} бүртгэлтэй
                </span>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    className="btn btn-ghost h-8 px-2.5 text-[10.5px]"
                    onClick={() => {
                      startTransition(async () => {
                        await updateGoalStatus(goal.id, "done");
                        flash("Зорилго дууссан гэж тэмдэглэгдлээ.");
                        router.refresh();
                      });
                    }}
                  >
                    Дуусгах
                  </button>
                  <Link href="/plan" className="btn btn-ghost h-8 px-2.5 text-[10.5px]">
                    Төлөвлөх →
                  </Link>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {archived.length > 0 ? (
        <div className="panel p-5">
          <SectionHeading label="Архив" title="Дууссан ба зогсоосон зорилго" />
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {archived.map((goal) => (
              <div key={goal.id} className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-white/[0.025] px-3 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-[11.5px] font-semibold text-[#d6dde8]">{goal.title}</p>
                  <p className="text-[9.5px] text-[var(--dim)]">
                    {goal.doneMilestones}/{goal.milestones.length} үе шат · {goal.status}
                  </p>
                </div>
                <button
                  type="button"
                  className="btn btn-ghost h-8 shrink-0 px-2.5 text-[10.5px]"
                  onClick={() => {
                    startTransition(async () => {
                      await updateGoalStatus(goal.id, "active");
                      router.refresh();
                    });
                  }}
                >
                  Сэргээх
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Шинэ зорилго"
        subtitle="Тодорхой, хэмжигдэхүйц зорилго үүсгэ. Эхний үе шатаа шууд нэм."
        footer={
          <>
            <button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>
              Болих
            </button>
            <button type="button" className="btn btn-primary" onClick={submit} disabled={pending || !form.title.trim()}>
              {pending ? "Хадгалж байна…" : "Зорилго үүсгэх"}
            </button>
          </>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="label" htmlFor="goal-title">Зорилгын нэр</label>
            <input
              id="goal-title"
              className="input mt-1.5"
              placeholder="Жишээ: IELTS 7.5 авах"
              value={form.title}
              onChange={(event) => setForm({ ...form, title: event.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="goal-desc">Тайлбар</label>
            <textarea
              id="goal-desc"
              rows={2}
              className="textarea mt-1.5"
              placeholder="Хэмжигдэхүйц шалгуур, арга барил…"
              value={form.description}
              onChange={(event) => setForm({ ...form, description: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="goal-subject">Сэдэв</label>
            <select
              id="goal-subject"
              className="select mt-1.5"
              value={form.subjectId}
              onChange={(event) => setForm({ ...form, subjectId: event.target.value })}
            >
              <option value="">Ерөнхий</option>
              {subjects.map((subject) => (
                <option key={subject.id} value={subject.id}>{subject.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="goal-priority">Ач холбогдол</label>
            <select
              id="goal-priority"
              className="select mt-1.5"
              value={form.priority}
              onChange={(event) => setForm({ ...form, priority: event.target.value })}
            >
              <option value="3">Өндөр</option>
              <option value="2">Дунд</option>
              <option value="1">Бага</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="goal-date">Зорилтот огноо</label>
            <input
              id="goal-date"
              type="date"
              className="input mt-1.5"
              value={form.targetDate}
              onChange={(event) => setForm({ ...form, targetDate: event.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="goal-weekly">Долоо хоногийн минут</label>
            <input
              id="goal-weekly"
              type="number"
              min={30}
              step={30}
              className="input mt-1.5"
              value={form.weeklyMinutes}
              onChange={(event) => setForm({ ...form, weeklyMinutes: event.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="goal-milestone">Эхний үе шат</label>
            <input
              id="goal-milestone"
              className="input mt-1.5"
              placeholder="Жишээ: 20 эссэ бичих"
              value={form.firstMilestone}
              onChange={(event) => setForm({ ...form, firstMilestone: event.target.value })}
            />
          </div>
        </div>
      </Modal>

      {toast ? <Toast message={toast} /> : null}
    </div>
  );
}
