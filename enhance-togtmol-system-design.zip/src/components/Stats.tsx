"use client";

import { useMemo } from "react";
import { Flame, Clock, Target, TrendingUp, Award, BarChart3 } from "lucide-react";
import { fmtMnDuration, streakDays, levelForXp } from "@/lib/focus";
import type { StudySession, Subject } from "@/db/schema";

export default function Stats({
  sessions, subjects, accent,
}: { sessions: StudySession[]; subjects: Subject[]; accent: string }) {
  const data = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const todayS = sessions.filter((s) => new Date(s.startedAt).toISOString().slice(0, 10) === today);
    const todaySec = todayS.reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
    const weekAgo = Date.now() - 7 * 864e5;
    const weekS = sessions.filter((s) => new Date(s.startedAt).getTime() > weekAgo);
    const weekSec = weekS.reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
    const totalSec = sessions.reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
    const avgFocus = sessions.length
      ? Math.round(sessions.reduce((a, s) => a + (s.focusScore ?? 0), 0) / sessions.length)
      : 0;
    const dates = [...new Set(sessions.map((s) => new Date(s.startedAt).toISOString().slice(0, 10)))];
    const streak = streakDays(dates);
    const totalXp = sessions.reduce((a, s) => {
      const base = Math.floor((s.actualSeconds ?? 0) / 60) * 2;
      return a + base + (s.completed ? 15 : 0) + Math.floor((s.focusScore ?? 0) / 10);
    }, 0);
    const level = levelForXp(totalXp);
    // heatmap: last 8 weeks
    const days: { date: string; sec: number }[] = [];
    for (let i = 55; i >= 0; i--) {
      const d = new Date(Date.now() - i * 864e5);
      const key = d.toISOString().slice(0, 10);
      const sec = sessions
        .filter((s) => new Date(s.startedAt).toISOString().slice(0, 10) === key)
        .reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
      days.push({ date: key, sec });
    }
    const bySubject = subjects.map((sub) => {
      const sec = sessions
        .filter((s) => s.subjectId === sub.id)
        .reduce((a, s) => a + (s.actualSeconds ?? 0), 0);
      return { ...sub, sec };
    }).sort((a, b) => b.sec - a.sec);
    const maxSub = Math.max(1, ...bySubject.map((s) => s.sec));
    return { todaySec, weekSec, totalSec, avgFocus, streak, totalXp, level, days, bySubject, maxSub, todayCount: todayS.length };
  }, [sessions, subjects]);

  const heat = (sec: number) =>
    sec === 0 ? "heat-0" : sec < 1500 ? "heat-1" : sec < 3600 ? "heat-2" : sec < 7200 ? "heat-3" : "heat-4";

  const accentColor = accent;
  const cards = [
    { icon: Flame, label: "Цуврал", value: `${data.streak} өдөр`, color: "#fb923c" },
    { icon: Clock, label: "Өнөөдөр", value: fmtMnDuration(data.todaySec), color: "#38bdf8" },
    { icon: BarChart3, label: "7 хоног", value: fmtMnDuration(data.weekSec), color: "#4ade80" },
    { icon: Target, label: "Фокус дундаж", value: `${data.avgFocus}/100`, color: accentColor },
  ];

  return (
    <div className="space-y-3">
      {/* level banner */}
      <div className="glass overflow-hidden rounded-3xl p-4">
        <div className="flex items-center gap-3">
          <div
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl font-display text-xl font-bold text-white"
            style={{ background: `linear-gradient(135deg, ${accentColor}, ${accentColor}66)`, boxShadow: `0 6px 24px ${accentColor}55` }}
          >
            {data.level.level}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <Award size={15} style={{ color: accentColor }} />
              <span className="font-display text-[14px] font-bold text-white">
                Түвшин {data.level.level} · {data.level.title}
              </span>
            </div>
            <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${(data.level.into / data.level.needed) * 100}%`, background: `linear-gradient(90deg, ${accentColor}, #fff)` }}
              />
            </div>
            <div className="mt-1 text-[11px] text-white/55">
              {data.totalXp} XP нийт · дараагийн түвшин хүртэл {data.level.needed - data.level.into} XP
            </div>
          </div>
        </div>
      </div>

      {/* stat cards */}
      <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="glass rounded-3xl p-3.5">
            <c.icon size={18} style={{ color: c.color }} />
            <div className="mt-2 font-display text-[19px] font-bold text-white">{c.value}</div>
            <div className="text-[11px] text-white/55">{c.label}</div>
          </div>
        ))}
      </div>

      {/* heatmap */}
      <div className="glass rounded-3xl p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp size={16} style={{ color: accentColor }} />
            <span className="text-[13px] font-bold text-white">Идэвхийн зураглал — 8 долоо хоног</span>
          </div>
          <span className="text-[11px] text-white/50">Нийт {fmtMnDuration(data.totalSec)} · {sessions.length} сесс</span>
        </div>
        <div className="grid grid-cols-[repeat(8,minmax(0,1fr))] gap-1.5 sm:grid-cols-[repeat(14,minmax(0,1fr))]">
          {data.days.map((d) => (
            <div
              key={d.date}
              title={`${d.date}: ${fmtMnDuration(d.sec)}`}
              className={`aspect-square rounded-[6px] ${heat(d.sec)} transition hover:scale-110`}
            />
          ))}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-[10px] text-white/40">
          <span>Бага</span>
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className={`h-2.5 w-2.5 rounded-[4px] heat-${i}`} />
          ))}
          <span>Их</span>
          <span className="ml-auto">Өнөөдөр: {data.todayCount} сесс</span>
        </div>
      </div>

      {/* subjects */}
      {data.bySubject.length > 0 && (
        <div className="glass rounded-3xl p-4">
          <div className="mb-3 text-[13px] font-bold text-white">Хичээлээр — зарцуулсан цаг</div>
          <div className="space-y-2.5">
            {data.bySubject.map((s) => (
              <div key={s.id}>
                <div className="mb-1 flex items-center justify-between text-[12px]">
                  <span className="flex items-center gap-1.5 font-bold text-white/85">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                    {s.name}
                  </span>
                  <span className="font-bold text-white/60">{fmtMnDuration(s.sec)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-white/8">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${(s.sec / data.maxSub) * 100}%`, background: s.color, boxShadow: `0 0 10px ${s.color}` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
