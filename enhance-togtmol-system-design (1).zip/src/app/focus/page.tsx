import Link from "next/link";
import { getFocusData } from "@/lib/data";
import { FocusRoom } from "@/components/focus/focus-room";
import { PageHeader } from "@/components/shell";

export const dynamic = "force-dynamic";

export default async function FocusPage({
  searchParams,
}: {
  searchParams: Promise<{ task?: string }>;
}) {
  const params = await searchParams;
  const data = await getFocusData();
  const parsed = Number(params.task);
  const initialTaskId = Number.isFinite(parsed) && parsed > 0 ? parsed : null;

  return (
    <div>
      <PageHeader
        eyebrow="Анхаарлын өрөө"
        title="Гүн ажлын цаг"
        description="Дрифтгүй тоолуур, давхаргат амбиент дуу, сесс бүрийн бодит бүртгэл. Нэг блок — нэг зорилт."
        actions={
          <>
            <span className="chip chip-live">
              <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[var(--mint)]" />
              Web Audio · төхөөрөмж дээр
            </span>
            <Link href="/plan" className="btn btn-ghost">
              Блок сонгох
            </Link>
          </>
        }
      />
      <FocusRoom data={data} initialTaskId={initialTaskId} />
    </div>
  );
}
