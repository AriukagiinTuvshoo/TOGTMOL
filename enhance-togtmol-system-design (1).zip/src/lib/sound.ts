export type LayerId =
  | "rain"
  | "brown"
  | "ocean"
  | "fire"
  | "wind"
  | "cafe"
  | "night"
  | "pad"
  | "piano"
  | "bells"
  | "binaural";

export type LayerMeta = {
  id: LayerId;
  name: string;
  glyph: string;
  hint: string;
  group: "Байгаль" | "Орон зай" | "Хөгжим";
};

export const LAYERS: LayerMeta[] = [
  { id: "rain", name: "Бороо", glyph: "☂", hint: "Шигшүүртэй борооны шуугиан", group: "Байгаль" },
  { id: "ocean", name: "Далайн давлагаа", glyph: "≈", hint: "Удаан амьсгалтай давлагаа", group: "Байгаль" },
  { id: "fire", name: "Гал", glyph: "✦", hint: "Галын шажигнаан, гүн дулаан", group: "Байгаль" },
  { id: "wind", name: "Салхи", glyph: "≋", hint: "Ойн салхины урсгал", group: "Байгаль" },
  { id: "night", name: "Шөнийн шавьж", glyph: "◌", hint: "Шөнийн шавьжны чимээ", group: "Байгаль" },
  { id: "cafe", name: "Кафе", glyph: "☕", hint: "Алслагдсан ярианы чимээ", group: "Орон зай" },
  { id: "brown", name: "Бор шуугиан", glyph: "▮", hint: "Гүн анхаарлын суурь", group: "Орон зай" },
  { id: "binaural", name: "Бинаурал", glyph: "◐", hint: "Чихэвч шаардлагатай (10 Hz)", group: "Орон зай" },
  { id: "pad", name: "Аялгуун давхарга", glyph: "∿", hint: "Амьсгалсан аккорд", group: "Хөгжим" },
  { id: "piano", name: "Төгөлдөр хуур", glyph: "♪", hint: "Пентатоник арпеджио", group: "Хөгжим" },
  { id: "bells", name: "Хонх", glyph: "☉", hint: "Ховор тохиолдох бясалгалын хонх", group: "Хөгжим" },
];

export type Preset = {
  id: string;
  name: string;
  description: string;
  glyph: string;
  mix: Record<string, number>;
};

export const PRESETS: Preset[] = [
  {
    id: "forest-rain",
    name: "Ойн бороо",
    description: "Бороо, салхи, алслагдсан галын шажигнаан",
    glyph: "☂",
    mix: { rain: 0.55, wind: 0.22, fire: 0.18, pad: 0.16, bells: 0.1 },
  },
  {
    id: "deep-focus",
    name: "Гүн анхаарал",
    description: "Бор шуугиан, аккорд, ховор хонх",
    glyph: "◎",
    mix: { brown: 0.4, pad: 0.3, bells: 0.14 },
  },
  {
    id: "night-library",
    name: "Шөнийн номын сан",
    description: "Борооны шигшүүр, кафе, төгөлдөр хуур",
    glyph: "☾",
    mix: { rain: 0.24, cafe: 0.2, piano: 0.28, night: 0.16 },
  },
  {
    id: "ocean-calm",
    name: "Далайн тайван",
    description: "Удаан давлагаа, салхи, хонх",
    glyph: "≈",
    mix: { ocean: 0.5, wind: 0.2, pad: 0.16, bells: 0.1 },
  },
  {
    id: "rainy-cafe",
    name: "Бороотой кафе",
    description: "Бороо, кафе, төгөлдөр хуур",
    glyph: "☕",
    mix: { rain: 0.4, cafe: 0.24, piano: 0.22, fire: 0.12 },
  },
  {
    id: "space-drift",
    name: "Сансрын аялал",
    description: "Бинаурал, аккорд, алслагдсан хонх",
    glyph: "◐",
    mix: { pad: 0.34, binaural: 0.2, bells: 0.16, brown: 0.14 },
  },
  {
    id: "campfire",
    name: "Уулын гал",
    description: "Галын шажигнаан, шөнийн шавьж, салхи",
    glyph: "✦",
    mix: { fire: 0.44, night: 0.2, wind: 0.18, pad: 0.1 },
  },
  {
    id: "silence",
    name: "Чимээгүй",
    description: "Зөвхөн өөрийн амьсгал",
    glyph: "○",
    mix: {},
  },
];

export const PRESET_BY_ID = new Map(PRESETS.map((preset) => [preset.id, preset]));

export const SOUNDSCAPE_LABEL: Record<string, string> = {
  "forest-rain": "Ойн бороо",
  "deep-focus": "Гүн анхаарал",
  "night-library": "Шөнийн номын сан",
  "ocean-calm": "Далайн тайван",
  "rainy-cafe": "Бороотой кафе",
  "space-drift": "Сансрын аялал",
  campfire: "Уулын гал",
  silence: "Чимээгүй",
  none: "Чимээгүй",
};

export function soundscapeName(id: string | null | undefined): string {
  if (!id) return "Чимээгүй";
  return SOUNDSCAPE_LABEL[id] ?? id;
}

export const DEFAULT_MIX = PRESET_BY_ID.get("forest-rain")?.mix ?? {};
