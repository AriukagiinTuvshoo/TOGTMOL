"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Play, Pause, Square, RotateCcw, Timer, Hourglass, Infinity as InfinityIcon,
  Waves, Bell, BellOff, Zap, Plus, Minus, BookOpen, CheckCircle2,
  Maximize2, X, SkipForward, Layers, ListTodo, CalendarClock, NotebookPen, Keyboard,
} from "lucide-react";
import { fmtClock, fmtMnDuration, focusScore } from "@/lib/focus";
import { engine } from "@/lib/audio-engine";
import { api } from "@/lib/api";
import type { Subject, Goal } from "@/db/schema";

export type TimerMode = "pomodoro" | "stopwatch" | "countdown" | "flowtime";

const POMODORO_PRESETS = [
  { label: "25/5", focus: 25, break: 5, desc: "Хөнгөн" },
  { label: "50/10", focus: 50, break: 10, desc: "Гүн" },
  { label: "90/20", focus: 90, break: 20, desc: "Урсгал" },
];

interface Props {
  subjects: Subject[];
  roomId: string;
  accent: string;
  goals?: Goal[];
  dueCards?: number;
  openTasks?: { id: string; title: string }[];
  onSessionComplete: (info: { seconds: number; score: number; xp: number; completed: boolean }) => void;
  onRunningChange?: (running: boolean) => void;
  onDisplayChange?: (clock: string, phase: string) => void;
}

// ── scalable ring clock (used both compact & full-screen) ─────────────
function RingClock({
  size, progress, display, phase, status, accent, sw = 12, glow = true,
}: {
  size: number; progress: number; display: string; phase: "focus" | "break";
  status: string; accent: string; sw?: number; glow?: boolean;
}) {
  const R = 92;
  const C = 2 * Math.PI * R;
  const color = phase === "break" ? "#4ade80" : accent;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      {/* breathing halo */}
      {glow && status === "running" && (
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `radial-gradient(circle, ${color}33, transparent 62%)`,
            animation: "breathe 4s ease-in-out infinite",
          }}
        />
      )}
      <svg viewBox="0 0 220 220" className="relative h-full w-full -rotate-90">
        <circle cx="110" cy="110" r={R} fill="none" stroke="rgba(255,255,255,.1)" strokeWidth={sw} />
        <circle
          cx="110" cy="110" r={R} fill="none"
          stroke={color}
          strokeWidth={sw} strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - progress)}
          style={{ transition: "stroke-dashoffset .3s linear, stroke .5s", filter: `drop-shadow(0 0 10px ${color})` }}
        />
        {Array.from({ length: 60 }).map((_, i) => {
          const a = (i / 60) * Math.PI * 2;
          const big = i % 5 === 0;
          const r1 = R - (big ? 22 : 18);
          const r2 = R - 26;
          return (
            <line
              key={i}
              x1={110 + Math.cos(a) * r1} y1={110 + Math.sin(a) * r1}
              x2={110 + Math.cos(a) * r2} y2={110 + Math.sin(a) * r2}
              stroke={big ? "rgba(255,255,255,.42)" : "rgba(255,255,255,.15)"}
              strokeWidth={big ? 2.2 : 1.1}
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div
          className="font-display font-bold tabular-nums leading-none text-white"
          style={{
            fontSize: Math.round(size * 0.185),
            letterSpacing: "-0.03em",
            textShadow: `0 0 ${size * 0.12}px ${color}66`,
            fontVariantNumeric: "tabular-nums",
          }}
        >
          {display}
        </div>
        <div
          className="mt-2 flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-bold"
          style={{
            background: phase === "break" ? "rgba(74,222,128,.15)" : `${accent}22`,
            color: phase === "break" ? "#86efac" : accent,
            border: `1px solid ${phase === "break" ? "rgba(74,222,128,.4)" : accent + "55"}`,
          }}
        >
          {status === "running" ? (
            <span className="relative flex h-2 w-2">
              <span className="absolute h-full w-full animate-ping rounded-full bg-current opacity-60" />
              <span className="h-2 w-2 rounded-full bg-current" />
            </span>
          ) : <Zap size={12} />}
          {phase === "break" ? "☕ АМРАЛТ" : status === "running" ? "ГЭН ФОКУС" : status === "paused" ? "ТҮР ЗОГСОН" : "БЭЛЭН"}
        </div>
      </div>
    </div>
  );
}

export default function TimerSystem({
  subjects, roomId, accent, goals = [], dueCards = 0, openTasks = [],
  onSessionComplete, onRunningChange, onDisplayChange,
}: Props) {
  const [mode, setMode] = useState<TimerMode>("pomodoro");
  const [preset, setPreset] = useState(1); // 50/10 default
  const [customMin, setCustomMin] = useState(50);
  const [subjectId, setSubjectId] = useState<string>("");
  const [phase, setPhase] = useState<"focus" | "break">("focus");
  const [status, setStatus] = useState<"idle" | "running" | "paused">("idle");
  const [elapsed, setElapsed] = useState(0);
  const [interruptions, setInterruptions] = useState(0);
  const [soundOn, setSoundOn] = useState(true);
  const [cycle, setCycle] = useState(1);
  const [note, setNote] = useState("");
  const [lastResult, setLastResult] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [bigSize, setBigSize] = useState(340);

  // responsive full-screen clock size
  useEffect(() => {
    if (!expanded) return;
    const fit = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const byW = w < 768 ? w * 0.78 : w * 0.34;
      const byH = h < 700 ? h * 0.42 : h * 0.46;
      setBigSize(Math.round(Math.max(240, Math.min(460, byW, byH))));
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, [expanded]);

  const endAtRef = useRef(0);
  const elapsedRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const wakeLockRef = useRef<any>(null);
  const sessionStartRef = useRef<Date>(new Date());
  const totalFocusRef = useRef(0);

  const focusLen = mode === "pomodoro" ? POMODORO_PRESETS[preset].focus * 60 : customMin * 60;
  const breakLen = mode === "pomodoro" ? POMODORO_PRESETS[preset].break * 60 : 5 * 60;
  const planned = phase === "focus" ? focusLen : mode === "pomodoro" ? breakLen : focusLen;
  const isCountUp = mode === "stopwatch" || mode === "flowtime";

  const display = isCountUp ? elapsed : Math.max(0, planned - elapsed);
  const progress = isCountUp
    ? Math.min(1, elapsed / (customMin * 60 || 3600))
    : planned > 0 ? Math.min(1, elapsed / planned) : 0;

  // notify shell header of the live clock
  useEffect(() => {
    onDisplayChange?.(fmtClock(display), phase);
  }, [display, phase, onDisplayChange]);

  const requestWake = useCallback(async () => {
    try {
      const nav = navigator as any;
      if (nav.wakeLock) wakeLockRef.current = await nav.wakeLock.request("screen");
    } catch { /* noop */ }
  }, []);
  const releaseWake = useCallback(() => {
    try { wakeLockRef.current?.release?.(); } catch { /* noop */ }
    wakeLockRef.current = null;
  }, []);

  const notify = useCallback((title: string, body: string) => {
    try {
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification(title, { body });
      }
    } catch { /* noop */ }
  }, []);

  useEffect(() => {
    try {
      if ("Notification" in window && Notification.permission === "default") {
        void Notification.requestPermission();
      }
    } catch { /* noop */ }
  }, []);

  const finish = useCallback(async (completed: boolean) => {
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
    setStatus("idle");
    onRunningChange?.(false);
    const actualPhase = Math.floor(elapsedRef.current);
    const totalActual = mode === "pomodoro"
      ? totalFocusRef.current + (phase === "focus" ? actualPhase : 0)
      : actualPhase;
    const realSeconds = Math.max(1, totalActual);
    const score = focusScore({
      plannedSeconds: mode === "pomodoro" ? POMODORO_PRESETS[preset].focus * 60 * cycle : planned,
      actualSeconds: realSeconds,
      completed,
      interruptions,
      mode,
      hourOfDay: new Date().getHours(),
    });
    const xp = Math.floor(realSeconds / 60) * 2 + (completed ? 15 : 0) + Math.floor(score / 10);
    try {
      await api.create("study_sessions", {
        subjectId: subjectId || null,
        roomId,
        mode,
        plannedSeconds: planned,
        actualSeconds: realSeconds,
        completed,
        interruptions,
        focusScore: score,
        startedAt: sessionStartRef.current.toISOString(),
        endedAt: new Date().toISOString(),
        note,
      });
    } catch { /* offline — still celebrate */ }
    if (completed && soundOn) engine.chime("complete");
    setLastResult(completed
      ? `+${xp} XP · Фокус ${score}/100 · ${Math.floor(realSeconds / 60)} мин`
      : `Хадгаллаа · ${Math.floor(realSeconds / 60)} мин · Фокус ${score}`);
    setElapsed(0);
    elapsedRef.current = 0;
    totalFocusRef.current = 0;
    setInterruptions(0);
    setPhase("focus");
    setCycle(1);
    setNote("");
    onSessionComplete({ seconds: realSeconds, score, xp, completed });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, phase, planned, preset, cycle, interruptions, subjectId, roomId, note, soundOn]);

  const tick = useCallback(() => {
    const now = Date.now();
    if (isCountUp) {
      elapsedRef.current += 0.25;
      setElapsed(Math.floor(elapsedRef.current));
    } else {
      const remain = Math.max(0, (endAtRef.current - now) / 1000);
      const el = planned - remain;
      elapsedRef.current = el;
      setElapsed(Math.floor(el));
      if (remain <= 0) {
        if (mode === "pomodoro" && phase === "focus") {
          totalFocusRef.current += planned;
          if (soundOn) engine.chime("complete");
          notify("Фокус дууслаа! 🎉", `${Math.round(planned / 60)} минут гүн ажил — одоо амраарай.`);
          setPhase("break");
          elapsedRef.current = 0;
          setElapsed(0);
          const bl = POMODORO_PRESETS[preset].break * 60;
          endAtRef.current = Date.now() + bl * 1000;
        } else if (mode === "pomodoro" && phase === "break") {
          if (soundOn) engine.chime("break");
          notify("Амралт дууслаа ⚡", "Дараагийн гүн фокус эхэллээ.");
          setPhase("focus");
          setCycle((c) => c + 1);
          elapsedRef.current = 0;
          setElapsed(0);
          const fl = POMODORO_PRESETS[preset].focus * 60;
          endAtRef.current = Date.now() + fl * 1000;
        } else {
          void finish(true);
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isCountUp, planned, mode, phase, preset, soundOn]);

  const start = useCallback(() => {
    sessionStartRef.current = status === "paused" ? sessionStartRef.current : new Date();
    if (status === "idle") {
      elapsedRef.current = 0;
      setElapsed(0);
      totalFocusRef.current = 0;
      setLastResult(null);
    }
    if (!isCountUp) {
      endAtRef.current = Date.now() + (planned - elapsedRef.current) * 1000;
    }
    setStatus("running");
    onRunningChange?.(true);
    void requestWake();
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(tick, 250);
  }, [status, isCountUp, planned, tick, requestWake, onRunningChange]);

  const pause = useCallback(() => {
    setStatus("paused");
    onRunningChange?.(false);
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
  }, [releaseWake, onRunningChange]);

  const reset = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
    setStatus("idle");
    onRunningChange?.(false);
    setElapsed(0);
    elapsedRef.current = 0;
    setPhase("focus");
    setCycle(1);
    setInterruptions(0);
  }, [releaseWake, onRunningChange]);

  // skip to next phase (StudySphere-inspired)
  const skipPhase = useCallback(() => {
    if (mode !== "pomodoro") return;
    if (phase === "focus") {
      totalFocusRef.current += Math.floor(elapsedRef.current);
      setPhase("break");
      elapsedRef.current = 0;
      setElapsed(0);
      endAtRef.current = Date.now() + POMODORO_PRESETS[preset].break * 60 * 1000;
    } else {
      setPhase("focus");
      setCycle((c) => c + 1);
      elapsedRef.current = 0;
      setElapsed(0);
      endAtRef.current = Date.now() + POMODORO_PRESETS[preset].focus * 60 * 1000;
    }
    if (soundOn) engine.chime("tick");
  }, [mode, phase, preset, soundOn]);

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
    releaseWake();
  }, [releaseWake]);

  // keyboard shortcuts: Space works everywhere (StudySet), Esc/S/R inside big timer
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (e.target as HTMLElement)?.isContentEditable;
      const modifier = e.metaKey || e.ctrlKey || e.altKey;
      if (typing || modifier) return;

      if (e.code === "Space") {
        e.preventDefault();
        if (status === "running") pause(); else start();
        return;
      }
      if (!expanded) return;
      if (e.key === "Escape") { setExpanded(false); return; }
      if (e.key.toLowerCase() === "s") skipPhase();
      if (e.key.toLowerCase() === "r") reset();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [expanded, status, pause, start, skipPhase, reset]);

  useEffect(() => {
    if (status === "running") {
      document.title = `${fmtClock(display)} · ${phase === "break" ? "Амралт" : "Фокус"} — ТОГТМОЛ`;
    } else {
      document.title = "ТОГТМОЛ v8 — Гүн төвлөрлийн өрөө";
    }
  }, [display, status, phase]);

  const MODES: { id: TimerMode; label: string; icon: any }[] = [
    { id: "pomodoro", label: "Помодоро", icon: Timer },
    { id: "stopwatch", label: "Секундомер", icon: Hourglass },
    { id: "countdown", label: "Тоолуур", icon: Hourglass },
    { id: "flowtime", label: "Урсгал", icon: InfinityIcon },
  ];

  // nearest exam countdown (StudySphere idea)
  const exam = goals
    .filter((g) => g.targetDate && (g.progress ?? 0) < 100)
    .map((g) => {
      const days = Math.ceil((new Date(g.targetDate!).getTime() - Date.now()) / 864e5);
      return { title: g.title, days };
    })
    .sort((a, b) => a.days - b.days)[0];

  const subject = subjects.find((s) => s.id === subjectId);

  return (
    <>
      <div className="glass rounded-3xl p-4 md:p-5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl" style={{ background: `${accent}22`, border: `1px solid ${accent}44` }}>
              <Timer size={20} style={{ color: accent }} />
            </div>
            <div className="min-w-0">
              <h3 className="font-display text-[15px] font-bold text-white">Цагийн систем</h3>
              <p className="truncate text-[11px] text-white/55">
                {mode === "pomodoro" ? `Цикл ${cycle} · ${phase === "focus" ? "Гүн фокус" : "Амралт"}` : mode === "flowtime" ? "Зогсолтгүй урсгал" : "Чөлөөт хэмжилт"}
              </p>
            </div>
          </div>
          <div className="flex shrink-0 gap-1.5">
            <button
              onClick={() => setSoundOn(!soundOn)}
              className="grid h-9 w-9 place-items-center rounded-xl bg-white/8 text-white/70 transition hover:bg-white/15"
              title="Дуусах дохио"
            >
              {soundOn ? <Bell size={16} /> : <BellOff size={16} />}
            </button>
            <button
              onClick={() => setExpanded(true)}
              className="grid h-9 w-9 place-items-center rounded-xl text-white transition hover:scale-105"
              style={{ background: `${accent}30`, border: `1px solid ${accent}55` }}
              title="Том цаг нээх"
            >
              <Maximize2 size={16} />
            </button>
          </div>
        </div>

        {/* mode tabs */}
        <div className="mt-3 grid grid-cols-4 gap-1.5">
          {MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => { if (status === "idle") setMode(m.id); }}
              disabled={status !== "idle"}
              className={`flex flex-col items-center gap-1 rounded-2xl px-1 py-2 text-[11px] font-bold ring-1 transition ${
                mode === m.id ? "text-white" : "bg-white/5 text-white/55 ring-white/10 hover:bg-white/10"
              } ${status !== "idle" ? "opacity-60" : ""}`}
              style={mode === m.id ? { background: `${accent}2e`, borderColor: `${accent}55`, boxShadow: `0 0 20px ${accent}33` } : undefined}
            >
              <m.icon size={16} />
              {m.label}
            </button>
          ))}
        </div>

        {/* clock — click to open the big timer */}
        <button
          onClick={() => setExpanded(true)}
          title="Том цаг нээх (мөн ⌘K-аас)"
          className="mx-auto mt-4 block cursor-zoom-in transition-transform hover:scale-[1.03] active:scale-[.98]"
        >
          <div className="relative mx-auto h-[220px] w-[220px]">
            <RingClock
              size={220} progress={progress} display={fmtClock(display)}
              phase={phase} status={status} accent={accent}
            />
          </div>
          <div className="mt-1.5 flex items-center justify-center gap-1 text-[10px] font-bold uppercase tracking-widest text-white/35">
            <Maximize2 size={10} /> Том нээх
          </div>
        </button>

        {/* pomodoro presets */}
        {mode === "pomodoro" && status === "idle" && (
          <div className="mt-3 grid grid-cols-3 gap-1.5">
            {POMODORO_PRESETS.map((p, i) => (
              <button
                key={p.label}
                onClick={() => setPreset(i)}
                className={`rounded-2xl px-2 py-2 ring-1 transition ${
                  preset === i ? "text-white" : "bg-white/5 text-white/60 ring-white/10 hover:bg-white/10"
                }`}
                style={preset === i ? { background: `${accent}2e`, borderColor: `${accent}66` } : undefined}
              >
                <div className="text-[15px] font-bold">{p.label}</div>
                <div className="text-[10px] opacity-70">{p.desc}</div>
              </button>
            ))}
          </div>
        )}

        {(mode === "countdown" || mode === "stopwatch" || mode === "flowtime") && status === "idle" && (
          <div className="mt-3 flex items-center justify-center gap-3 rounded-2xl bg-white/5 py-2 ring-1 ring-white/10">
            <button onClick={() => setCustomMin(Math.max(5, customMin - 5))} className="grid h-8 w-8 place-items-center rounded-xl bg-white/10 transition hover:bg-white/20"><Minus size={14} /></button>
            <div className="text-center">
              <div className="font-display text-xl font-bold text-white">{customMin} <span className="text-xs font-medium text-white/50">мин</span></div>
              <div className="text-[10px] text-white/45">{mode === "flowtime" ? "зорилтот урсгал" : "зорилтот хугацаа"}</div>
            </div>
            <button onClick={() => setCustomMin(Math.min(240, customMin + 5))} className="grid h-8 w-8 place-items-center rounded-xl bg-white/10 transition hover:bg-white/20"><Plus size={14} /></button>
          </div>
        )}

        {/* subject */}
        {status === "idle" && (
          <div className="mt-3 flex items-center gap-2">
            <BookOpen size={14} className="shrink-0 text-white/50" />
            <div className="flex flex-1 gap-1.5 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setSubjectId("")}
                className={`shrink-0 rounded-xl px-2.5 py-1.5 text-[11px] font-bold ring-1 transition ${!subjectId ? "bg-white/20 text-white ring-white/40" : "bg-white/5 text-white/55 ring-white/10"}`}
              >
                Чөлөөт
              </button>
              {subjects.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSubjectId(s.id)}
                  className={`flex shrink-0 items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-bold ring-1 transition ${
                    subjectId === s.id ? "bg-white/20 text-white ring-white/40" : "bg-white/5 text-white/60 ring-white/10 hover:bg-white/10"
                  }`}
                >
                  <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                  {s.name}
                </button>
              ))}
            </div>
          </div>
        )}

        {lastResult && status === "idle" && (
          <div className="anim-pop mt-3 flex items-center gap-2 rounded-2xl bg-emerald-400/12 px-3 py-2.5 text-[12px] font-bold text-emerald-200 ring-1 ring-emerald-400/30">
            <CheckCircle2 size={16} /> {lastResult}
          </div>
        )}

        {/* controls */}
        <div className="mt-4 flex items-center justify-center gap-2.5">
          {status === "idle" ? (
            <button
              onClick={start}
              className="anim-ring flex items-center gap-2 rounded-2xl px-8 py-3.5 font-display text-[15px] font-bold text-white transition hover:scale-105 active:scale-95"
              style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)`, boxShadow: `0 8px 32px ${accent}55` }}
            >
              <Play size={18} fill="currentColor" /> Эхлэх
            </button>
          ) : (
            <>
              {status === "running" ? (
                <button onClick={pause} className="flex items-center gap-2 rounded-2xl bg-amber-400/20 px-6 py-3 text-[14px] font-bold text-amber-200 ring-1 ring-amber-400/40 transition hover:scale-105">
                  <Pause size={17} /> Түр зогс
                </button>
              ) : (
                <button
                  onClick={start}
                  className="flex items-center gap-2 rounded-2xl px-6 py-3 text-[14px] font-bold text-white transition hover:scale-105"
                  style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}
                >
                  <Play size={17} /> Үргэлжлүүл
                </button>
              )}
              <button onClick={() => finish(false)} className="flex items-center gap-2 rounded-2xl bg-emerald-400/20 px-5 py-3 text-[14px] font-bold text-emerald-200 ring-1 ring-emerald-400/40 transition hover:scale-105" title="Дуусгаж хадгалах">
                <Square size={15} /> Дуусгах
              </button>
              <button onClick={reset} className="grid h-[46px] w-[46px] place-items-center rounded-2xl bg-white/8 text-white/60 ring-1 ring-white/10 transition hover:bg-white/15" title="Цуцлах">
                <RotateCcw size={17} />
              </button>
            </>
          )}
        </div>

        {/* interruptions */}
        {status !== "idle" && (
          <div className="mt-3 flex items-center justify-center gap-2">
            <button
              onClick={() => setInterruptions((i) => i + 1)}
              className="flex items-center gap-1.5 rounded-xl bg-white/5 px-3 py-1.5 text-[11px] font-bold text-white/60 ring-1 ring-white/10 transition hover:bg-white/10"
              title="Сатаарал тэмдэглэх"
            >
              <Waves size={13} /> Сатаарал: {interruptions}
            </button>
            <span className="hidden text-[11px] text-white/35 sm:inline">Сатаарсан бол товшоод буц</span>
          </div>
        )}
      </div>

      {/* ══════ FULL-SCREEN TIMER ══════ */}
      {expanded && (
        <div
          className="fixed inset-0 z-[75] flex flex-col overflow-y-auto"
          style={{
            background: "linear-gradient(165deg, rgba(4,4,12,.94), rgba(6,6,20,.97) 55%, rgba(10,8,28,.96))",
            backdropFilter: "blur(26px)",
            WebkitBackdropFilter: "blur(26px)",
          }}
        >
          {/* ambient orbs */}
          <div
            className="anim-drift1 pointer-events-none absolute -left-40 top-10 h-[460px] w-[460px] rounded-full blur-[130px]"
            style={{ background: `${accent}33` }}
          />
          <div
            className="anim-drift2 pointer-events-none absolute -right-40 bottom-0 h-[500px] w-[500px] rounded-full blur-[140px]"
            style={{ background: phase === "break" ? "#4ade8044" : `${accent}2b` }}
          />

          {/* top bar */}
          <div className="relative z-10 flex items-center justify-between px-4 pt-4 md:px-8 md:pt-6">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-2xl font-display text-[15px] font-bold text-white" style={{ background: `linear-gradient(135deg, ${accent}, ${accent}66)` }}>
                Т
              </span>
              <div>
                <div className="font-display text-[14px] font-bold text-white">ТОГТМОЛ · Том цаг</div>
                <div className="flex items-center gap-1.5 text-[11px] text-white/50">
                  {subject && <span className="h-2 w-2 rounded-full" style={{ background: subject.color }} />}
                  {subject?.name ?? "Чөлөөт"} · {roomLabel(roomId)} · {mode === "pomodoro" ? POMODORO_PRESETS[preset].label : `${customMin} мин`}
                </div>
              </div>
            </div>
            <button
              onClick={() => setExpanded(false)}
              className="flex items-center gap-1.5 rounded-xl bg-white/8 px-3 py-2 text-[12px] font-bold text-white/70 ring-1 ring-white/12 transition hover:bg-white/15"
            >
              Хураах <X size={15} />
            </button>
          </div>

          {/* center clock */}
          <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-4 py-4">
            <div className="relative">
              <RingClock
                size={bigSize}
                progress={progress}
                display={fmtClock(display)}
                phase={phase}
                status={status}
                accent={accent}
                sw={7}
              />
            </div>

            {/* pomodoro cycle pips */}
            {mode === "pomodoro" && (
              <div className="mt-5 flex items-center gap-1.5">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div
                    key={i}
                    className="h-2 rounded-full transition-all duration-500"
                    style={{
                      width: i === cycle - 1 ? 26 : 10,
                      background: i < cycle ? accent : "rgba(255,255,255,.14)",
                      boxShadow: i === cycle - 1 ? `0 0 12px ${accent}` : "none",
                    }}
                  />
                ))}
                <span className="ml-2 text-[11px] font-bold text-white/45">Цикл {cycle}</span>
              </div>
            )}

            {/* big controls */}
            <div className="mt-6 flex items-center gap-2.5">
              <button
                onClick={reset}
                className="grid h-14 w-14 place-items-center rounded-2xl bg-white/8 text-white/70 ring-1 ring-white/12 transition hover:scale-105 hover:bg-white/14"
                title="Цуцлах (R)"
              >
                <RotateCcw size={20} />
              </button>

              {status === "idle" ? (
                <button
                  onClick={start}
                  className="anim-ring flex h-16 items-center gap-3 rounded-3xl px-10 font-display text-[18px] font-bold text-white transition hover:scale-105 active:scale-95"
                  style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)`, boxShadow: `0 12px 44px ${accent}66` }}
                >
                  <Play size={22} fill="currentColor" /> Эхлэх
                </button>
              ) : (
                <>
                  <button
                    onClick={status === "running" ? pause : start}
                    className="flex h-16 items-center gap-3 rounded-3xl px-9 font-display text-[17px] font-bold text-white transition hover:scale-105"
                    style={{
                      background: status === "running"
                        ? "linear-gradient(135deg, #f59e0b, #d97706)"
                        : `linear-gradient(135deg, ${accent}, ${accent}88)`,
                      boxShadow: status === "running" ? "0 12px 44px rgba(245,158,11,.5)" : `0 12px 44px ${accent}66`,
                    }}
                  >
                    {status === "running" ? <><Pause size={21} /> Түр зогс</> : <><Play size={21} /> Үргэлжлүүл</>}
                  </button>
                  <button
                    onClick={() => finish(false)}
                    className="flex h-14 items-center gap-2 rounded-2xl bg-emerald-400/20 px-6 font-display text-[15px] font-bold text-emerald-200 ring-1 ring-emerald-400/40 transition hover:scale-105"
                  >
                    <Square size={17} /> Дуусгах
                  </button>
                </>
              )}

              {mode === "pomodoro" && status !== "idle" && (
                <button
                  onClick={skipPhase}
                  className="grid h-14 w-14 place-items-center rounded-2xl bg-white/8 text-white/70 ring-1 ring-white/12 transition hover:scale-105 hover:bg-white/14"
                  title="Ээлж дэвсгэх (S)"
                >
                  <SkipForward size={20} />
                </button>
              )}
            </div>

            {/* shortcuts hint */}
            <div className="mt-5 hidden items-center gap-2 text-[11px] text-white/35 md:flex">
              <Keyboard size={13} />
              <kbd className="rounded-md bg-white/10 px-1.5 py-0.5 font-bold">Space</kbd> эхлэх/зогсоо
              <kbd className="rounded-md bg-white/10 px-1.5 py-0.5 font-bold">S</kbd> дэвсгэх
              <kbd className="rounded-md bg-white/10 px-1.5 py-0.5 font-bold">R</kbd> шинэчлэх
              <kbd className="rounded-md bg-white/10 px-1.5 py-0.5 font-bold">Esc</kbd> хаах
            </div>
          </div>

          {/* bottom panels */}
          <div className="relative z-10 grid gap-2.5 px-4 pb-5 md:grid-cols-3 md:px-8">
            {/* left: session stats */}
            <div className="glass rounded-3xl p-3.5">
              <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-white/45">
                <Timer size={12} style={{ color: accent }} /> Энэ сесс
              </div>
              <div className="space-y-1.5 text-[12px]">
                <Row label="Нийт ажилласан" value={fmtMnDuration(totalFocusRef.current + (phase === "focus" ? elapsed : 0))} />
                <Row label="Сатаарал" value={String(interruptions)} danger={interruptions > 0} />
                <Row label="Давталт" value={mode === "pomodoro" ? `${cycle} / 8` : "—"} />
              </div>
              <div className="mt-2.5">
                <div className="mb-1 flex items-center gap-1 text-[11px] font-bold text-white/50">
                  <NotebookPen size={11} /> Сессийн тэмдэглэл
                </div>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={2}
                  placeholder="Юу хийснээ бич…"
                  className="w-full resize-none rounded-2xl bg-black/30 px-2.5 py-2 text-[12px] text-white ring-1 ring-white/10 outline-none placeholder:text-white/30 focus:ring-white/35"
                />
              </div>
            </div>

            {/* middle: subject + sound */}
            <div className="glass rounded-3xl p-3.5">
              <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-white/45">
                <BookOpen size={12} style={{ color: accent }} /> Хичээл
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSubjectId("")}
                  className={`rounded-xl px-2.5 py-1.5 text-[11px] font-bold ring-1 transition ${!subjectId ? "bg-white/20 text-white ring-white/40" : "bg-white/5 text-white/55 ring-white/10"}`}
                >
                  Чөлөөт
                </button>
                {subjects.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSubjectId(s.id)}
                    className={`flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-bold ring-1 transition ${
                      subjectId === s.id ? "bg-white/20 text-white ring-white/40" : "bg-white/5 text-white/60 ring-white/10 hover:bg-white/10"
                    }`}
                  >
                    <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                    {s.name}
                  </button>
                ))}
              </div>
              {mode === "pomodoro" && (
                <>
                  <div className="mt-3 mb-1 text-[11px] font-bold uppercase tracking-widest text-white/45">Амралтын хэмнэл</div>
                  <div className="grid grid-cols-3 gap-1.5">
                    {POMODORO_PRESETS.map((p, i) => (
                      <button
                        key={p.label}
                        onClick={() => setPreset(i)}
                        className={`rounded-xl py-2 text-[13px] font-bold ring-1 transition ${preset === i ? "text-white" : "bg-white/5 text-white/55 ring-white/10"}`}
                        style={preset === i ? { background: `${accent}33`, borderColor: `${accent}66` } : undefined}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </>
              )}
              <button
                onClick={() => setSoundOn(!soundOn)}
                className="mt-3 flex w-full items-center justify-between rounded-xl bg-white/5 px-3 py-2 text-[12px] font-bold text-white/60 ring-1 ring-white/10"
              >
                Дуусах дохио {soundOn ? <Bell size={14} /> : <BellOff size={14} />}
              </button>
            </div>

            {/* right: next up queue */}
            <div className="glass rounded-3xl p-3.5">
              <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-white/45">
                <Zap size={12} style={{ color: accent }} /> Дараа юу хүлээж байна
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 rounded-xl bg-white/5 px-2.5 py-2 ring-1 ring-white/8">
                  <Layers size={15} style={{ color: accent }} />
                  <span className="flex-1 text-[12px] font-bold text-white/85">Карт давтлага</span>
                  <span className={`text-[13px] font-bold ${dueCards > 0 ? "text-red-300" : "text-emerald-300"}`}>{dueCards}</span>
                </div>
                <div className="flex items-center gap-2 rounded-xl bg-white/5 px-2.5 py-2 ring-1 ring-white/8">
                  <ListTodo size={15} style={{ color: accent }} />
                  <span className="flex-1 text-[12px] font-bold text-white/85">Нээлттэй даалгавар</span>
                  <span className={`text-[13px] font-bold ${openTasks.length > 0 ? "text-amber-300" : "text-emerald-300"}`}>{openTasks.length}</span>
                </div>
                {openTasks.slice(0, 2).map((t) => (
                  <div key={t.id} className="truncate rounded-xl bg-white/[.03] px-2.5 py-1.5 text-[11px] text-white/50 ring-1 ring-white/6">
                    • {t.title}
                  </div>
                ))}
                {exam && (
                  <div className="flex items-center gap-2 rounded-xl px-2.5 py-2 ring-1" style={{ background: `${accent}1c`, borderColor: `${accent}44` }}>
                    <CalendarClock size={15} style={{ color: accent }} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[11px] font-bold text-white/85">{exam.title}</div>
                      <div className="text-[10px] text-white/50">зорилгын хугацаа</div>
                    </div>
                    <span className="font-display text-[15px] font-bold" style={{ color: accent }}>
                      {exam.days > 0 ? exam.days : 0}х
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Row({ label, value, danger }: { label: string; value: string; danger?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-white/50">{label}</span>
      <span className={`font-bold ${danger ? "text-red-300" : "text-white/90"}`}>{value}</span>
    </div>
  );
}

function roomLabel(id: string): string {
  const map: Record<string, string> = {
    night: "Шөнийн өрөө", rainy: "Бороотой кафе", forest: "Ой", space: "Сансар",
    cabin: "Уулын байшин", library: "Номын сан", ocean: "Далайн эрэг",
    sakura: "Сакура", cozy: "Муужгай", minimal: "Минимал",
  };
  return map[id] ?? id;
}
