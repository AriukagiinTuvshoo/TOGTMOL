import { sql } from "drizzle-orm";
import { db } from "@/db";
import { goals, milestones, sessions, settings, subjects, tasks } from "@/db/schema";
import { addDaysISO, combineDateTime, nowMinuteOfDay, todayISO } from "@/lib/date";

let seedPromise: Promise<void> | null = null;

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SOUNDSCAPES = [
  "forest-rain",
  "deep-focus",
  "night-library",
  "ocean-calm",
  "rainy-cafe",
  "space-drift",
];

export async function ensureSeeded(): Promise<void> {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    const existing = await db.select({ count: sql<number>`count(*)::int` }).from(subjects);
    if ((existing[0]?.count ?? 0) > 0) {
      await db.insert(settings).values({ id: 1 }).onConflictDoNothing();
      return;
    }

    await db.insert(settings).values({ id: 1 }).onConflictDoNothing();

    const subjectRows = await db
      .insert(subjects)
      .values([
        { name: "Математик", color: "#b9f24e", glyph: "∑", weeklyTargetMinutes: 360 },
        { name: "Физик", color: "#5eead4", glyph: "φ", weeklyTargetMinutes: 240 },
        { name: "Англи хэл", color: "#f472b6", glyph: "A", weeklyTargetMinutes: 300 },
        { name: "Программчлал", color: "#fbbf24", glyph: "{}", weeklyTargetMinutes: 300 },
        { name: "Монгол хэл", color: "#c084fc", glyph: "✎", weeklyTargetMinutes: 180 },
        { name: "Түүх", color: "#60a5fa", glyph: "⌛", weeklyTargetMinutes: 120 },
      ])
      .returning({ id: subjects.id });

    const [math, physics, english, programming, mongolian, history] = subjectRows.map(
      (row) => row.id,
    );

    const goalRows = await db
      .insert(goals)
      .values([
        {
          title: "ЭЕШ-д математикаас 750+ авах",
          description: "Бодлогын хурд, алдааны дүн шинжилгээ, өмнөх жилийн эсээнд төвлөрнө.",
          subjectId: math,
          targetDate: addDaysISO(todayISO(), 120),
          priority: 3,
          weeklyMinutes: 420,
        },
        {
          title: "IELTS 7.0 — бичих ба сонсгол",
          description: "Долоо хоногт 2 эссэ, 3 сонсголын дасгал. Үгсийн сангаа давтана.",
          subjectId: english,
          targetDate: addDaysISO(todayISO(), 180),
          priority: 2,
          weeklyMinutes: 300,
        },
        {
          title: "Алгоритм ба өгөгдлийн бүтэц",
          description: "Граф, динамик програмчлал, цаг хугацааны нарийн шинжилгээ.",
          subjectId: programming,
          targetDate: addDaysISO(todayISO(), 75),
          priority: 3,
          weeklyMinutes: 300,
        },
        {
          title: "Физикийн олимпиадын бэлтгэл",
          description: "Механик, цахилгаан соронзон — бодлого бодох хурд.",
          subjectId: physics,
          targetDate: addDaysISO(todayISO(), 50),
          priority: 2,
          weeklyMinutes: 240,
        },
      ])
      .returning({ id: goals.id });

    const [mathGoal, ieltsGoal, algoGoal, physicsGoal] = goalRows.map((row) => row.id);

    await db.insert(milestones).values([
      { goalId: mathGoal, title: "Функц ба хязгаарыг давтах", done: true, sortOrder: 1 },
      { goalId: mathGoal, title: "Интегралын 100 бодлого", done: false, sortOrder: 2, dueDate: addDaysISO(todayISO(), 14) },
      { goalId: mathGoal, title: "Өмнөх 5 жилийн эсээ", done: false, sortOrder: 3, dueDate: addDaysISO(todayISO(), 45) },
      { goalId: ieltsGoal, title: "20 эссэ бичих", done: true, sortOrder: 1 },
      { goalId: ieltsGoal, title: "Сонсголын 30 дасгал", done: false, sortOrder: 2, dueDate: addDaysISO(todayISO(), 30) },
      { goalId: algoGoal, title: "Графын алгоритм", done: true, sortOrder: 1 },
      { goalId: algoGoal, title: "Динамик програмчлал", done: false, sortOrder: 2, dueDate: addDaysISO(todayISO(), 20) },
      { goalId: algoGoal, title: "LeetCode 150 бодлого", done: false, sortOrder: 3 },
      { goalId: physicsGoal, title: "Кинематик ба динамик", done: true, sortOrder: 1 },
      { goalId: physicsGoal, title: "Олимпиадын 40 бодлого", done: false, sortOrder: 2, dueDate: addDaysISO(todayISO(), 10) },
    ]);

    const today = todayISO();
    await db.insert(tasks).values([
      {
        title: "Интеграл — бодлогын багц 4",
        notes: "Тодорхой интеграл, орлуулах арга. Алдаагаа тэмдэглэж явах.",
        subjectId: math,
        goalId: mathGoal,
        estimateMinutes: 50,
        priority: 3,
        energy: "deep",
        dueDate: today,
        scheduledStart: combineDateTime(today, 9 * 60),
        scheduledEnd: combineDateTime(today, 9 * 60 + 50),
      },
      {
        title: "Физик: кинематик бодлого",
        subjectId: physics,
        goalId: physicsGoal,
        estimateMinutes: 45,
        priority: 2,
        energy: "deep",
        dueDate: addDaysISO(today, 1),
        scheduledStart: combineDateTime(today, 10 * 60 + 10),
        scheduledEnd: combineDateTime(today, 10 * 60 + 55),
      },
      {
        title: "IELTS Task 2 — эссэ",
        notes: "Environment сэдэв. 40 минут бичиж, дараа нь засварлана.",
        subjectId: english,
        goalId: ieltsGoal,
        estimateMinutes: 60,
        priority: 3,
        energy: "deep",
        dueDate: addDaysISO(today, 2),
        scheduledStart: combineDateTime(today, 14 * 60),
        scheduledEnd: combineDateTime(today, 15 * 60),
      },
      {
        title: "React Server Components давтах",
        subjectId: programming,
        goalId: algoGoal,
        estimateMinutes: 40,
        priority: 2,
        energy: "light",
        dueDate: addDaysISO(today, 3),
        scheduledStart: combineDateTime(today, 16 * 60 + 30),
        scheduledEnd: combineDateTime(today, 17 * 60 + 10),
      },
      {
        title: "Монгол хэл: эсээний төлөвлөгөө",
        subjectId: mongolian,
        estimateMinutes: 30,
        priority: 1,
        energy: "light",
        dueDate: addDaysISO(today, 1),
      },
      {
        title: "Физикийн томьёоны карт",
        subjectId: physics,
        goalId: physicsGoal,
        estimateMinutes: 25,
        priority: 2,
        energy: "light",
        dueDate: addDaysISO(today, 2),
      },
      {
        title: "Өгөгдлийн бүтэц: BFS ба DFS",
        notes: "Графын гүнзгий хайлт. Хоёр бодлогыг цаг хэмжиж бод.",
        subjectId: programming,
        goalId: algoGoal,
        estimateMinutes: 45,
        priority: 3,
        energy: "deep",
        dueDate: addDaysISO(today, -1),
      },
      {
        title: "Математикийн өмнөх жилийн эсээ",
        subjectId: math,
        goalId: mathGoal,
        estimateMinutes: 90,
        priority: 2,
        energy: "deep",
        dueDate: addDaysISO(today, 4),
        scheduledStart: combineDateTime(addDaysISO(today, 1), 9 * 60),
        scheduledEnd: combineDateTime(addDaysISO(today, 1), 10 * 60 + 30),
      },
      {
        title: "Англи хэлний сонсгол",
        subjectId: english,
        goalId: ieltsGoal,
        estimateMinutes: 30,
        priority: 1,
        energy: "light",
        dueDate: addDaysISO(today, 5),
        scheduledStart: combineDateTime(addDaysISO(today, 1), 20 * 60),
        scheduledEnd: combineDateTime(addDaysISO(today, 1), 20 * 60 + 30),
      },
      {
        title: "Түүх: XX зууны тойм",
        subjectId: history,
        estimateMinutes: 40,
        priority: 1,
        energy: "light",
        dueDate: addDaysISO(today, 6),
      },
      {
        title: "Математик: дериватив давтлага",
        subjectId: math,
        goalId: mathGoal,
        estimateMinutes: 40,
        priority: 2,
        energy: "deep",
        status: "done",
        completedAt: combineDateTime(addDaysISO(today, -1), 18 * 60),
        focusSeconds: 2_400,
        dueDate: addDaysISO(today, -1),
      },
      {
        title: "IELTS үгсийн сан — 50 карт",
        subjectId: english,
        goalId: ieltsGoal,
        estimateMinutes: 25,
        priority: 1,
        energy: "light",
        status: "done",
        completedAt: combineDateTime(addDaysISO(today, -2), 19 * 60),
        focusSeconds: 1_500,
        dueDate: addDaysISO(today, -2),
      },
    ]);

    const random = mulberry32(20260214);
    const sessionValues: (typeof sessions.$inferInsert)[] = [];
    const subjectIds = [math, physics, english, programming, mongolian, history];

    for (let offset = 84; offset >= 1; offset -= 1) {
      const date = addDaysISO(today, -offset);
      const day = new Date(`${date}T12:00:00`).getDay();
      const weekendFactor = day === 0 || day === 6 ? 0.55 : 1;
      if (random() > 0.86 * weekendFactor) continue;
      const count = 1 + Math.floor(random() * (weekendFactor < 1 ? 2 : 3));
      let cursor = 7 * 60 + Math.floor(random() * 120);
      for (let index = 0; index < count; index += 1) {
        const duration = [1_500, 1_800, 2_100, 2_700, 3_000][Math.floor(random() * 5)];
        const subjectId = subjectIds[Math.floor(random() * subjectIds.length)];
        cursor += Math.floor(random() * 40);
        const start = cursor;
        const end = start + Math.round(duration / 60);
        cursor = end + 20 + Math.floor(random() * 40);
        if (end > 22 * 60) break;
        sessionValues.push({
          subjectId,
          mode: "focus",
          plannedSeconds: duration,
          actualSeconds: duration - Math.floor(random() * 180),
          startedAt: combineDateTime(date, start),
          endedAt: combineDateTime(date, end),
          localDate: date,
          soundscape: SOUNDSCAPES[Math.floor(random() * SOUNDSCAPES.length)],
          rating: 3 + Math.floor(random() * 3),
          interruptions: Math.floor(random() * 3),
          completed: true,
        });
      }
    }

    const nowMinute = nowMinuteOfDay();
    const morningSlots = [
      { start: 7 * 60 + 40, duration: 1_500 },
      { start: 9 * 60 + 30, duration: 2_100 },
    ];
    for (const slot of morningSlots) {
      if (slot.start + 10 < nowMinute) {
        const end = Math.min(nowMinute - 1, slot.start + Math.round(slot.duration / 60));
        if (end - slot.start < 5) continue;
        sessionValues.push({
          subjectId: math,
          mode: "focus",
          plannedSeconds: slot.duration,
          actualSeconds: (end - slot.start) * 60,
          startedAt: combineDateTime(today, slot.start),
          endedAt: combineDateTime(today, end),
          localDate: today,
          soundscape: "forest-rain",
          rating: 4,
          interruptions: 0,
          completed: true,
        });
      }
    }

    if (sessionValues.length > 0) {
      await db.insert(sessions).values(sessionValues);
    }

    await db.execute(sql`select 1`);
  })().catch((error) => {
    seedPromise = null;
    throw error;
  });

  return seedPromise;
}

export const SOUNDSCAPE_IDS = SOUNDSCAPES;
