import {
  combineDateTime,
  clockLabel,
  clockLabelFromTimestamp,
  daysBetweenISO,
  minutesOfDayFromClock,
  todayISO,
  nowMinuteOfDay,
} from "@/lib/date";
import type { Energy, PlanBlock, Settings, Subject, Task } from "@/lib/types";

type Interval = { start: number; end: number };

export const PRIORITY_LABEL: Record<number, string> = {
  1: "Бага",
  2: "Дунд",
  3: "Өндөр",
};

export function taskBlocks(tasks: Task[]): PlanBlock[] {
  return tasks
    .filter((task) => task.scheduledStart && task.scheduledEnd)
    .map((task) => {
      const startLabel = clockLabelFromTimestamp(task.scheduledStart) ?? "00:00";
      const endLabel = clockLabelFromTimestamp(task.scheduledEnd) ?? "00:00";
      return {
        id: `task-${task.id}`,
        taskId: task.id,
        title: task.title,
        startLabel,
        endLabel,
        startMinute: minutesOfDayFromClock(startLabel),
        endMinute: minutesOfDayFromClock(endLabel),
        startIso: task.scheduledStart,
        endIso: task.scheduledEnd,
        kind: "task" as const,
        energy: task.energy,
        subjectId: task.subjectId,
        reason: "Төлөвлөсөн блок",
        taskEstimate: task.estimateMinutes,
        taskPriority: task.priority,
      };
    })
    .sort((a, b) => a.startMinute - b.startMinute);
}

function subtractIntervals(window: Interval, busy: Interval[]): Interval[] {
  const sorted = [...busy]
    .filter((item) => item.end > window.start && item.start < window.end)
    .sort((a, b) => a.start - b.start);
  const free: Interval[] = [];
  let cursor = window.start;
  for (const item of sorted) {
    if (item.start > cursor) free.push({ start: cursor, end: Math.min(item.start, window.end) });
    cursor = Math.max(cursor, item.end);
    if (cursor >= window.end) break;
  }
  if (cursor < window.end) free.push({ start: cursor, end: window.end });
  return free.filter((slot) => slot.end - slot.start >= 10);
}

function urgencyScore(task: Task, date: string): number {
  if (!task.dueDate) return 0;
  const diff = daysBetweenISO(date, task.dueDate);
  if (diff < 0) return 900;
  if (diff === 0) return 600;
  if (diff === 1) return 340;
  if (diff <= 3) return 200;
  if (diff <= 7) return 90;
  return 30;
}

function preferredEnergyScore(
  taskEnergy: Energy,
  slot: Interval,
  deepStart: number,
  deepEnd: number,
): number {
  const overlapsDeep = slot.start < deepEnd && slot.end > deepStart;
  if (taskEnergy === "deep") return overlapsDeep ? 220 : -60;
  return overlapsDeep ? 20 : 90;
}

function splitChunks(estimate: number): number[] {
  const total = Math.max(10, Math.min(240, Math.round(estimate / 5) * 5));
  if (total <= 55) return [total];
  const chunks: number[] = [];
  let remaining = total;
  while (remaining > 0) {
    const chunk = Math.min(50, remaining);
    chunks.push(Math.max(20, chunk));
    remaining -= chunk;
  }
  return chunks;
}

export type AutoScheduleInput = {
  date: string;
  tasks: Task[];
  settings: Settings;
  nowMinute?: number;
};

export type AutoScheduleResult = {
  blocks: PlanBlock[];
  unplaced: Task[];
  loadMinutes: number;
  deepMinutes: number;
  breaks: number;
};

/**
 * Greedy, energy-aware day scheduler.
 * 1. Build the free-slot map inside the planning window (minus fixed blocks).
 * 2. Score every task by priority + deadline urgency + deep-work fit.
 * 3. Place the highest-value chunk into the earliest suitable free slot.
 * 4. Reserve a 5 minute recovery buffer between blocks.
 */
export function autoScheduleDay(input: AutoScheduleInput): AutoScheduleResult {
  const { date, settings } = input;
  const isToday = date === todayISO();
  const now = input.nowMinute ?? nowMinuteOfDay();
  const dayStart = minutesOfDayFromClock(settings.dayStart);
  const dayEnd = minutesOfDayFromClock(settings.dayEnd);
  const deepStart = minutesOfDayFromClock(settings.deepStart);
  const deepEnd = minutesOfDayFromClock(settings.deepEnd);

  const windowStart = isToday ? Math.max(dayStart, Math.ceil((now + 5) / 5) * 5) : dayStart;
  const windowEnd = Math.max(windowStart + 30, dayEnd);

  // Only tasks without a block are candidates; blocks belonging to *this* day
  // are treated as immovable (a reschedule flow clears them before calling us).
  const reschedule = input.tasks.filter(
    (task) => task.status !== "done" && task.scheduledStart === null,
  );
  const fixed = taskBlocks(
    input.tasks.filter((task) => task.scheduledStart?.slice(0, 10) === date),
  ).map((block) => ({
    start: block.startMinute,
    end: block.endMinute,
  }));

  let slots = subtractIntervals({ start: windowStart, end: windowEnd }, fixed);
  const scored = reschedule
    .map((task) => ({
      task,
      score: task.priority * 120 + urgencyScore(task, date) + (task.goalId ? 40 : 0),
    }))
    .sort((a, b) => b.score - a.score || a.task.estimateMinutes - b.task.estimateMinutes);

  const blocks: PlanBlock[] = [];
  const unplaced: Task[] = [];
  let loadMinutes = 0;
  let deepMinutes = 0;
  let breaks = 0;
  let lastBlockEnd = 0;

  for (const { task } of scored) {
    const chunks = splitChunks(task.estimateMinutes);
    let placedAll = true;
    for (const [chunkIndex, chunk] of chunks.entries()) {
      if (slots.length === 0) {
        placedAll = false;
        break;
      }
      const options = slots
        .map((slot) => {
          const fits = slot.end - slot.start >= chunk;
          const buffer = lastBlockEnd === slot.start ? 5 : 0;
          const start = Math.max(slot.start, windowStart) + buffer;
          if (!fits || start + chunk > slot.end) return null;
          const candidate = { start, end: start + chunk };
          const score =
            preferredEnergyScore(task.energy, candidate, deepStart, deepEnd) -
            (start - windowStart) * 0.12 +
            (slot.end - slot.start - chunk) * 0.04;
          return { slot, candidate, score };
        })
        .filter((option): option is { slot: Interval; candidate: Interval; score: number } => Boolean(option))
        .sort((a, b) => b.score - a.score);

      const best = options[0];
      if (!best) {
        placedAll = false;
        break;
      }

      const buffer = lastBlockEnd === best.slot.start ? 5 : 0;
      const start = Math.max(best.slot.start, windowStart) + buffer;
      const end = start + chunk;

      if (lastBlockEnd > 0 && start - lastBlockEnd >= 60 && breaks < 6) {
        breaks += 1;
        blocks.push({
          id: `break-${task.id}-${chunkIndex}`,
          taskId: null,
          title: "Сэргээх амралт",
          startLabel: clockLabel(lastBlockEnd + 5),
          endLabel: clockLabel(lastBlockEnd + 15),
          startMinute: lastBlockEnd + 5,
          endMinute: lastBlockEnd + 15,
          startIso: null,
          endIso: null,
          kind: "break",
          energy: "rest",
          subjectId: null,
          reason: "Урт завсарлага — тархинд амралт",
        });
      }

      const remainder = { start: end, end: best.slot.end };
      slots = slots.filter((slot) => slot !== best.slot);
      if (remainder.end - remainder.start >= 10) slots.push(remainder);
      const before = { start: best.slot.start, end: start };
      if (before.end - before.start >= 10) slots.push(before);
      slots.sort((a, b) => a.start - b.start);

      blocks.push({
        id: `auto-${task.id}-${chunkIndex}`,
        taskId: task.id,
        title: chunks.length > 1 ? `${task.title} · ${chunkIndex + 1}/${chunks.length}` : task.title,
        startLabel: clockLabel(start),
        endLabel: clockLabel(end),
        startMinute: start,
        endMinute: end,
        startIso: combineDateTime(date, start),
        endIso: combineDateTime(date, end),
        kind: "task",
        energy: task.energy,
        subjectId: task.subjectId,
        reason:
          task.priority === 3
            ? "Өндөр ач холбогдол"
            : task.energy === "deep"
              ? "Гүн анхаарлын цонх"
              : "Хөнгөн ажлын цонх",
        taskEstimate: task.estimateMinutes,
        taskPriority: task.priority,
      });
      loadMinutes += chunk;
      if (task.energy === "deep") deepMinutes += chunk;
      lastBlockEnd = end;
    }
    if (!placedAll) unplaced.push(task);
  }

  blocks.sort((a, b) => a.startMinute - b.startMinute);
  return { blocks, unplaced, loadMinutes, deepMinutes, breaks };
}

export function dayCapacity(settings: Settings): number {
  const start = minutesOfDayFromClock(settings.dayStart);
  const end = minutesOfDayFromClock(settings.dayEnd);
  // Real focus capacity is roughly 80% of the available window once breaks,
  // transitions and context switching are accounted for.
  return Math.max(0, Math.round((end - start) * 0.8));
}

export function subjectOf(subjects: Subject[], id: number | null): Subject | null {
  if (id === null) return null;
  return subjects.find((subject) => subject.id === id) ?? null;
}

export function overdueTasks(tasks: Task[], today = todayISO()): Task[] {
  return tasks.filter(
    (task) => task.status !== "done" && task.dueDate !== null && task.dueDate < today,
  );
}

export function focusQueue(tasks: Task[]): Task[] {
  return tasks
    .filter((task) => task.status !== "done")
    .sort((a, b) => {
      const dueA = a.dueDate ?? "9999-12-31";
      const dueB = b.dueDate ?? "9999-12-31";
      if (dueA !== dueB) return dueA.localeCompare(dueB);
      return b.priority - a.priority;
    });
}
