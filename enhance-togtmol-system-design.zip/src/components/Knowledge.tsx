"use client";

import { useEffect, useMemo, useState } from "react";
import {
  NotebookPen, Layers, ClipboardCheck, Plus, Search, Star, Trash2, X,
  RotateCw, Check, Eye, ChevronRight, Trophy, Sparkles, BookOpen, Pencil,
} from "lucide-react";
import { api } from "@/lib/api";
import { sm2 } from "@/lib/focus";
import { engine } from "@/lib/audio-engine";
import type { Subject, Note, Deck, Card, Quiz } from "@/db/schema";

interface Props {
  subjects: Subject[];
  notes: Note[];
  decks: Deck[];
  cards: Card[];
  quizzes: Quiz[];
  accent: string;
  refresh: () => void;
  onXp?: (xp: number, label: string) => void;
}

type Tab = "notes" | "cards" | "quiz";

export default function Knowledge({ subjects, notes, decks, cards, quizzes, accent, refresh, onXp }: Props) {
  const [tab, setTab] = useState<Tab>("cards");

  return (
    <div className="glass rounded-3xl p-4 md:p-5">
      <div className="grid grid-cols-3 gap-1.5">
        {([
          { id: "cards", label: "Карт", icon: Layers, badge: cards.filter((c) => new Date(c.nextReview) <= new Date()).length },
          { id: "notes", label: "Тэмдэглэл", icon: NotebookPen, badge: notes.length },
          { id: "quiz", label: "Сорил", icon: ClipboardCheck, badge: quizzes.length },
        ] as { id: Tab; label: string; icon: any; badge: number }[]).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative flex items-center justify-center gap-1.5 rounded-2xl px-2 py-2.5 text-[13px] font-bold ring-1 transition ${
              tab === t.id ? "text-white" : "bg-white/5 text-white/55 ring-white/10 hover:bg-white/10"
            }`}
            style={tab === t.id ? { background: `${accent}2e`, borderColor: `${accent}66` } : undefined}
          >
            <t.icon size={15} />
            {t.label}
            {t.badge > 0 && (
              <span
                className="grid min-h-5 min-w-5 place-items-center rounded-full px-1 text-[10px] font-bold text-white"
                style={{ background: accent }}
              >
                {t.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="mt-4">
        {tab === "cards" && <CardsPanel decks={decks} cards={cards} subjects={subjects} accent={accent} refresh={refresh} onXp={onXp} />}
        {tab === "notes" && <NotesPanel notes={notes} subjects={subjects} accent={accent} refresh={refresh} />}
        {tab === "quiz" && <QuizPanel quizzes={quizzes} subjects={subjects} accent={accent} refresh={refresh} onXp={onXp} />}
      </div>
    </div>
  );
}

// ─── FLASHCARDS ─────────────────────────────────────────────────────
function CardsPanel({ decks, cards, subjects, accent, refresh, onXp }: {
  decks: Deck[]; cards: Card[]; subjects: Subject[]; accent: string; refresh: () => void; onXp?: (xp: number, label: string) => void;
}) {
  const [deckId, setDeckId] = useState<string>("");
  const [queue, setQueue] = useState<Card[]>([]);
  const [flipped, setFlipped] = useState(false);
  const [done, setDone] = useState(0);
  const [showAdd, setShowAdd] = useState(false);
  const [showDeck, setShowDeck] = useState(false);
  const [front, setFront] = useState("");
  const [back, setBack] = useState("");
  const [deckName, setDeckName] = useState("");

  const activeDeck = deckId || decks[0]?.id || "";
  const due = useMemo(
    () => cards.filter((c) => (!activeDeck || c.deckId === activeDeck) && new Date(c.nextReview) <= new Date()),
    [cards, activeDeck]
  );
  const deckCards = useMemo(
    () => cards.filter((c) => !activeDeck || c.deckId === activeDeck),
    [cards, activeDeck]
  );
  const current = queue[0];

  const startSession = () => {
    const shuffled = [...due].sort(() => Math.random() - 0.5);
    setQueue(shuffled);
    setFlipped(false);
    setDone(0);
  };

  useEffect(() => {
    if (queue.length === 0 && done > 0) {
      engine.chime("complete");
      onXp?.(done * 3, `Карт давтлага +${done * 3} XP`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queue.length]);

  const grade = async (g: number) => {
    if (!current) return;
    const r = sm2(
      { easeFactor: current.easeFactor, intervalDays: current.intervalDays, repetitions: current.repetitions },
      g
    );
    const next = new Date(Date.now() + r.nextInDays * 864e5);
    try {
      await api.update("cards", current.id, {
        easeFactor: r.easeFactor, intervalDays: r.intervalDays,
        repetitions: r.repetitions, lastGrade: g, nextReview: next.toISOString(),
      });
      await api.create("card_reviews", { cardId: current.id, grade: g });
    } catch { /* noop */ }
    setDone((d) => d + 1);
    setFlipped(false);
    setQueue((q) => q.slice(1));
    refresh();
  };

  const addCard = async () => {
    if (!front.trim() || !back.trim() || !activeDeck) return;
    await api.create("cards", { deckId: activeDeck, front: front.trim(), back: back.trim() });
    setFront(""); setBack(""); setShowAdd(false);
    refresh();
  };

  const createDeck = async () => {
    if (!deckName.trim()) return;
    const d = await api.create<Deck>("decks", { name: deckName.trim(), subjectId: subjects[0]?.id ?? null });
    setDeckName(""); setShowDeck(false);
    setDeckId(d.id);
    refresh();
  };

  const delCard = async (id: string) => {
    if (!confirm("Энэ картыг устгах уу?")) return;
    await api.remove("cards", id);
    refresh();
  };

  if (current) {
    const total = done + queue.length;
    return (
      <div className="anim-pop">
        <div className="mb-2 flex items-center justify-between text-[12px] text-white/60">
          <span className="font-bold">{done + 1} / {total} · {decks.find((d) => d.id === current.deckId)?.name}</span>
          <button onClick={() => setQueue([])} className="flex items-center gap-1 rounded-lg bg-white/8 px-2 py-1 font-bold hover:bg-white/15">
            <X size={13} /> Гарах
          </button>
        </div>
        <div className="mb-3 h-2 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full transition-all" style={{ width: `${(done / total) * 100}%`, background: accent }} />
        </div>
        <div className={`perspective ${flipped ? "flip-flipped" : ""}`}>
          <button
            onClick={() => setFlipped(!flipped)}
            className="flip-inner relative block min-h-[220px] w-full rounded-3xl p-6 text-center ring-1 ring-white/15"
            style={{ background: `linear-gradient(160deg, ${accent}30, rgba(10,10,25,.9))` }}
          >
            <div className={`flip-face ${flipped ? "hidden" : ""}`}>
              <div className="text-[11px] font-bold uppercase tracking-widest text-white/50">Асуулт</div>
              <div className="mt-3 font-display text-[22px] font-bold leading-snug text-white">{current.front}</div>
              <div className="mt-5 inline-flex items-center gap-1.5 rounded-full bg-white/10 px-4 py-2 text-[12px] font-bold text-white/75">
                <Eye size={14} /> Хариулт харах
              </div>
            </div>
            <div className={`flip-face flip-back ${flipped ? "" : "hidden"}`}>
              <div className="text-[11px] font-bold uppercase tracking-widest text-white/50">Хариулт</div>
              <div className="mt-3 text-[17px] font-semibold leading-relaxed text-white">{current.back}</div>
            </div>
          </button>
        </div>
        {flipped ? (
          <div className="anim-pop mt-3">
            <div className="mb-2 text-center text-[12px] font-bold text-white/55">Надад хэр санагдсан бэ?</div>
            <div className="grid grid-cols-6 gap-1.5">
              {[
                { g: 0, l: "0", c: "#ef4444" }, { g: 1, l: "1", c: "#f97316" },
                { g: 2, l: "2", c: "#eab308" }, { g: 3, l: "3", c: "#84cc16" },
                { g: 4, l: "4", c: "#22c55e" }, { g: 5, l: "5", c: "#10b981" },
              ].map((b) => (
                <button
                  key={b.g}
                  onClick={() => grade(b.g)}
                  className="rounded-2xl py-3 font-display text-[16px] font-bold text-white transition hover:scale-105"
                  style={{ background: `${b.c}30`, border: `1px solid ${b.c}66` }}
                >
                  {b.l}
                </button>
              ))}
            </div>
            <div className="mt-1.5 flex justify-between text-[10px] text-white/40">
              <span>Мартсан</span><span>Санасан</span>
            </div>
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-2 gap-1.5">
            <div className="rounded-2xl bg-white/5 p-2.5 text-center ring-1 ring-white/10">
              <div className="text-[11px] text-white/50">Давталт</div>
              <div className="font-bold text-white">{current.repetitions}×</div>
            </div>
            <div className="rounded-2xl bg-white/5 p-2.5 text-center ring-1 ring-white/10">
              <div className="text-[11px] text-white/50">Интервал</div>
              <div className="font-bold text-white">{current.intervalDays} өдөр</div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      {/* deck selector */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {decks.map((d) => {
          const n = cards.filter((c) => c.deckId === d.id && new Date(c.nextReview) <= new Date()).length;
          return (
            <button
              key={d.id}
              onClick={() => setDeckId(d.id)}
              className={`flex shrink-0 items-center gap-2 rounded-2xl px-3 py-2 text-[12px] font-bold ring-1 transition ${
                activeDeck === d.id ? "text-white" : "bg-white/5 text-white/60 ring-white/10"
              }`}
              style={activeDeck === d.id ? { background: `${accent}2e`, borderColor: `${accent}66` } : undefined}
            >
              <Layers size={13} />
              {d.name}
              {n > 0 && (
                <span className="grid h-5 min-w-5 place-items-center rounded-full bg-red-400 px-1 text-[10px] text-white">{n}</span>
              )}
            </button>
          );
        })}
        <button onClick={() => setShowDeck(true)} className="flex shrink-0 items-center gap-1 rounded-2xl bg-white/5 px-3 py-2 text-[12px] font-bold text-white/60 ring-1 ring-white/10 hover:bg-white/10">
          <Plus size={13} /> Багц
        </button>
      </div>

      {showDeck && (
        <div className="anim-pop mt-2 flex gap-1.5">
          <input
            value={deckName} onChange={(e) => setDeckName(e.target.value)}
            placeholder="Шинэ багцын нэр…"
            className="w-full rounded-2xl bg-black/30 px-3 py-2.5 text-[13px] text-white ring-1 ring-white/15 outline-none placeholder:text-white/30 focus:ring-white/40"
          />
          <button onClick={createDeck} className="shrink-0 rounded-2xl px-4 py-2 text-[13px] font-bold text-white" style={{ background: accent }}>
            <Check size={15} />
          </button>
        </div>
      )}

      {/* start card */}
      <div className="mt-3 rounded-3xl bg-white/5 p-4 text-center ring-1 ring-white/10">
        <div className="font-display text-[34px] font-bold text-white">{due.length}</div>
        <div className="text-[12px] text-white/55">карт давтах цаг болсон (SM-2)</div>
        <div className="mt-3 flex justify-center gap-2">
          <button
            onClick={startSession}
            disabled={due.length === 0}
            className="flex items-center gap-2 rounded-2xl px-6 py-2.5 text-[13px] font-bold text-white transition hover:scale-105 disabled:opacity-40"
            style={{ background: `linear-gradient(135deg, ${accent}, ${accent}77)` }}
          >
            <RotateCw size={14} /> Давтах
          </button>
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1.5 rounded-2xl bg-white/10 px-4 py-2.5 text-[13px] font-bold text-white/80 ring-1 ring-white/15 hover:bg-white/15">
            <Plus size={14} /> Карт нэмэх
          </button>
        </div>
      </div>

      {showAdd && (
        <div className="anim-pop mt-2 space-y-1.5 rounded-3xl bg-black/25 p-3 ring-1 ring-white/10">
          <input
            value={front} onChange={(e) => setFront(e.target.value)}
            placeholder="Нүүр — асуулт / үг…"
            className="w-full rounded-2xl bg-white/8 px-3 py-2.5 text-[13px] text-white ring-1 ring-white/12 outline-none placeholder:text-white/30"
          />
          <input
            value={back} onChange={(e) => setBack(e.target.value)}
            placeholder="Ар — хариулт / утга…"
            className="w-full rounded-2xl bg-white/8 px-3 py-2.5 text-[13px] text-white ring-1 ring-white/12 outline-none placeholder:text-white/30"
          />
          <button onClick={addCard} className="w-full rounded-2xl py-2.5 text-[13px] font-bold text-white" style={{ background: accent }}>
            Хадгалах
          </button>
        </div>
      )}

      {/* card list */}
      <div className="mt-3 max-h-56 space-y-1.5 overflow-y-auto pr-1">
        {deckCards.slice(0, 30).map((c) => {
          const isDue = new Date(c.nextReview) <= new Date();
          return (
            <div key={c.id} className="group flex items-center gap-2 rounded-2xl bg-white/4 px-3 py-2 ring-1 ring-white/8">
              <div className={`h-2 w-2 shrink-0 rounded-full ${isDue ? "bg-red-400" : "bg-emerald-400"}`} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[12px] font-bold text-white/90">{c.front}</div>
                <div className="truncate text-[11px] text-white/45">{c.back}</div>
              </div>
              <button onClick={() => delCard(c.id)} className="opacity-0 transition group-hover:opacity-100 hover:text-red-300 text-white/40">
                <Trash2 size={14} />
              </button>
            </div>
          );
        })}
        {deckCards.length === 0 && (
          <div className="rounded-2xl bg-white/4 p-4 text-center text-[12px] text-white/45">
            Энэ багцад карт алга — дээрээс нэмээрэй ✨
          </div>
        )}
      </div>
    </div>
  );
}

// ─── NOTES ──────────────────────────────────────────────────────────
function NotesPanel({ notes, subjects, accent, refresh }: {
  notes: Note[]; subjects: Subject[]; accent: string; refresh: () => void;
}) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [editing, setEditing] = useState(false);

  const filtered = notes.filter((n) =>
    !q || n.title.toLowerCase().includes(q.toLowerCase()) || n.content.toLowerCase().includes(q.toLowerCase())
  );
  const selected = notes.find((n) => n.id === sel);

  const openNew = () => {
    setSel(null); setTitle(""); setContent(""); setEditing(true);
  };
  const open = (n: Note) => {
    setSel(n.id); setTitle(n.title); setContent(n.content); setEditing(false);
  };
  const save = async () => {
    if (!title.trim()) return;
    if (sel) await api.update("notes", sel, { title: title.trim(), content, updatedAt: new Date().toISOString() });
    else await api.create("notes", { title: title.trim(), content, subjectId: subjects[0]?.id ?? null });
    setEditing(false);
    refresh();
  };
  const del = async (id: string) => {
    if (!confirm("Устгах уу?")) return;
    await api.remove("notes", id);
    setSel(null);
    refresh();
  };
  const fav = async (n: Note) => {
    await api.update("notes", n.id, { favorite: !n.favorite });
    refresh();
  };

  return (
    <div>
      <div className="flex gap-1.5">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/35" />
          <input
            value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="Тэмдэглэл хайх…"
            className="w-full rounded-2xl bg-black/30 py-2.5 pl-9 pr-3 text-[13px] text-white ring-1 ring-white/12 outline-none placeholder:text-white/30 focus:ring-white/40"
          />
        </div>
        <button onClick={openNew} className="flex shrink-0 items-center gap-1 rounded-2xl px-3.5 py-2 text-[13px] font-bold text-white" style={{ background: accent }}>
          <Plus size={15} /> Шинэ
        </button>
      </div>

      {editing || (!selected && sel === null && (title || content || editing)) ? (
        <div className="anim-pop mt-2 space-y-1.5">
          <input
            value={title} onChange={(e) => setTitle(e.target.value)}
            placeholder="Гарчиг…"
            className="w-full rounded-2xl bg-black/30 px-3 py-2.5 font-display text-[14px] font-bold text-white ring-1 ring-white/15 outline-none placeholder:text-white/30"
          />
          <textarea
            value={content} onChange={(e) => setContent(e.target.value)}
            placeholder="Энд бич… (markdown дэмжинэ)"
            rows={6}
            className="w-full resize-none rounded-2xl bg-black/30 px-3 py-2.5 text-[13px] leading-relaxed text-white/90 ring-1 ring-white/15 outline-none placeholder:text-white/30"
          />
          <div className="flex gap-1.5">
            <button onClick={save} className="flex-1 rounded-2xl py-2.5 text-[13px] font-bold text-white" style={{ background: accent }}>
              Хадгалах
            </button>
            <button onClick={() => setEditing(false)} className="rounded-2xl bg-white/10 px-4 py-2 text-[13px] font-bold text-white/70">
              Болих
            </button>
          </div>
        </div>
      ) : selected && !editing ? (
        <div className="anim-pop mt-2 rounded-3xl bg-black/25 p-4 ring-1 ring-white/12">
          <div className="flex items-start justify-between gap-2">
            <h4 className="font-display text-[16px] font-bold text-white">{selected.title}</h4>
            <div className="flex shrink-0 gap-1">
              <button onClick={() => fav(selected)} className="grid h-8 w-8 place-items-center rounded-xl bg-white/8 hover:bg-white/15">
                <Star size={14} className={selected.favorite ? "fill-amber-300 text-amber-300" : "text-white/50"} />
              </button>
              <button onClick={() => setEditing(true)} className="grid h-8 w-8 place-items-center rounded-xl bg-white/8 hover:bg-white/15">
                <Pencil size={14} className="text-white/60" />
              </button>
              <button onClick={() => del(selected.id)} className="grid h-8 w-8 place-items-center rounded-xl bg-white/8 hover:bg-red-500/30">
                <Trash2 size={14} className="text-white/60" />
              </button>
              <button onClick={() => setSel(null)} className="grid h-8 w-8 place-items-center rounded-xl bg-white/8 hover:bg-white/15">
                <X size={14} className="text-white/60" />
              </button>
            </div>
          </div>
          <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed text-white/80">{selected.content || "(хоосон)"}</p>
          <div className="mt-2 text-[10px] text-white/35">
            {new Date(selected.updatedAt).toLocaleString("mn-MN")}
          </div>
        </div>
      ) : null}

      <div className="mt-2 max-h-64 space-y-1.5 overflow-y-auto pr-1">
        {filtered.map((n) => (
          <button
            key={n.id}
            onClick={() => open(n)}
            className={`flex w-full items-center gap-2.5 rounded-2xl px-3 py-2.5 text-left ring-1 transition hover:bg-white/8 ${
              sel === n.id ? "bg-white/10 ring-white/25" : "bg-white/4 ring-white/8"
            }`}
          >
            {n.favorite && <Star size={13} className="shrink-0 fill-amber-300 text-amber-300" />}
            <div className="min-w-0 flex-1">
              <div className="truncate text-[13px] font-bold text-white/90">{n.title}</div>
              <div className="truncate text-[11px] text-white/45">{n.content.slice(0, 80) || "—"}</div>
            </div>
            <ChevronRight size={14} className="shrink-0 text-white/30" />
          </button>
        ))}
        {filtered.length === 0 && (
          <div className="rounded-2xl bg-white/4 p-4 text-center text-[12px] text-white/45">
            Тэмдэглэл олдсонгүй — “Шинэ” товчоор эхлээрэй 📝
          </div>
        )}
      </div>
    </div>
  );
}

// ─── QUIZ ───────────────────────────────────────────────────────────
interface Q { q: string; type: "choice" | "bool" | "short"; options?: string[]; answer: number | boolean | string }

function QuizPanel({ quizzes, subjects, accent, refresh, onXp }: {
  quizzes: Quiz[]; subjects: Subject[]; accent: string; refresh: () => void; onXp?: (xp: number, label: string) => void;
}) {
  const [quizId, setQuizId] = useState("");
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<(number | boolean | string | null)[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [short, setShort] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newQ, setNewQ] = useState("");
  const [newOpts, setNewOpts] = useState("");
  const [newAns, setNewAns] = useState(0);
  const [draftQs, setDraftQs] = useState<Q[]>([]);

  const quiz = quizzes.find((x) => x.id === (quizId || quizzes[0]?.id));
  const questions = useMemo(() => ((quiz?.questions as unknown as Q[]) ?? []), [quiz]);

  const start = () => {
    setIdx(0);
    setAnswers(new Array(questions.length).fill(null));
    setShowResult(false);
    setShort("");
  };

  const answer = (a: number | boolean | string) => {
    const next = [...answers];
    next[idx] = a;
    setAnswers(next);
    if (idx + 1 < questions.length) {
      setIdx(idx + 1);
      setShort("");
    } else {
      finish(next);
    }
  };

  const finish = async (ans: (number | boolean | string | null)[]) => {
    let score = 0;
    questions.forEach((qq, i) => {
      const a = ans[i];
      if (qq.type === "choice" && a === qq.answer) score++;
      else if (qq.type === "bool" && a === qq.answer) score++;
      else if (qq.type === "short" && String(a ?? "").trim().toLowerCase().includes(String(qq.answer).toLowerCase().slice(0, 4))) score++;
    });
    setShowResult(true);
    if (score === questions.length && questions.length > 0) engine.chime("complete");
    else if (score >= questions.length / 2) engine.chime("break");
    try {
      if (quiz) await api.create("quiz_attempts", { quizId: quiz.id, score, total: questions.length, answers: ans });
    } catch { /* noop */ }
    onXp?.(score * 5, `Сорил +${score * 5} XP`);
    refresh();
  };

  const addDraftQ = () => {
    if (!newQ.trim()) return;
    const opts = newOpts.split("|").map((s) => s.trim()).filter(Boolean);
    if (opts.length >= 2) {
      setDraftQs([...draftQs, { q: newQ.trim(), type: "choice", options: opts, answer: Math.min(newAns, opts.length - 1) }]);
    } else {
      setDraftQs([...draftQs, { q: newQ.trim(), type: "short", answer: newOpts.trim() || "?" }]);
    }
    setNewQ(""); setNewOpts(""); setNewAns(0);
  };

  const createQuiz = async () => {
    if (!newTitle.trim() || draftQs.length === 0) return;
    await api.create("quizzes", { title: newTitle.trim(), questions: draftQs, subjectId: subjects[0]?.id ?? null });
    setNewTitle(""); setDraftQs([]); setShowNew(false);
    refresh();
  };

  if (showResult && quiz) {
    const score = answers.filter((a, i) => {
      const qq = questions[i];
      if (qq.type === "choice") return a === qq.answer;
      if (qq.type === "bool") return a === qq.answer;
      return String(a ?? "").trim().toLowerCase().includes(String(qq.answer).toLowerCase().slice(0, 4));
    }).length;
    const pct = questions.length ? Math.round((score / questions.length) * 100) : 0;
    return (
      <div className="anim-pop rounded-3xl bg-white/5 p-5 text-center ring-1 ring-white/12">
        <Trophy size={40} className="mx-auto" style={{ color: accent }} />
        <div className="mt-2 font-display text-[30px] font-bold text-white">{score}/{questions.length}</div>
        <div className="text-[13px] text-white/60">{pct}% — {pct === 100 ? "Төгс! Бондоок бахархаж байна 🎉" : pct >= 60 ? "Сайн байна! Бага зэрэг дутуу." : "Дахин оролд — давтлага бол түлхүүр 🔑"}</div>
        <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: accent }} />
        </div>
        <div className="mt-3 space-y-1.5 text-left">
          {questions.map((qq, i) => {
            const ok = answers[i] === qq.answer ||
              (qq.type === "short" && String(answers[i] ?? "").toLowerCase().includes(String(qq.answer).toLowerCase().slice(0, 4)));
            return (
              <div key={i} className={`rounded-2xl px-3 py-2 text-[12px] ring-1 ${ok ? "bg-emerald-400/10 ring-emerald-400/25 text-emerald-100" : "bg-red-400/10 ring-red-400/25 text-red-100"}`}>
                <span className="font-bold">{ok ? "✓" : "✗"}</span> {qq.q}
                {!ok && <div className="mt-0.5 text-white/60">Зөв: {qq.type === "choice" ? qq.options?.[qq.answer as number] : String(qq.answer)}</div>}
              </div>
            );
          })}
        </div>
        <button onClick={() => setShowResult(false)} className="mt-3 rounded-2xl bg-white/10 px-6 py-2.5 text-[13px] font-bold text-white ring-1 ring-white/15 hover:bg-white/15">
          Буцах
        </button>
      </div>
    );
  }

  if (answers.length > 0 && questions[idx]) {
    const qq = questions[idx];
    return (
      <div className="anim-pop">
        <div className="mb-2 flex items-center justify-between text-[12px] text-white/60">
          <span className="font-bold">{idx + 1} / {questions.length}</span>
          <button onClick={() => setAnswers([])} className="rounded-lg bg-white/8 px-2 py-1 font-bold hover:bg-white/15">
            <X size={13} />
          </button>
        </div>
        <div className="mb-3 h-2 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full transition-all" style={{ width: `${(idx / questions.length) * 100}%`, background: accent }} />
        </div>
        <div className="rounded-3xl bg-white/5 p-5 ring-1 ring-white/12">
          <div className="font-display text-[17px] font-bold leading-snug text-white">{qq.q}</div>
        </div>
        <div className="mt-3 space-y-1.5">
          {qq.type === "choice" && qq.options?.map((op, i) => (
            <button
              key={i}
              onClick={() => answer(i)}
              className="flex w-full items-center gap-2.5 rounded-2xl bg-white/5 px-4 py-3 text-left text-[13px] font-bold text-white/85 ring-1 ring-white/10 transition hover:scale-[1.01] hover:bg-white/10"
            >
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-xl bg-white/10 text-[12px]" style={{ color: accent }}>
                {String.fromCharCode(65 + i)}
              </span>
              {op}
            </button>
          ))}
          {qq.type === "bool" && (
            <div className="grid grid-cols-2 gap-1.5">
              {[true, false].map((b) => (
                <button
                  key={String(b)}
                  onClick={() => answer(b)}
                  className="rounded-2xl py-4 font-display text-[16px] font-bold text-white ring-1 transition hover:scale-[1.02]"
                  style={{ background: b ? "rgba(34,197,94,.2)" : "rgba(239,68,68,.2)", borderColor: b ? "rgba(34,197,94,.4)" : "rgba(239,68,68,.4)" }}
                >
                  {b ? "✓ Үнэн" : "✗ Худал"}
                </button>
              ))}
            </div>
          )}
          {qq.type === "short" && (
            <div className="flex gap-1.5">
              <input
                value={short}
                onChange={(e) => setShort(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && short.trim()) answer(short.trim()); }}
                placeholder="Хариултаа бич…"
                autoFocus
                className="w-full rounded-2xl bg-black/30 px-4 py-3 text-[14px] text-white ring-1 ring-white/15 outline-none placeholder:text-white/30"
              />
              <button onClick={() => short.trim() && answer(short.trim())} className="shrink-0 rounded-2xl px-5 py-2 text-[14px] font-bold text-white" style={{ background: accent }}>
                <ChevronRight size={18} />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {quizzes.map((x) => (
          <button
            key={x.id}
            onClick={() => setQuizId(x.id)}
            className={`shrink-0 rounded-2xl px-3 py-2 text-[12px] font-bold ring-1 transition ${
              (quizId || quizzes[0]?.id) === x.id ? "text-white" : "bg-white/5 text-white/60 ring-white/10"
            }`}
            style={(quizId || quizzes[0]?.id) === x.id ? { background: `${accent}2e`, borderColor: `${accent}66` } : undefined}
          >
            <BookOpen size={12} className="mr-1 inline" />
            {x.title}
          </button>
        ))}
        <button onClick={() => setShowNew(!showNew)} className="flex shrink-0 items-center gap-1 rounded-2xl bg-white/5 px-3 py-2 text-[12px] font-bold text-white/60 ring-1 ring-white/10 hover:bg-white/10">
          <Plus size={13} /> Сорил
        </button>
      </div>

      {showNew && (
        <div className="anim-pop mt-2 space-y-1.5 rounded-3xl bg-black/25 p-3 ring-1 ring-white/10">
          <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Сорилын нэр…" className="w-full rounded-2xl bg-white/8 px-3 py-2.5 text-[13px] font-bold text-white ring-1 ring-white/12 outline-none placeholder:text-white/30" />
          <input value={newQ} onChange={(e) => setNewQ(e.target.value)} placeholder="Асуулт…" className="w-full rounded-2xl bg-white/8 px-3 py-2.5 text-[13px] text-white ring-1 ring-white/12 outline-none placeholder:text-white/30" />
          <input value={newOpts} onChange={(e) => setNewOpts(e.target.value)} placeholder="Хариултууд (|) — жишээ: Улаан|Ногоон|Цэнхэр" className="w-full rounded-2xl bg-white/8 px-3 py-2.5 text-[13px] text-white ring-1 ring-white/12 outline-none placeholder:text-white/30" />
          <div className="flex gap-1.5">
            <button onClick={addDraftQ} className="flex-1 rounded-2xl bg-white/10 py-2 text-[12px] font-bold text-white/80 ring-1 ring-white/15">
              + Асуулт нэмэх ({draftQs.length})
            </button>
            <button onClick={createQuiz} disabled={!newTitle.trim() || draftQs.length === 0} className="flex-1 rounded-2xl py-2 text-[12px] font-bold text-white disabled:opacity-40" style={{ background: accent }}>
              Сорил үүсгэх
            </button>
          </div>
          <p className="flex items-center gap-1 text-[11px] text-white/40"><Sparkles size={11} /> Эхний хариулт зөв гэж тооцогдоно</p>
        </div>
      )}

      {quiz ? (
        <div className="mt-3 rounded-3xl bg-white/5 p-5 text-center ring-1 ring-white/10">
          <ClipboardCheck size={32} className="mx-auto opacity-70" style={{ color: accent }} />
          <div className="mt-2 font-display text-[17px] font-bold text-white">{quiz.title}</div>
          <div className="text-[12px] text-white/55">{questions.length} асуулт · сонгох / үнэн-худлын / бичих</div>
          <button
            onClick={start}
            disabled={questions.length === 0}
            className="mt-3 rounded-2xl px-8 py-2.5 text-[13px] font-bold text-white transition hover:scale-105 disabled:opacity-40"
            style={{ background: `linear-gradient(135deg, ${accent}, ${accent}77)` }}
          >
            Сорил эхлэх
          </button>
        </div>
      ) : (
        <div className="mt-3 rounded-3xl bg-white/4 p-5 text-center text-[12px] text-white/45">
          Сорил алга — дээрээс үүсгээрэй ✨
        </div>
      )}
    </div>
  );
}
